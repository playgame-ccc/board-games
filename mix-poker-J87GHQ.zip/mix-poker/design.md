# MIX POKER — Design

10種目のミックスポーカー（ホールデム / スーパーHD / オーシャン / PLO / PLO8 / A-5 / 2-7 SD・TD / バドゥーギ / 7スタッド / スタッドHi-Lo / ラズ）を
CPU対戦＋マルチプレイで遊べる Web ゲーム。ビジュアル方針は **グラスモーフィズム**：
深いミッドナイトのオーロラ背景の上に、半透明でぼかしの効いた「ガラス板」UI を重ねる。
（元デザインの JOPT 風＝茶色木目×濃緑フェルト×金 は全面的に置き換え済み）

プラットフォーム: Web（`packages/web`）。デスクトップは同じ Web UI を読み込む。

## Brand & Colors

トークンは `packages/web/public/mixpoker/style.css` の `:root` に定義。
ゲームロジック（`/mixpoker/game*.js`）が変数名を参照しているため **名前は変えず値だけを再定義** している。

| Token | Value | Use |
|-------|-------|-----|
| `--bg` / `--bg2` | `#070b14` / `#0b1120` | ミッドナイト基調の背景 |
| `--aqua` | `#5ee6ff` | 主アクセント（枠線グロー・強調テキスト） |
| `--violet` | `#9d7cff` | 副アクセント（グラデーション） |
| `--mint` | `#4ff0b5` | 第三アクセント（ポジティブ・勝ち表示） |
| `--glass` / `--glass-2` / `--glass-3` | `rgba(255,255,255,0.055 → 0.12)` | ガラス面の重ね（パネル / ボタン / ホバー） |
| `--glass-line` / `--glass-hi` | `rgba(255,255,255,0.16)` / `rgba(255,255,255,0.14)` | ガラスの縁・上面ハイライト |
| `--text` / `--muted` | `#eaf4ff` / `#8fa2c0` | 本文 / 補助テキスト |
| `--gold` / `--gold-bright` | アイスゴールド系 | ベット額・チップ表記（旧金アクセントの置換） |
| `--felt-rim` | `#7ce9ff` | テーブル外周のライトライン |
| `--red` / `--green` | `#ff5c7a` / `#3ff0a5` | フォールド・危険 / コール・成功 |
| カード色 | `--card-black/red/blue/green` | 4色スート表示 |

背景は多重 radial-gradient のオーロラメッシュ（左上アクア・右上バイオレット・下ミント）＋
グリッドノイズの薄いオーバーレイ（`body::before`、下方向にフェード）。

## Typography

- 見出し・UI: **Outfit** / **Sora**（+ `Noto Sans JP` で日本語）
- 数値・コード・チップ額: **JetBrains Mono**
- Google Fonts で `packages/web/index.html` から読み込む。
- 階層はサイズ＋ウェイト（700/800）＋トラッキングで付ける。装飾は縁の光のみ。

## Glass recipe

すべてのサーフェスで共通:

```css
background: linear-gradient(180deg, var(--glass-2), var(--glass));
backdrop-filter: blur(18px) saturate(160%);
border: 1px solid var(--glass-line);
box-shadow: 0 18px 50px rgba(0,0,0,0.45), inset 0 1px 0 var(--glass-hi);
border-radius: 16px;
```

- 角丸: パネル 16–20px / ボタン 12px / カード 8px / ピル 999px。
- カードは `::after` の斜めハイライトで光沢を出す。
- ポーカーテーブルはフェルトではなく、オーロラに照らされた半透明の楕円ガラス。
- モーション: 画面遷移は blur + fade（`.screen`）、種目チェンジは `#game-change-popout` のスケールイン。

## Structure

- 単一ページ（`/`）。`packages/web/src/web/pages/index.tsx` が
  `/mixpoker/body.html` を `document.body` に展開し、`game1–4.js` を順番に読み込んでから
  `DOMContentLoaded` を再送してゲームを起動する（既存のゲームロジックは無改変）。
- 画面: ロビー → 待機/ルーム → インゲーム（テーブル・アクションバー・ログ）→ リザルト → 成績。
- マルチプレイのルーム状態は既存の Firebase Realtime DB をそのまま利用。
