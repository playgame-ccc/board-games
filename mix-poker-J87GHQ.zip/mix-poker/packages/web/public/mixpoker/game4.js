
/* ================================================================
   PG共通アドオン v1（2026-07 追加）
   ゲーム本体のコードには手を入れず、後付けで動く独立モジュール。
   ① 切断検知: 15秒ごとに presence へ生存報告、40秒途絶で画面上部に表示
   ② 名前保存: 全ゲーム共通キー pgPlayerName で名前を自動入力
   ③ ルーム掃除: 24時間更新のないルームを削除（端末ごと6時間に1回）
   ④ 遊び方: ルール未搭載ゲームにモーダルを追加
   ================================================================ */
(function(){
'use strict';
var HB_MS=15000, WATCH_MS=10000, STALE_MS=40000;
var ROOM_TTL=24*60*60*1000, CLEAN_EVERY=6*60*60*1000;
var NAME_KEY='pgPlayerName';

function db(){
  try{ if(typeof FB_URL==='string' && FB_URL.indexOf('https://')===0) return FB_URL; }catch(e){}
  try{ if(typeof fbUrl==='string' && fbUrl.indexOf('https://')===0) return fbUrl; }catch(e){}
  return 'https://playgame-3e7ba-default-rtdb.firebaseio.com';
}
function room(){ try{ return (typeof fbRoom==='string') ? fbRoom : ''; }catch(e){ return ''; } }
function me(){ var id='',nm='';
  try{ if(typeof myId==='string') id=myId; }catch(e){}
  try{ if(typeof myName==='string') nm=myName; }catch(e){}
  return {id:id, name:nm};
}
function put(url,body){ try{ return fetch(url,{method:'PUT',body:JSON.stringify(body),keepalive:true}); }catch(e){ return null; } }

/* ========== 名前の共通保存・自動入力 ========== */
function initName(){
  var saved='';
  try{ saved = localStorage.getItem(NAME_KEY) || localStorage.getItem('spName') || ''; }catch(e){}
  ['in-name','my-name'].forEach(function(id){
    var el=document.getElementById(id); if(!el) return;
    if(saved && !el.value) el.value=saved;
    function save(){ var v=(el.value||'').trim(); if(v){ try{ localStorage.setItem(NAME_KEY,v); }catch(e){} } }
    el.addEventListener('change',save);
    el.addEventListener('blur',save);
  });
}

/* ========== 切断検知（ハートビート） ========== */
var lastRoom='';
function syncRoom(){
  var r=room(), m=me();
  if(r!==lastRoom){
    if(lastRoom && m.id){
      try{ fetch(db()+'/rooms/'+lastRoom+'/presence/'+m.id+'.json',{method:'DELETE',keepalive:true}); }catch(e){}
    }
    lastRoom=r;
  }
}
function beat(){
  syncRoom();
  var r=room(), m=me(); if(!r||!m.id) return;
  put(db()+'/rooms/'+r+'/presence/'+m.id+'.json',{t:Date.now(),n:m.name||'?'});
}
function markLeft(){
  syncRoom();
  var r=room(), m=me(); if(!r||!m.id) return;
  put(db()+'/rooms/'+r+'/presence/'+m.id+'.json',{t:Date.now(),n:m.name||'?',left:1});
}
var hideUntil=0;
function banner(txt){
  var b=document.getElementById('pga-banner');
  if(!txt || Date.now()<hideUntil){ if(b) b.style.display='none'; return; }
  if(!b){
    b=document.createElement('div'); b.id='pga-banner';
    b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:99990;background:rgba(178,34,34,.93);color:#fff;font-size:12px;line-height:1.4;padding:5px 30px 5px 10px;text-align:center;font-family:sans-serif;';
    var t=document.createElement('span'); t.id='pga-banner-text'; b.appendChild(t);
    var x=document.createElement('span'); x.textContent='\u2715';
    x.style.cssText='position:absolute;right:8px;top:4px;cursor:pointer;padding:0 4px;';
    x.onclick=function(){ hideUntil=Date.now()+60000; b.style.display='none'; };
    b.appendChild(x);
    document.body.appendChild(b);
  }
  document.getElementById('pga-banner-text').textContent=txt;
  b.style.display='block';
}
function watch(){
  syncRoom();
  var r=room(), m=me();
  if(!r){ banner(''); return; }
  fetch(db()+'/rooms/'+r+'/presence.json').then(function(res){ return res.json(); }).then(function(d){
    if(room()!==r) return;
    if(!d){ banner(''); return; }
    var now=Date.now(), gone=[];
    Object.keys(d).forEach(function(pid){
      if(pid===m.id) return;
      var p=d[pid]||{};
      if(p.left || (p.t && now-p.t>STALE_MS)) gone.push(p.n||'?');
    });
    banner(gone.length ? ('\u26A0\uFE0F \u901A\u4FE1\u304C\u9014\u5207\u308C\u3066\u3044\u307E\u3059: '+gone.join('\u3001')) : '');
  }).catch(function(){});
}
setInterval(beat,HB_MS); setTimeout(beat,1500);
setInterval(watch,WATCH_MS); setTimeout(watch,4000);
document.addEventListener('visibilitychange',function(){
  if(document.visibilityState==='visible'){ beat(); watch(); }
});
window.addEventListener('pagehide',markLeft);

/* ========== 古いルームの自動削除 ========== */
function tsOf(k,sub){
  return fetch(db()+'/rooms/'+k+'/'+sub+'.json').then(function(r){ return r.json(); }).catch(function(){ return null; });
}
async function cleanup(){
  try{
    var last=0; try{ last=+(localStorage.getItem('pgLastCleanup')||0); }catch(e){}
    if(Date.now()-last < CLEAN_EVERY) return;
    try{ localStorage.setItem('pgLastCleanup', String(Date.now())); }catch(e){}
    var res=await fetch(db()+'/rooms.json?shallow=true');
    var keys=await res.json(); if(!keys) return;
    var list=Object.keys(keys).filter(function(k){ return /^[A-Za-z0-9_]{1,6}-/.test(k) && k!==room(); });
    list.sort(function(){ return Math.random()-0.5; });
    var checked=0, deleted=0;
    for(var i=0;i<list.length;i++){
      if(checked>=80 || deleted>=25) break;
      var k=list[i]; checked++;
      var ts=0, v;
      v=await tsOf(k,'meta/ts');      if(typeof v==='number') ts=Math.max(ts,v);
      v=await tsOf(k,'broadcast/ts'); if(typeof v==='number') ts=Math.max(ts,v);
      v=await tsOf(k,'hostState/ts'); if(typeof v==='number') ts=Math.max(ts,v);
      v=await tsOf(k,'presence');
      if(v){ Object.keys(v).forEach(function(pid){ var t=v[pid]&&v[pid].t; if(typeof t==='number') ts=Math.max(ts,t); }); }
      if(!ts) continue; /* 時刻が取れないルームには触らない */
      if(Date.now()-ts > ROOM_TTL){
        try{ await fetch(db()+'/rooms/'+k+'.json',{method:'DELETE'}); deleted++; }catch(e){}
      }
    }
  }catch(e){}
}
setTimeout(cleanup,5000);

/* ========== 遊び方モーダル ========== */
var RULES=null;
function openRulesPga(){ var m=document.getElementById('pga-rules'); if(m) m.style.display='flex'; }
function closeRulesPga(){ var m=document.getElementById('pga-rules'); if(m) m.style.display='none'; }

/* ゲーム中でもルールを開けるボタン（ロビー/待機以外の画面で表示） */
function initFloatRules(){
  // 共通ルール文が無いゲームでは、そのゲーム自身のルール画面を開く
  var opener = RULES ? openRulesPga
    : (typeof window.openRules === 'function' ? window.openRules : null);
  if(!opener) return;
  var b = document.createElement('button');
  b.id = 'pga-rules-fab';
  b.type = 'button';
  b.textContent = '\uD83D\uDCD6';
  b.setAttribute('aria-label','ルール');
  b.style.cssText = 'position:fixed;right:10px;bottom:calc(10px + env(safe-area-inset-bottom));z-index:99989;width:40px;height:40px;'
    + 'border-radius:19px;border:1px solid rgba(255,255,255,.22);background:rgba(10,12,18,.78);'
    + 'color:#eaf4ff;font-size:17px;line-height:1;cursor:pointer;display:none;'
    + 'align-items:center;justify-content:center;padding:0;-webkit-tap-highlight-color:transparent;';
  b.onclick = opener;
  document.body.appendChild(b);
  // ロビー・待機・結果以外の画面にいるときだけ出す
  function upd(){
    try{
      // ロビー側の「遊び方」ボタンが見えているなら重複するので出さない
      var dup = false;
      var all = document.querySelectorAll('button');
      for(var i=0;i<all.length;i++){
        var el = all[i];
        if(el === b) continue;
        if(!/遊び方/.test(el.textContent||'')) continue;
        if(el.offsetParent !== null) { dup = true; break; }
      }
      var modalOpen = !!document.querySelector('#pga-rules[style*="flex"]');
      b.style.display = (dup || modalOpen) ? 'none' : 'inline-flex';
    }catch(e){}
  }
  setInterval(upd, 700);
  setTimeout(upd, 400);
}
function initRules(){
  if(!RULES) return;
  var m=document.createElement('div'); m.id='pga-rules';
  m.style.cssText='display:none;position:fixed;inset:0;z-index:99991;background:rgba(0,0,0,.72);align-items:center;justify-content:center;padding:14px;';
  m.innerHTML='<div style="background:linear-gradient(180deg,rgba(24,32,52,0.92),rgba(12,17,30,0.94));backdrop-filter:blur(22px) saturate(160%);-webkit-backdrop-filter:blur(22px) saturate(160%);border:1px solid rgba(255,255,255,0.14);box-shadow:0 24px 70px rgba(0,0,0,0.6),inset 0 1px 0 rgba(255,255,255,0.14);color:#eaf4ff;max-width:520px;width:100%;max-height:82vh;overflow-y:auto;border-radius:12px;padding:18px 16px;font-size:13.5px;line-height:1.75;font-family:sans-serif;-webkit-overflow-scrolling:touch;">'+RULES+'<button id="pga-rules-close" style="display:block;width:100%;margin-top:14px;padding:11px;border:1px solid rgba(255,255,255,0.18);border-radius:10px;background:linear-gradient(180deg,rgba(94,230,255,0.22),rgba(157,124,255,0.22));color:#eaf4ff;font-weight:700;backdrop-filter:blur(10px);font-size:14px;cursor:pointer;">\u9589\u3058\u308B</button></div>';
  m.addEventListener('click',function(ev){ if(ev.target===m) closeRulesPga(); });
  document.body.appendChild(m);
  document.getElementById('pga-rules-close').onclick=closeRulesPga;
  ['screen-lobby','screen-waiting'].forEach(function(id){
    var sc=document.getElementById(id); if(!sc) return;
    var btn=document.createElement('button');
    btn.type='button';
    btn.textContent='\uD83D\uDCD6 \u904A\u3073\u65B9';
    btn.style.cssText='display:block;width:100%;margin:10px 0 0;padding:11px;border:1px solid rgba(255,255,255,.28);border-radius:8px;background:rgba(255,255,255,.06);color:inherit;font-size:14px;cursor:pointer;';
    btn.onclick=openRulesPga;
    sc.appendChild(btn);
  });
}

initName();
initRules();
initFloatRules();
})();
