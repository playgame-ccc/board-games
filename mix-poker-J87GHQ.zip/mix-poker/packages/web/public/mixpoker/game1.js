
// ============================================================
// PLO 役判定エンジン（検証済み）
// ルール: 手札4枚から「ちょうど2枚」+ 場5枚から「ちょうど3枚」
// ============================================================
const HAND_RANK = { STRAIGHT_FLUSH:8, FOUR_KIND:7, FULL_HOUSE:6, FLUSH:5, STRAIGHT:4, THREE_KIND:3, TWO_PAIR:2, ONE_PAIR:1, HIGH_CARD:0 };
const HAND_NAME = { 8:'ストレートフラッシュ',7:'フォーカード',6:'フルハウス',5:'フラッシュ',4:'ストレート',3:'スリーカード',2:'ツーペア',1:'ワンペア',0:'ハイカード' };

// ランク数値→表示文字（A/K/Q/J/T/9...）。役名整形でも使う（rankStrは後方で定義されるため独立版）
function rkStr(r){ return ({14:'A',13:'K',12:'Q',11:'J',10:'T'})[r] || String(r); }

// HTML特殊文字をエスケープ（XSS対策）。innerHTMLに名前・ログを入れる前に必ず通す
function esc(s){
  return String(s==null?'':s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

// [0,n) の一様乱数。暗号論的乱数があれば使い、無ければMath.randomにフォールバック
// 剰余バイアスを避けるため棄却サンプリングを使う
function secureRand(n){
  if(n<=0) return 0;
  if(typeof crypto!=='undefined' && crypto.getRandomValues){
    const max = Math.floor(0x100000000 / n) * n;
    const buf = new Uint32Array(1);
    let x;
    do { crypto.getRandomValues(buf); x = buf[0]; } while(x >= max);
    return x % n;
  }
  return Math.floor(Math.random()*n);
}

// 役名を具体的にする。rank=役の種類, tb=tiebreak配列（構成ランク）
// 例: ワンペア→「ワンペア(K)」, ツーペア→「ツーペア K・7」, フルハウス→「フルハウス K over 7」
function handDetail(rank, tb){
  const base = HAND_NAME[rank];
  if(!tb || !tb.length) return base;
  switch(rank){
    case 8: // ストレートフラッシュ
      return tb[0]===14 ? 'ロイヤルフラッシュ' : `ストレートフラッシュ(${rkStr(tb[0])}ハイ)`;
    case 7: // フォーカード
      return `フォーカード(${rkStr(tb[0])})`;
    case 6: // フルハウス（tb=[3枚のランク, 2枚のランク]）
      return `フルハウス(${rkStr(tb[0])} over ${rkStr(tb[1])})`;
    case 5: // フラッシュ（tb=5枚のランク降順）
      return `フラッシュ(${rkStr(tb[0])}ハイ)`;
    case 4: // ストレート
      return `ストレート(${rkStr(tb[0])}ハイ)`;
    case 3: // スリーカード
      return `スリーカード(${rkStr(tb[0])})`;
    case 2: // ツーペア（tb=[高ペア, 低ペア, キッカー]）
      return `ツーペア(${rkStr(tb[0])}・${rkStr(tb[1])})`;
    case 1: // ワンペア
      return `ワンペア(${rkStr(tb[0])})`;
    case 0: // ハイカード
      return `ハイカード(${rkStr(tb[0])})`;
    default: return base;
  }
}

function combinations(arr, k){
  const result = [];
  (function helper(start, combo){
    if(combo.length === k){ result.push(combo.slice()); return; }
    for(let i=start; i<arr.length; i++){ combo.push(arr[i]); helper(i+1, combo); combo.pop(); }
  })(0, []);
  return result;
}
function eval5(cards){
  const ranks = cards.map(c=>c.r).sort((a,b)=>b-a);
  const suits = cards.map(c=>c.s);
  const isFlush = suits.every(s=>s===suits[0]);
  const uniqueRanks = [...new Set(ranks)].sort((a,b)=>b-a);
  let isStraight=false, straightHigh=0;
  if(uniqueRanks.length===5){
    if(uniqueRanks[0]-uniqueRanks[4]===4){ isStraight=true; straightHigh=uniqueRanks[0]; }
    else if(uniqueRanks[0]===14 && uniqueRanks[1]===5 && uniqueRanks[2]===4 && uniqueRanks[3]===3 && uniqueRanks[4]===2){ isStraight=true; straightHigh=5; }
  }
  const counts={}; ranks.forEach(r=>counts[r]=(counts[r]||0)+1);
  const groups = Object.entries(counts).map(([r,c])=>({r:parseInt(r),c})).sort((a,b)=> b.c!==a.c ? b.c-a.c : b.r-a.r);
  if(isStraight && isFlush) return [HAND_RANK.STRAIGHT_FLUSH, [straightHigh]];
  if(groups[0].c===4) return [HAND_RANK.FOUR_KIND, [groups[0].r, groups[1].r]];
  if(groups[0].c===3 && groups[1].c===2) return [HAND_RANK.FULL_HOUSE, [groups[0].r, groups[1].r]];
  if(isFlush) return [HAND_RANK.FLUSH, ranks];
  if(isStraight) return [HAND_RANK.STRAIGHT, [straightHigh]];
  if(groups[0].c===3){ const k=groups.slice(1).map(g=>g.r).sort((a,b)=>b-a); return [HAND_RANK.THREE_KIND, [groups[0].r, ...k]]; }
  if(groups[0].c===2 && groups[1].c===2){
    const ph=Math.max(groups[0].r,groups[1].r), pl=Math.min(groups[0].r,groups[1].r);
    return [HAND_RANK.TWO_PAIR, [ph, pl, groups[2].r]];
  }
  if(groups[0].c===2){ const k=groups.slice(1).map(g=>g.r).sort((a,b)=>b-a); return [HAND_RANK.ONE_PAIR, [groups[0].r, ...k]]; }
  return [HAND_RANK.HIGH_CARD, ranks];
}
function compareEval(a,b){
  if(a[0]!==b[0]) return a[0]-b[0];
  const ta=a[1], tb=b[1];
  for(let i=0;i<Math.max(ta.length,tb.length);i++){ const va=ta[i]||0, vb=tb[i]||0; if(va!==vb) return va-vb; }
  return 0;
}
function evalPLO(hole, board){
  if(hole.length!==4) throw new Error('手札4枚必要');
  if(board.length<3) return null;
  const holePairs = combinations(hole,2);
  const boardTriples = combinations(board,3);
  let best=null;
  for(const hp of holePairs) for(const bt of boardTriples){
    const ev = eval5([...hp, ...bt]);
    if(best===null || compareEval(ev, best.ev)>0) best={ev, cards:[...hp,...bt]};
  }
  return { rank:best.ev[0], tiebreak:best.ev[1], name:HAND_NAME[best.ev[0]], detail:handDetail(best.ev[0],best.ev[1]), cards:best.cards };
}

// ============================================================
// MIX: 種目定義（全10種）
// ============================================================
// type: 'community'(場札共有) / 'draw'(ドロー) / 'stud'(スタッド)
// holeN: 配る手札枚数, boardN: コミュニティカード枚数
// hi/lo: ハイ/ロー判定, plo: 手札ちょうど2枚ルール
// evalType: 役判定の種類（hi/a5lo/lo8/deuce27/badugi）
// drawRounds: ドロー回数（draw種目）
const MIX_GAMES = {
  // --- コミュニティ系（場札共有） ---
  holdem: { label:"テキサスホールデム", short:'NLH', type:'community', betting:'nl', holeN:2, boardN:5, hi:true, lo:false, plo:false, evalHi:'hi' },
  superhi:{ label:"スーパーホールデム",   short:'SUP', type:'community', betting:'nl', holeN:3, boardN:5, hi:true, lo:false, plo:false, superHi:true, evalHi:'superhi' },
  ocean:  { label:"オーシャン",            short:'OCN', type:'community', betting:'nl', holeN:2, boardN:6, hi:true, lo:false, plo:false, evalHi:'hi' },
  plo:    { label:"PLO（オマハ）",        short:'PLO', type:'community', betting:'pl', holeN:4, boardN:5, hi:true, lo:false, plo:true,  evalHi:'hi' },
  plo8:   { label:"PLO Hi-Lo (8b)",       short:'PLO8',type:'community', betting:'pl', holeN:4, boardN:5, hi:true, lo:true,  plo:true,  evalHi:'hi', evalLo:'lo8' },
  // --- ドロー系（場札なし、交換あり） ---
  a5:     { label:"A-5 トリプルドロー",   short:'A5',  type:'draw', betting:'fl', holeN:5, boardN:0, hi:false, lo:true,  plo:false, drawRounds:3, evalLo:'a5lo' },
  sd27:   { label:"2-7 シングルドロー",   short:'SD',  type:'draw', betting:'nl', holeN:5, boardN:0, hi:false, lo:true,  plo:false, drawRounds:1, evalLo:'deuce27' },
  td27:   { label:"2-7 トリプルドロー",   short:'TD',  type:'draw', betting:'fl', holeN:5, boardN:0, hi:false, lo:true,  plo:false, drawRounds:3, evalLo:'deuce27' },
  badugi: { label:"バドゥーギ",           short:'BAD', type:'draw', betting:'fl', holeN:4, boardN:0, hi:false, lo:true,  plo:false, drawRounds:3, evalLo:'badugi' },
  // --- スタッド系（場札なし、公開/非公開札） ---
  stud:   { label:"7カードスタッド",      short:'STD', type:'stud', betting:'fl', holeN:7, boardN:0, hi:true,  lo:false, plo:false, evalHi:'stud7' },
  studhi: { label:"スタッド Hi-Lo (8b)",  short:'ST8', type:'stud', betting:'fl', holeN:7, boardN:0, hi:true,  lo:true,  plo:false, evalHi:'stud7', evalLo:'stud7lo8' },
  razz:   { label:"ラズ",                 short:'RAZ', type:'stud', betting:'fl', holeN:7, boardN:0, hi:false, lo:true,  plo:false, evalLo:'razz' },
};
// 種目の表示順
const MIX_ORDER = ['holdem','superhi','ocean','plo','plo8','a5','sd27','td27','badugi','stud','studhi','razz'];


// ハイ役: ホールデム(任意5枚) or PLO(手札2+場3)
function evalHi(hole, board, isPlo){
  if(board.length<3) return null;
  if(isPlo){
    const hp=combinations(hole,2), bt=combinations(board,3);
    let best=null;
    for(const a of hp) for(const b of bt){ const ev=eval5([...a,...b]); if(!best||compareEval(ev,best.ev)>0) best={ev,cards:[...a,...b]}; }
    return best ? {rank:best.ev[0], tiebreak:best.ev[1], name:HAND_NAME[best.ev[0]], detail:handDetail(best.ev[0],best.ev[1]), cards:best.cards} : null;
  } else {
    const all=[...hole,...board];
    if(all.length<5) return null;
    let best=null;
    for(const c of combinations(all,5)){ const ev=eval5(c); if(!best||compareEval(ev,best.ev)>0) best={ev,cards:c}; }
    return best ? {rank:best.ev[0], tiebreak:best.ev[1], name:HAND_NAME[best.ev[0]], detail:handDetail(best.ev[0],best.ev[1]), cards:best.cards} : null;
  }
}
// スーパーホールデム: 3枚のホールから1〜3枚 + 場札を組み合わせて最強5枚。
// ボードプレイ不可（最低1枚はホールカードを使う）。
function evalSuperHi(hole, board){
  if(board.length < 2) return null; // 5枚を構成できる最低条件（hole3+board2）
  let best=null;
  for(let k=1; k<=3; k++){            // 使うホール枚数
    const need = 5 - k;              // 必要な場札枚数
    if(hole.length < k || board.length < need) continue;
    const hs = combinations(hole, k);
    const bs = combinations(board, need);
    for(const hc of hs) for(const bc of bs){
      const ev = eval5([...hc, ...bc]);
      if(!best || compareEval(ev, best.ev) > 0) best = {ev, cards:[...hc, ...bc]};
    }
  }
  return best ? {rank:best.ev[0], tiebreak:best.ev[1], name:HAND_NAME[best.ev[0]], detail:handDetail(best.ev[0],best.ev[1]), cards:best.cards} : null;
}

// ロー役(A-5, 8 or better)。役が成立しなければ null
// カードのrankは2-14(A=14)。ローではAは1扱い。8以下(A,2,3,4,5,6,7,8)のみ、5枚すべて異なる数字
// 戻り値: {loRanks:[降順の5枚], tiebreak} 小さいほど強い
function loValue(cards5){
  // Aを1として、各カードのlow値
  const vals = cards5.map(c=> c.r===14 ? 1 : c.r);
  // 8 or better: 全て8以下
  if(vals.some(v=>v>8)) return null;
  // ペア不可（ローは5枚異なる数字）
  if(new Set(vals).size !== 5) return null;
  const sorted = [...vals].sort((a,b)=>b-a); // 降順（比較用、最大が小さいほど強い）
  return sorted;
}
function compareLo(a, b){
  // a,b: loValueの戻り（降順配列）。小さい方が強い。戻り: aが強ければ-1
  for(let i=0;i<5;i++){ if(a[i]!==b[i]) return a[i]-b[i]; }
  return 0;
}
function evalLo(hole, board, isPlo){
  if(board.length<3) return null;
  let combos5=[];
  if(isPlo){
    const hp=combinations(hole,2), bt=combinations(board,3);
    for(const a of hp) for(const b of bt) combos5.push([...a,...b]);
  } else {
    const all=[...hole,...board];
    if(all.length<5) return null;
    combos5 = combinations(all,5);
  }
  let best=null;
  for(const five of combos5){
    const lv = loValue(five);
    if(!lv) continue;
    if(!best || compareLo(lv, best.lo)<0) best={lo:lv, cards:five};
  }
  return best ? {lo:best.lo, cards:best.cards} : null;
}

// ============================================================
// ドロー系・スタッド系 役判定エンジン（手札のみで判定）
// カード形式 {r:2-14(A=14), s:'c/d/h/s'}
// ============================================================

// --- A-5 ローボール: ストレート・フラッシュ無視、Aは最小。5枚で最も低い組み合わせが強い ---
// 役の強さは「降順5枚」を比較、小さいほど強い（ペアは弱い）
function eval5_a5(cards5){
  // Aを1扱い
  const vals = cards5.map(c=> c.r===14 ? 1 : c.r);
  const fr={}; vals.forEach(v=>fr[v]=(fr[v]||0)+1);
  const groups = Object.entries(fr).map(([v,n])=>[+v,n]).sort((a,b)=>b[1]-a[1]||b[0]-a[0]);
  const counts = groups.map(g=>g[1]);
  // ローボール: ペアなしが最強。役の段階を返す（小さいほど強い）
  // [tier, ...tiebreak] tier: 0=ノーペア, 1=ワンペア, 2=ツーペア, 3=トリップス, ...
  let tier;
  if(counts[0]===4) tier=5;
  else if(counts[0]===3&&counts[1]===2) tier=4;
  else if(counts[0]===3) tier=3;
  else if(counts[0]===2&&counts[1]===2) tier=2;
  else if(counts[0]===2) tier=1;
  else tier=0;
  // tiebreak: 各グループの値（多い順→値の降順）
  const tb = [];
  groups.forEach(([v,n])=>{ for(let i=0;i<n;i++) tb.push(v); });
  tb.sort((a,b)=>b-a); // 降順
  return [tier, ...tb];
}
// A-5: 7枚等から最良5枚（最も低い）
function bestA5Lo(cards){
  if(cards.length<5) return null;
  let best=null;
  for(const c of combinations(cards,5)){
    const s = eval5_a5(c);
    if(!best || cmpArr(s, best.s)<0) best={s, cards:c};
  }
  return best ? {score:best.s, cards:best.cards} : null;
}

// --- 2-7 ローボール: ストレート・フラッシュは「悪い役」、Aは最大。低いほど強い ---
function eval5_27(cards5){
  const rk = cards5.map(c=>c.r).sort((a,b)=>b-a);
  const fl = cards5.every(c=>c.s===cards5[0].s);
  const fr={}; rk.forEach(r=>fr[r]=(fr[r]||0)+1);
  const groups = Object.entries(fr).map(([r,n])=>[+r,n]).sort((a,b)=>b[1]-a[1]||b[0]-a[0]);
  const counts = groups.map(g=>g[1]);
  const st = new Set(rk).size===5 && (rk[0]-rk[4]===4);
  let tier;
  // 2-7では Aは常に高い（14）。ストレート・フラッシュは成立すると「高い＝弱い」
  if(fl && st) tier=8;
  else if(counts[0]===4) tier=7;
  else if(counts[0]===3&&counts[1]===2) tier=6;
  else if(fl) tier=5;
  else if(st) tier=4;
  else if(counts[0]===3) tier=3;
  else if(counts[0]===2&&counts[1]===2) tier=2;
  else if(counts[0]===2) tier=1;
  else tier=0;
  const tb=[];
  groups.forEach(([v,n])=>{ for(let i=0;i<n;i++) tb.push(v); });
  tb.sort((a,b)=>b-a);
  return [tier, ...tb];
}
function best27Lo(cards){
  if(cards.length<5) return null;
  let best=null;
  for(const c of combinations(cards,5)){
    const s = eval5_27(c);
    if(!best || cmpArr(s, best.s)<0) best={s, cards:c};
  }
  return best ? {score:best.s, cards:best.cards} : null;
}

// --- バドゥーギ: 異なるスート・異なる数字の枚数が多いほど強い。Aは最小 ---
// 4枚すべて異色異数（バドゥーギ）が最強
function badugiScore(cards){
  // 最良のバドゥーギ（異色異数の最大枚数、低い数字）を探す
  let best=null;
  for(let sz=Math.min(4,cards.length); sz>=1; sz--){
    let bestSz=null;
    for(const c of combinations(cards,sz)){
      // 異なる数字 かつ 異なるスート
      if(new Set(c.map(x=>x.r)).size!==sz) continue;
      if(new Set(c.map(x=>x.s)).size!==sz) continue;
      // スコア: 枚数が多い＝強い、数字は低い＝強い
      const vals = c.map(x=> x.r===14?1:x.r).sort((a,b)=>b-a); // 降順
      const s = [sz, ...vals.map(v=>-v)]; // 枚数大・値小が強い→比較用に符号調整
      if(!bestSz || cmpArr(s, bestSz.s)>0) bestSz={s, cards:c};
    }
    if(bestSz){ best=bestSz; break; }
  }
  return best ? {score:best.score||best.s, cards:best.cards, count:best.cards.length} : null;
}

// --- 配列比較: a<b なら負、a>b なら正 ---
function cmpArr(a,b){
  const n=Math.max(a.length,b.length);
  for(let i=0;i<n;i++){
    const x=a[i]??-Infinity, y=b[i]??-Infinity;
    if(x!==y) return x-y;
  }
  return 0;
}

// ハイ役: 任意の手札枚数から最強5枚
function bestHiFrom(cards){
  if(cards.length<5) return null;
  let best=null;
  for(const c of combinations(cards,5)){
    const ev = eval5(c);
    if(!best || compareEval(ev, best.ev)>0) best={ev, cards:c};
  }
  return best ? {rank:best.ev[0], tiebreak:best.ev[1], name:HAND_NAME[best.ev[0]], detail:handDetail(best.ev[0],best.ev[1]), cards:best.cards} : null;
}
// 8 or better ロー（スタッド用、7枚から）
function bestLo8From(cards, gameDef){
  // 8以下のカードを集めて5枚の最良ロー
  const q = cards.filter(c=> c.r===14 || c.r<=8);
  if(q.length<5) return null;
  let best=null;
  for(const c of combinations(q,5)){
    const lv = loValue(c);
    if(!lv) continue;
    if(!best || compareLo(lv, best.lo)<0) best={lo:lv, cards:c};
  }
  return best ? {lo:best.lo, cards:best.cards} : null;
}

// 種目対応ヘルパー（ホスト/ソロ用: G.currentGame を参照）
function evalHiCur(hole, board){
  const gd = MIX_GAMES[(typeof G!=='undefined' && G && G.currentGame) || 'holdem'] || MIX_GAMES.holdem;
  if(gd.type==='community'){ return gd.superHi ? evalSuperHi(hole, board) : evalHi(hole, board, gd.plo); }
  // 場札なし種目はhole7枚等から
  return bestHiFrom(hole);
}
// ドロー検出（コミュニティ系のフロップ/ターンで有効）。完成役未満の時に「あと1枚」を教える
// 返り値: 'フラッシュドロー' / 'ストレートドロー' / 'ガットショット' などの配列
function detectDraws(hole, board, isPlo, boardN){
  const draws = [];
  const target = boardN || 5;
  if(!board || board.length<3 || board.length>=target) return draws; // 場が完成したらドロー無し（オーシャンは6枚で完成）
  // PLOは手札ちょうど2枚ルールがあり判定が複雑なので、簡易にホール全体+ボードで見る
  const all = [...hole, ...board];
  // --- フラッシュドロー: 同じスートが4枚 ---
  const suitCount = {};
  all.forEach(c=> suitCount[c.s] = (suitCount[c.s]||0)+1 );
  // PLOは手札2枚しか使えないので、ホール内同スート2枚以上＋ボード同スート2枚が条件。簡易に4枚で判定
  if(Object.values(suitCount).some(n=> n===4)) draws.push('フラッシュドロー');
  // --- ストレートドロー: ユニークなランクの並びを調べる ---
  const rset = new Set();
  all.forEach(c=>{ rset.add(c.r); if(c.r===14) rset.add(1); }); // Aは1としても使う
  const rs = [...rset].sort((a,b)=>a-b);
  // 4連続（オープンエンド）か、5枚窓に4つ（ガットショット）かを判定
  let openEnd = false, gut = false;
  // 連続ラン長
  let run = 1, maxRun = 1;
  for(let i=1;i<rs.length;i++){
    if(rs[i]===rs[i-1]+1){ run++; maxRun = Math.max(maxRun, run); }
    else run = 1;
  }
  if(maxRun>=4) openEnd = true;
  if(!openEnd){
    // 5枚窓の中に4つランクがあればガットショット
    for(let lo=1; lo<=10; lo++){
      let cnt=0; for(let r=lo;r<lo+5;r++){ if(rset.has(r)) cnt++; }
      if(cnt===4){ gut = true; break; }
    }
  }
  if(openEnd) draws.push('ストレートドロー');
  else if(gut) draws.push('ガットショット');
  return draws;
}
// 種目対応ヘルパー（ゲスト用: ploPub.currentGame を参照）
function evalHiPub(hole, board){
  const gk = (typeof ploPub!=='undefined' && ploPub && ploPub.currentGame) || 'holdem';
  const gd = MIX_GAMES[gk] || MIX_GAMES.holdem;
  if(gd.type==='community'){ return gd.superHi ? evalSuperHi(hole, board) : evalHi(hole, board, gd.plo); }
  return bestHiFrom(hole);
}


// ============================================================
// ゲーム進行エンジン（検証済み）
// ============================================================
function makeDeck(){ const suits=['c','d','h','s']; const d=[]; for(let r=2;r<=14;r++) for(const s of suits) d.push({r,s}); return d; }
function shuffleDeck(a){ for(let i=a.length-1;i>0;i--){ const j=secureRand(i+1); [a[i],a[j]]=[a[j],a[i]]; } return a; }
function potLimitMaxRaiseTo(pot, toCall, myCurrentBet){ return myCurrentBet + toCall + (pot + toCall); }

// 山札から1枚引く。空なら捨て札をシャッフルして山札を再生成（ドロー系正式ルール）
function drawCard(h){
  if(h.deck.length === 0){
    if(h.discards && h.discards.length > 0){
      h.deck = shuffleDeck(h.discards.splice(0));
      G.log.unshift('♻️ 捨て札をシャッフルして山札を再生成');
    } else {
      // 山札・捨て札とも枯渇: 場に出ていないカードから再構築（重複を出さない）
      const used = new Set();
      (h.players||[]).forEach(p=>(p.hole||[]).forEach(c=>used.add(c.r+'_'+c.s)));
      (h.board||[]).forEach(c=>used.add(c.r+'_'+c.s));
      const fresh = makeDeck().filter(c=>!used.has(c.r+'_'+c.s));
      if(fresh.length===0) return null; // それでも無ければ諦める（呼び出し側でガード済み）
      console.warn('drawCard: 山札枯渇のため場外カードから再構築');
      h.deck = shuffleDeck(fresh);
    }
  }
  return h.deck.pop();
}

// フィックスリミットのベット単位（スモール or ビッグベット）
// スモール=BB、ビッグ=BB×2
// スタッド: 3rd/4th=スモール、5th以降=ビッグ
// ドロー系: 2回目ドロー前まで(drawDone<=1)=スモール、それ以降=ビッグ
function flBetUnit(h, gd){
  const small = h.bbAmount;
  const big = h.bbAmount * 2;
  if(gd.type==='stud'){
    return (h.studStreet||3) <= 4 ? small : big;
  }
  if(gd.type==='draw'){
    return (h.drawDone||0) <= 1 ? small : big;
  }
  return small;
}

// 種目のベッティング構造に応じた制限を返す
// 戻り値: {betting, minRaiseTo, maxRaiseTo, canRaise, flUnit}
function calcBetLimits(h, p){
  const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  const betting = gd.betting || 'pl';
  const toCall = h.highBet - p.roundBet;
  const pot = h.pot + h.players.reduce((s,pp)=>s+pp.roundBet,0);
  let minRaiseTo, maxRaiseTo, canRaise, flUnit=0;

  if(betting === 'fl'){
    // フィックスリミット: レイズ額固定、1ラウンド4ベットまで
    flUnit = flBetUnit(h, gd);
    const capped = (h.raiseCount||0) >= 4;
    // スタッド3rd: ブリングイン（最低額）に直面している場合のコンプリートは
    // 「スモールベットまで上げる」= highBet + flUnit ではなく flUnit に合わせる。
    const isBringInSpot = (gd.type==='stud') && (h.studStreet===3) && (h.highBet < flUnit);
    minRaiseTo = isBringInSpot ? flUnit : (h.highBet + flUnit);
    maxRaiseTo = minRaiseTo; // 固定
    canRaise = !capped && (p.stack > toCall) && (minRaiseTo - p.roundBet <= p.stack + toCall);
    // スタック不足でもオールイン分のレイズは認める（最小限）
    if(!capped && p.stack > toCall && minRaiseTo - p.roundBet > p.stack){
      minRaiseTo = p.roundBet + p.stack; maxRaiseTo = minRaiseTo;
      canRaise = minRaiseTo > h.highBet;
    }
  } else if(betting === 'nl'){
    // ノーリミット: 上限=スタック全部
    minRaiseTo = Math.min(h.highBet + Math.max(h.minRaise, h.bbAmount), p.roundBet + p.stack);
    maxRaiseTo = p.roundBet + p.stack;
    canRaise = (p.stack > toCall) && (maxRaiseTo > h.highBet);
  } else {
    // ポットリミット
    minRaiseTo = Math.min(h.highBet + h.bbAmount, p.roundBet + p.stack);
    maxRaiseTo = Math.min(potLimitMaxRaiseTo(pot, toCall, p.roundBet), p.roundBet + p.stack);
    canRaise = (p.stack > toCall) && (maxRaiseTo > h.highBet);
  }
  return {betting, minRaiseTo, maxRaiseTo, canRaise, flUnit, toCall, pot};
}

function buildPots(players){
  const contribs = players.map(p=>({id:p.id, bet:p.totalBet, folded:p.folded}));
  const pots=[];
  let remaining = contribs.filter(c=>c.bet>0);
  let carry = 0; // 勝てる人がいないレイヤーの死に金を有効ポットへ繰り入れる
  while(remaining.length>0){
    const minBet = Math.min(...remaining.map(c=>c.bet));
    let layer=0;
    remaining.forEach(c=>{ layer+=minBet; c.bet-=minBet; });
    const eligible = remaining.filter(c=>!c.folded).map(c=>c.id);
    if(layer>0){
      if(eligible.length===0){
        // このレイヤーの拠出者が全員フォールド → 直近の有効ポットへ。無ければ繰越
        if(pots.length>0) pots[pots.length-1].amount += layer;
        else carry += layer;
      } else {
        pots.push({amount: layer + carry, eligible});
        carry = 0;
      }
    }
    remaining = remaining.filter(c=>c.bet>0);
  }
  // 繰越が残った異常時は最初のポットへ寄せる（チップ総量を保つ）
  if(carry>0 && pots.length>0) pots[0].amount += carry;
  return pots;
}

// グローバル状態
let G = null;       // ゲーム状態
let myId = 'human';
let myName = 'あなた';
let soloPlayerCount = 3;
let soloStack = 1000;
let soloSB = 10, soloBB = 20;
let aiTimer = null;

// マルチプレイ
let isMulti = false;
let isHost = false;
let roomCode = '';
let ploPub = null;      // ゲストが受信する公開状態
let ploMyHole = [];     // 自分の手札（ゲスト用）
let ploMyFaceUp = [];   // 自分の手札の表/伏（スタッド・ゲスト用）
let waitingPlayers = []; // 待機中の参加者リスト（ホスト）
let pendingJoins = [];   // ゲーム中の途中参加待ち（次ハンドから参加）
// MIX 種目選択
let soloSelectedGame = 'holdem';  // ソロの種目
let hostSelectedGame = 'holdem';  // マルチの現在種目（ホストが切替）

// ===== 新機能の状態 =====
// CPU難易度（ロビー設定。ゲーム開始時に各CPUへプロファイル割当）
let cpuLevel = 'normal';   // 'easy' | 'normal' | 'hard'
// 種目ローテーション（ロビー設定）
let rotationMode = 'manual'; // 'manual' | 'horse' | '8game' | 'all'
let rotationEvery = 3;       // 何ハンドごとに切替（ローテーション時）
// WIN THE SHOW（ホスト設定）: 全員フォールド勝ちで勝者のカードを自動公開するか
let winTheShow = true;       // デフォルトON
// ハンド履歴・セッション収支（メモリ＋localStorage）
let sessionStats = null;     // 現在セッションの集計（startSolo/ploHostStartで初期化）
let handHistory = [];        // 直近ハンドの詳細（リプレイ用、最大200件）

function g(id){ return document.getElementById(id); }
function show(name){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  g('screen-'+name).classList.add('active');
  document.body.classList.toggle('ingame', name==='game');
}
// PLOリング風のヘッダーと手番バーを更新する
function plHeader(o){
  const hd=g('pl-hdr');
  if(hd) hd.innerHTML=[o.room, o.game?`<b>${o.game}</b>`:'', o.blind?`ブラインド <b>${o.blind}</b>`:'', o.extra||'']
    .filter(Boolean).join('／');
  const cg=g('pl-change'); if(cg) cg.style.display = o.canChange ? '' : 'none';
  const st=g('pl-street'); if(st) st.textContent = o.street||'';
  const tb=g('pl-turnbar');
  if(tb){ tb.textContent=o.turn||''; tb.className='pl-turnbar'+(o.myTurn?' me':''); }
}

// ===== ロビー設定 =====
function setPlayerCount(n){
  soloPlayerCount = n;
  document.querySelectorAll('#player-count .count-btn').forEach(b=>b.classList.toggle('selected', parseInt(b.dataset.n)===n));
  g('count-label').textContent = `あなた + CPU${n-1}人`;
}
function setStack(s){
  soloStack = s;
  document.querySelectorAll('#stack-select .count-btn').forEach(b=>b.classList.toggle('selected', parseInt(b.dataset.s)===s));
  if(gameFormat === 'tourney'){
    const st = TOURNEY_STRUCTURES[tourneyStructKey];
    const [sb,bb] = st.levels[0];
    soloSB = sb; soloBB = bb;
    g('blind-label').textContent = `開始 SB ${sb} / BB ${bb}（${Math.round(s/bb)}bb）`;
  } else {
    soloSB = 10; soloBB = 20;
    g('blind-label').textContent = `SB ${soloSB} / BB ${soloBB}（${Math.round(s / soloBB)}bb）`;
  }
}

// ===== ゲーム形式（リング / トーナメント） =====
let gameFormat = 'ring';
let tourneyLevelMin = 3;       // レガシー保持
let tourneyStructKey = 't30';  // 既定プリセット
function setGameFormat(m){
  gameFormat = m;
  document.querySelectorAll('#format-select .count-btn').forEach(b=>b.classList.toggle('selected', b.dataset.m===m));
  g('tourney-opts').style.display = m==='tourney' ? 'block' : 'none';
  if(m==='tourney'){
    setStruct(tourneyStructKey);
    setStack(soloStack); // ブラインド表示を更新
  } else {
    g('format-label').textContent = '通常のキャッシュゲーム（リバイあり）';
    setStack(soloStack);
  }
}
function setStruct(key){
  tourneyStructKey = key;
  const st = TOURNEY_STRUCTURES[key];
  document.querySelectorAll('#struct-select .count-btn').forEach(b=>b.classList.toggle('selected', b.dataset.st===key));
  const nLv = st.levels.length;
  const hasAnte = st.levels.some(l=>l[2]>0);
  const anteLv = st.levels.findIndex(l=>l[2]>0);
  const anteTxt = !hasAnte ? 'アンティなし'
    : (anteLv===0 ? 'BBアンティ最初から' : `BBアンティLv${anteLv+1}から`);
  g('struct-detail').textContent = `各レベル${st.minPerLevel}分・全${nLv}レベル・${anteTxt}`;
  g('format-label').textContent = `脱落制（リバイなし）・${st.label}`;
  if(g('blind-label')) setStack(soloStack);
}

// トーナメントのストラクチャープリセット（PDF準拠）
// 各レベル [SB, BB, アンティ(0=なし), このレベルの分数]
const TOURNEY_STRUCTURES = {
  t15: { label:'15分（ハイパーターボ）', minPerLevel:2, levels:[
    [50,100,100],[100,200,200],[150,300,300],[300,600,600],
    [600,1200,1200],[1200,2500,2500],[2000,4000,4000],[4000,8000,8000] ]},
  t30: { label:'30分（ターボ）', minPerLevel:3, levels:[
    [50,100,100],[80,150,150],[120,250,250],[200,400,400],[400,800,800],
    [600,1200,1200],[1000,2000,2000],[1500,3000,3000],[2500,5000,5000],[4000,8000,8000] ]},
  t60: { label:'60分（標準ターボ）', minPerLevel:5, levels:[
    [50,100,0],[80,150,0],[100,200,0],[150,300,300],[250,500,500],[400,800,800],
    [500,1000,1000],[800,1500,1500],[1200,2500,2500],[2000,4000,4000],[2500,5000,5000],[4000,8000,8000] ]},
  t90: { label:'90分（標準）', minPerLevel:6, levels:[
    [50,100,0],[80,150,0],[100,200,0],[120,250,250],[150,300,300],[250,500,500],
    [300,600,600],[400,800,800],[600,1200,1200],[800,1500,1500],[1200,2500,2500],
    [1500,3000,3000],[2000,4000,4000],[3000,6000,6000],[4000,8000,8000] ]},
};
// 後方互換: 旧levelMin指定（1/3/5分）の簡易ストラクチャを動的生成
const LEGACY_BLINDS = [[10,20],[15,30],[25,50],[40,80],[60,120],[100,200],[150,300],[250,500],[400,800],[600,1200],[1000,2000]];
function tourneyStruct(t){
  return (t.structKey && TOURNEY_STRUCTURES[t.structKey]) ? TOURNEY_STRUCTURES[t.structKey] : null;
}
function tourneyLevelInfo(t, lv){
  // [SB, BB, ante] を返す（レベル上限超過は最終レベルの倍々）
  const st = tourneyStruct(t);
  if(st){
    const L = st.levels;
    if(lv < L.length) return L[lv];
    const last = L[L.length-1];
    const mult = Math.pow(2, lv - L.length + 1);
    return [last[0]*mult, last[1]*mult, last[2]*mult];
  }
  // レガシー
  let blind;
  if(lv < LEGACY_BLINDS.length) blind = LEGACY_BLINDS[lv];
  else { const last=LEGACY_BLINDS[LEGACY_BLINDS.length-1]; const m=Math.pow(2,lv-LEGACY_BLINDS.length+1); blind=[last[0]*m,last[1]*m]; }
  return [blind[0], blind[1], blind[1]]; // レガシーはBBアンティ
}
function tourneyBlindsAt(t_or_lv, maybeLv){
  // 互換: 引数1個(数値)なら旧呼び出し（レガシーBB表）。2個ならtourneyLevelInfo相当
  if(typeof t_or_lv === 'number'){
    const lv = t_or_lv;
    if(lv < LEGACY_BLINDS.length) return LEGACY_BLINDS[lv];
    const last=LEGACY_BLINDS[LEGACY_BLINDS.length-1]; const m=Math.pow(2,lv-LEGACY_BLINDS.length+1); return [last[0]*m,last[1]*m];
  }
  const info = tourneyLevelInfo(t_or_lv, maybeLv);
  return [info[0], info[1]];
}
function tourneyAnteAt(t, lv){ return tourneyLevelInfo(t, lv)[2] || 0; }
function tourneyMinForLevel(t, lv){
  const st = tourneyStruct(t);
  return (st ? st.minPerLevel : (t.levelMin || 3));
}
function tourneyCurrentLevel(t){
  // 各レベルの分数が一定なので累積で算出（PDFは全レベル同一分数）
  const per = tourneyMinForLevel(t, 0);
  return Math.floor((Date.now() - t.startTs) / (per * 60000));
}

const CPU_NAMES = ['アル','ベラ','カイ','デフ','エコ','フィン','ジン','ハナ'];

// ===== CPU難易度 / ローテーション 設定 =====
function setCpuLevel(lv){
  cpuLevel = lv;
  document.querySelectorAll('#cpu-level-select .count-btn').forEach(b=>b.classList.toggle('selected', b.dataset.lv===lv));
  const txt = {
    easy:'ミスが多くブラフも単純。基礎練習向け',
    normal:'標準的な強さ。各CPUに個性（タイト/ルース/アグレ）がランダムに付きます',
    hard:'タイトかつGTO寄り。エクイティ計算とブラフ頻度が精密',
  };
  g('cpu-level-label').textContent = txt[lv];
}

// ローテーション順の定義
const ROTATION_SETS = {
  horse:  ['holdem','plo8','razz','stud','studhi'],          // H-O-R-S-E（OmahaはHi-Loを採用）
  '8game':['sd27','holdem','plo','razz','stud','studhi','plo8','a5'], // 8-Game Mix
  all:    MIX_ORDER.slice(),
};
const ROTATION_LABELS = {
  manual:'手動で種目を切り替えます（ゲーム中の変更ボタン）',
  horse: 'H→O8→Razz→Stud→Stud8 を順番に自動切替',
  '8game':'8種目を順番に自動切替',
  all:   '全10種を順番に自動切替',
};
function setRotationMode(m){
  rotationMode = m;
  document.querySelectorAll('#rotation-select .count-btn').forEach(b=>b.classList.toggle('selected', b.dataset.r===m));
  g('rotation-every-row').style.display = (m==='manual') ? 'none' : 'block';
  g('rotation-label').textContent = ROTATION_LABELS[m];
  // ローテーション選択時、開始種目をその先頭に合わせる
  if(m!=='manual'){
    const first = ROTATION_SETS[m][0];
    setInitGame(first);
  }
}
function setWinTheShow(on){
  winTheShow = !!on;
  document.querySelectorAll('#wts-select .count-btn').forEach(b=>b.classList.toggle('selected', (b.dataset.wts==='on')===winTheShow));
  const lbl = g('wts-label');
  if(lbl) lbl.textContent = winTheShow
    ? '全員フォールドで勝った人のカードを自動公開します'
    : '全員フォールド勝ちのカードは公開しません（通常ルール）';
}
function setRotationEvery(n){
  rotationEvery = n;
  document.querySelectorAll('#rotation-every-row .count-btn').forEach(b=>b.classList.toggle('selected', parseInt(b.dataset.re)===n));
}

// 続きは次のスクリプトブロックで
