
// ============================================================
// ソロゲーム本体（配牌・進行・CPU・描画）
// ============================================================

// ============================================================
// CPUプロファイル / ローテーション / セッション集計 ヘルパー
// ============================================================
// 各CPUに「難易度ベース＋個性」を持たせる。cpuDecideで参照。
//   eqShift: エクイティ閾値の下駄（+で弱気=タイト、-で強気=ルース）
//   bluffMul: ブラフ頻度倍率
//   raiseMul: バリューレイズ頻度倍率
//   err: ランダムミス確率（弱いCPUほど高い）
function buildCpuProfile(level){
  const styles = [
    {tag:'タイト',  eq:+0.04, bluff:0.6, raise:0.9},
    {tag:'ルース',  eq:-0.05, bluff:1.3, raise:1.1},
    {tag:'アグレ',  eq:-0.02, bluff:1.5, raise:1.4},
    {tag:'バランス',eq:0.0,   bluff:1.0, raise:1.0},
    {tag:'消極',    eq:+0.06, bluff:0.4, raise:0.6},
  ];
  // セルフプレイ10万ハンド級の総当たりで最も収支が高かったプロファイル＝
  // 「タイトアグレッシブ（やや絞る・ブラフ控えめ・バリューベット厚め）」を基準に採用。
  // hard=その最強形をそのまま、normal=やや緩めた版、easy=ルースで弱くミスもする。
  const base = {
    easy:   {eq:-0.04, bluff:1.35, raise:1.15, err:0.22}, // 緩く入ってミスもする（弱い）
    normal: {eq:+0.015,bluff:0.92, raise:1.15, err:0.05}, // 軽いTAG
    hard:   {eq:+0.02, bluff:0.85, raise:1.25, err:0.0},  // 検証で最強だったTAG（搾取されにくく価値を取る）
  }[level] || {eq:+0.015,bluff:0.92,raise:1.15,err:0.05};
  // hardは個性をかなり弱め（全員最強形に寄せる）、easy/normalは個性を残す
  // ※最強を求めるhardは個性ランダム性を排除し、検証済みの最適プロファイルで統一する
  const s = styles[Math.floor(Math.random()*styles.length)];
  const styleW = level==='hard' ? 0.0 : level==='normal' ? 0.6 : 1.0;
  const prof = {
    style: level==='hard' ? 'TAG' : s.tag,
    eqShift: base.eq + s.eq*styleW,
    bluffMul: base.bluff * (1 + (s.bluff-1)*styleW),
    raiseMul: base.raise * (1 + (s.raise-1)*styleW),
    err: base.err,
    tough: level==='hard', // hard: 対人で搾取されにくい厳しめ調整を有効化
  };
  return prof;
}
// G.ids 全員ぶんのプロファイルを生成（人間はnull）
// 注: マルチプレイは全員が人間プレイヤーのため、実際にプロファイルが付くのはソロのCPUのみ
function buildAllCpuProfiles(){
  const prof = {};
  G.ids.forEach(id=>{
    const isCpu = !isMulti && id !== 'human';
    prof[id] = isCpu ? buildCpuProfile(G.cpuLevel||'normal') : null;
  });
  return prof;
}
// ローテーション初期化（Gに保存）
function initRotation(){
  if(rotationMode==='manual'){ G.rotation = null; return; }
  G.rotation = { mode: rotationMode, every: rotationEvery, seq: ROTATION_SETS[rotationMode].slice(), idx: 0 };
  G.currentGame = G.rotation.seq[0];
  if(!isMulti) soloSelectedGame = G.currentGame;
  if(isMulti && isHost) hostSelectedGame = G.currentGame;
}
// 次ハンド開始時にローテーションを進める（startNewHand内、handNo++後に呼ぶ）
function advanceRotation(){
  if(!G || !G.rotation) return;
  const r = G.rotation;
  // handNoは1始まり。every手ごとに種目交代。
  // 例: every=3 なら hand 1-3=種目0, hand 4-6=種目1 …
  // → handNo>1 かつ (handNo-1)%every===0 のハンドで次へ
  if(G.handNo > 1 && (G.handNo - 1) % r.every === 0){
    r.idx = (r.idx + 1) % r.seq.length;
    const gk = r.seq[r.idx];
    G.currentGame = gk;
    if(!isMulti) soloSelectedGame = gk;
    if(isMulti && isHost) hostSelectedGame = gk;
    G.log.unshift(`🔄 ローテーション: 「${MIX_GAMES[gk].label}」へ`);
  }
}

// ===== 種目チェンジ ポップアウト演出 =====
// 各種目の1行ルール説明（ポップアウトに表示）
const GAME_RULE_BLURB = {
  holdem: '2枚の手札＋場の5枚で最強の5枚',
  plo:    '4枚のうち2枚＋場の3枚を必ず使う',
  plo8:   'ハイとロー(8以下)でポット折半',
  a5:     '3回ドローで最も低い手（A-5・ストフラ無視）',
  sd27:   '5枚で最も低い手（2-7・ストレート/フラッシュは不利）',
  td27:   '3回ドローで最も低い手（2-7）',
  badugi: '異なるスート・ランク4枚で最も低い手',
  stud:   '7枚から最強の5枚（コミュニティなし）',
  studhi: 'ハイとロー(8以下)でポット折半（スタッド）',
  razz:   '7枚から最も低い手（A-5）',
};
let gcpTimer = null;
function showGameChangePopout(gameKey){
  const el = g('game-change-popout');
  if(!el) return;
  const gd = MIX_GAMES[gameKey];
  if(!gd) return;
  g('gcp-name').textContent = gd.label;
  g('gcp-short').textContent = gd.short;
  g('gcp-rule').textContent = GAME_RULE_BLURB[gameKey] || '';
  // 再生のためアニメーションを一旦リセット
  el.classList.remove('show');
  void el.offsetWidth; // reflowで強制リセット
  el.classList.add('show');
  if(gcpTimer) clearTimeout(gcpTimer);
  gcpTimer = setTimeout(()=>{ el.classList.remove('show'); }, 1850);
}

// ===== セッション集計（ハンド履歴・収支） =====
const STATS_LS_KEY = 'mixpoker_stats_v1';
function loadPersistStats(){
  try { const raw = localStorage.getItem(STATS_LS_KEY); return raw ? JSON.parse(raw) : null; } catch(e){ return null; }
}
function savePersistStats(obj){
  try { localStorage.setItem(STATS_LS_KEY, JSON.stringify(obj)); } catch(e){}
}
// セッション開始時に初期化
function initSession(mode){
  sessionStats = {
    startTs: Date.now(),
    mode, // 'solo' | 'multi'
    hands: 0,
    net: 0,                 // 自分の通算収支（チップ）
    byGame: {},             // gameKey -> {hands, net, bbSum}
    bb: soloBB || 20,
  };
}
// ハンド確定時に自分の収支を記録（logHandPnlからフック）
function recordHandResult(h){
  if(!sessionStats) return;
  const me = h.players.find(p=>p.id===myId);
  if(!me) return;
  const delta = (me.stack||0) - (me.startStack||0);
  const gk = G.currentGame || 'holdem';
  const bb = h.bbAmount || sessionStats.bb || 20;
  sessionStats.hands++;
  sessionStats.net += delta;
  const bg = sessionStats.byGame[gk] || (sessionStats.byGame[gk] = {hands:0, net:0, bbSum:0});
  bg.hands++; bg.net += delta; bg.bbSum += delta / bb;
  // 履歴（リプレイ用・軽量）
  handHistory.unshift({
    ts: Date.now(),
    game: gk,
    gameLabel: MIX_GAMES[gk]?.label || gk,
    handNo: G.handNo,
    delta,
    bb,
    myCards: (me.hole||[]).map(c=>rankStr(c.r)+SUIT_SYM[c.s]),
    board: (h.board||[]).map(c=>rankStr(c.r)+SUIT_SYM[c.s]),
    myHandName: (h.handNames && h.handNames[me.id]) || '',
    won: delta>0,
    results: (h.results||[]).map(r=>({names:r.winnerNames, amount:r.amount})),
  });
  if(handHistory.length>200) handHistory.length=200;
  // localStorageへ通算を加算保存
  const persist = loadPersistStats() || {lifetimeHands:0, lifetimeNet:0, byGame:{}};
  persist.lifetimeHands = (persist.lifetimeHands||0) + 1;
  persist.lifetimeNet = (persist.lifetimeNet||0) + delta;
  const pg = persist.byGame[gk] || (persist.byGame[gk] = {hands:0, net:0, bbSum:0});
  pg.hands++; pg.net += delta; pg.bbSum += delta / bb;
  savePersistStats(persist);
}

// ===== 成績画面 =====
let statsReturnScreen = 'lobby'; // 戻る先（ゲーム中に開いた場合はgame）
function openStatsScreen(){
  // 現在アクティブな画面を記録（ロビー or ゲーム）
  const active = document.querySelector('.screen.active');
  statsReturnScreen = (active && active.id==='screen-game') ? 'game' : 'lobby';
  renderStatsScreen();
  show('stats');
}
function closeStatsScreen(){ show(statsReturnScreen); }

function fmtSigned(n){ return n>0?'+'+n.toLocaleString():(n<0?n.toLocaleString():'±0'); }

function renderStatsScreen(){
  // --- セッション ---
  const sBody = g('stats-session-body');
  if(sessionStats && sessionStats.hands>0){
    const mins = Math.max(1, Math.round((Date.now()-sessionStats.startTs)/60000));
    const bbTotal = (sessionStats.net / (sessionStats.bb||20));
    const per100 = sessionStats.hands>0 ? (bbTotal/sessionStats.hands*100) : 0;
    const cls = sessionStats.net>0?'pnl-plus':(sessionStats.net<0?'pnl-minus':'pnl-zero');
    sBody.innerHTML = `
      <div style="display:flex; justify-content:center; gap:18px; flex-wrap:wrap; font-family:'Share Tech Mono',monospace;">
        <div><div class="muted" style="font-size:0.66rem;">ハンド数</div><div style="font-size:1.1rem; font-weight:700;">${sessionStats.hands}</div></div>
        <div><div class="muted" style="font-size:0.66rem;">収支</div><div style="font-size:1.1rem; font-weight:700;" class="${sessionStats.net>0?'':''}"><span class="${cls}" style="padding:1px 10px; border-radius:10px;">${fmtSigned(sessionStats.net)}</span></div></div>
        <div><div class="muted" style="font-size:0.66rem;">bb/100</div><div style="font-size:1.1rem; font-weight:700; color:${per100>=0?'var(--green-dim)':'var(--red)'};">${per100>=0?'+':''}${per100.toFixed(1)}</div></div>
        <div><div class="muted" style="font-size:0.66rem;">経過</div><div style="font-size:1.1rem; font-weight:700;">${mins}分</div></div>
      </div>`;
  } else {
    sBody.innerHTML = 'まだプレイしていません';
  }

  // --- ゲーム別 bb/100（通算）---
  renderStatsChart();

  // --- 履歴 ---
  renderStatsHistory();
}

function renderStatsChart(){
  const persist = loadPersistStats();
  const chart = g('stats-chart');
  if(!persist || !persist.byGame || Object.keys(persist.byGame).length===0){
    chart.innerHTML = '<div class="center muted small">まだ記録がありません</div>';
    return;
  }
  // MIX_ORDER順で、記録のある種目だけ表示
  const rows = MIX_ORDER.filter(gk=>persist.byGame[gk] && persist.byGame[gk].hands>0).map(gk=>{
    const d = persist.byGame[gk];
    const per100 = d.hands>0 ? (d.bbSum/d.hands*100) : 0;
    return { gk, short:MIX_GAMES[gk].short, label:MIX_GAMES[gk].label, per100, hands:d.hands, net:d.net };
  });
  if(rows.length===0){ chart.innerHTML = '<div class="center muted small">まだ記録がありません</div>'; return; }
  // スケール（左右対称、0中央）
  const maxAbs = Math.max(10, ...rows.map(r=>Math.abs(r.per100)));
  chart.innerHTML = rows.map(r=>{
    const isPos = r.per100>=0;
    const w = Math.min(50, Math.abs(r.per100)/maxAbs*50); // 中央から最大50%
    const barColor = isPos?'var(--green)':'var(--red)';
    return `
      <div style="margin-bottom:10px;">
        <div style="display:flex; justify-content:space-between; font-size:0.72rem; margin-bottom:3px;">
          <span style="font-weight:700;">${r.label}</span>
          <span class="muted mono">${r.hands}手 ・ ${fmtSigned(r.net)}</span>
        </div>
        <div style="position:relative; height:18px; background:var(--bg); border-radius:5px; overflow:hidden;">
          <div style="position:absolute; left:50%; top:0; bottom:0; width:1px; background:var(--surface3);"></div>
          <div style="position:absolute; top:0; bottom:0; ${isPos?'left:50%':'right:50%'}; width:${w}%; background:${barColor}; border-radius:3px;"></div>
          <div style="position:absolute; ${isPos?'left:calc(50% + '+w+'% + 4px)':'right:calc(50% + '+w+'% + 4px)'}; top:0; bottom:0; display:flex; align-items:center; font-size:0.66rem; font-weight:700; font-family:'Share Tech Mono',monospace; color:${isPos?'var(--green-dim)':'var(--red)'}; white-space:nowrap;">
            ${isPos?'+':''}${r.per100.toFixed(0)}
          </div>
        </div>
      </div>`;
  }).join('') + `<div class="center muted small" style="margin-top:6px;">単位 bb/100（100ハンドあたりの獲得bb）</div>`;
}

function renderStatsHistory(){
  const cont = g('stats-history');
  if(!handHistory || handHistory.length===0){
    cont.innerHTML = '<div class="center muted small">このセッションの履歴はまだありません</div>';
    return;
  }
  cont.innerHTML = handHistory.slice(0,60).map((hh,i)=>{
    const cls = hh.delta>0?'pnl-plus':(hh.delta<0?'pnl-minus':'pnl-zero');
    const cards = hh.myCards.join(' ');
    const board = hh.board.length ? ` ・ 場 ${hh.board.join(' ')}` : '';
    return `
      <div style="display:flex; align-items:center; gap:8px; padding:7px 4px; border-bottom:1px solid var(--surface2);">
        <span style="font-size:0.6rem; background:var(--surface2); color:var(--muted); padding:1px 6px; border-radius:5px; font-weight:700; white-space:nowrap;">${hh.gameLabel.length>6?MIX_GAMES[hh.game].short:hh.gameLabel}</span>
        <span class="mono" style="flex:1; font-size:0.72rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${cards}${board}</span>
        <span class="${cls}" style="font-size:0.7rem; padding:1px 9px; border-radius:10px; font-family:'Share Tech Mono',monospace; white-space:nowrap;">${fmtSigned(hh.delta)}</span>
      </div>`;
  }).join('');
}

function clearAllStats(){
  if(!confirm('保存された通算成績をすべて消去します。よろしいですか？')) return;
  try { localStorage.removeItem(STATS_LS_KEY); } catch(e){}
  handHistory = [];
  renderStatsScreen();
}

// ゲスト用: 受信した公開状態から自分の収支を1ハンド1回だけ記録
let guestLastRecordedHand = -1;
function maybeRecordGuestHand(pub){
  if(!sessionStats) return;
  if(pub.phase!=='showdown' || !pub.results) return;
  const handNo = pub.handNo || 0;
  if(handNo===guestLastRecordedHand) return; // このハンドは記録済み
  const me = pub.players.find(p=>p.id===myId);
  if(!me || me.startStack==null) return;
  guestLastRecordedHand = handNo;
  const delta = (me.stack||0) - (me.startStack||0);
  const gk = pub.currentGame || 'holdem';
  const bb = pub.bbAmount || sessionStats.bb || 20;
  sessionStats.hands++;
  sessionStats.net += delta;
  const bg = sessionStats.byGame[gk] || (sessionStats.byGame[gk] = {hands:0, net:0, bbSum:0});
  bg.hands++; bg.net += delta; bg.bbSum += delta/bb;
  handHistory.unshift({
    ts: Date.now(), game: gk, gameLabel: MIX_GAMES[gk]?.label||gk, handNo,
    delta, bb,
    myCards: (me.hole||[]).map(c=>rankStr(c.r)+SUIT_SYM[c.s]),
    board: (pub.board||[]).map(c=>rankStr(c.r)+SUIT_SYM[c.s]),
    myHandName: (pub.handNames && pub.handNames[me.id])||'',
    won: delta>0,
    results: (pub.results||[]).map(r=>({names:r.winnerNames, amount:r.amount})),
  });
  if(handHistory.length>200) handHistory.length=200;
  const persist = loadPersistStats() || {lifetimeHands:0, lifetimeNet:0, byGame:{}};
  persist.lifetimeHands=(persist.lifetimeHands||0)+1;
  persist.lifetimeNet=(persist.lifetimeNet||0)+delta;
  const pg = persist.byGame[gk] || (persist.byGame[gk]={hands:0,net:0,bbSum:0});
  pg.hands++; pg.net+=delta; pg.bbSum+=delta/bb;
  savePersistStats(persist);
}

function startSolo(){
  const nameInput = g('my-name').value.trim();
  myName = nameInput || 'あなた';
  myId = 'human';

  // プレイヤー作成
  const ids = ['human'];
  const names = {human: myName};
  for(let i=0; i<soloPlayerCount-1; i++){
    ids.push('cpu'+i);
    names['cpu'+i] = CPU_NAMES[i];
  }
  const stacks = ids.map(()=>soloStack);

  G = {
    ids, names, stacks,
    buttonIdx: Math.floor(Math.random()*ids.length),
    handNo: 0,
    log: [],
    currentGame: soloSelectedGame || 'holdem',
    cpuLevel,
  };
  G.cpuProfiles = buildAllCpuProfiles();
  initRotation();
  initSession('solo');
  if(gameFormat === 'tourney'){
    G.tourney = {startTs: Date.now(), levelMin: tourneyLevelMin, structKey: tourneyStructKey, level: 0, ranks: {}};
    soloSB = 10; soloBB = 20;
    G.log.unshift(`🏆 トーナメント開始！ ${tourneyLevelMin}分ごとにブラインドアップ`);
  }
  show('game');
  startTourneyBar();
  startNewHand();
}

function startNewHand(){
  // 途中参加者を取り込み（次ハンドから = ここ）。トーナメント中は観戦のみ
  if(isMulti && isHost && pendingJoins.length){
    if(G.tourney){
      pendingJoins.forEach(j=>{ G.log.unshift(`👀 ${j.name} は観戦します（トーナメント進行中）`); });
      pendingJoins = [];
    } else {
      pendingJoins.forEach(j=>{
        if(G.ids.includes(j.id)) return;
        if(G.ids.length >= 8) return;
        G.ids.push(j.id);
        G.names[j.id] = j.name;
        G.stacks.push(soloStack);
        G.log.unshift(`✅ ${j.name} が参加しました（スタック${soloStack}）`);
      });
      pendingJoins = [];
    }
  }

  // トーナメント: 経過時間からブラインドレベルを更新（次のハンド=ここで適用）
  if(G.tourney){
    const lv = tourneyCurrentLevel(G.tourney);
    if(lv > G.tourney.level){
      G.tourney.level = lv;
      const [nsb, nbb] = tourneyBlindsAt(G.tourney, lv);
      const nante = tourneyAnteAt(G.tourney, lv);
      G.log.unshift(`📈 ブラインドアップ → Lv${lv+1}: ${nsb}/${nbb}${nante>0?` (アンティ${nante})`:''}`);
    }
    const [sb, bb] = tourneyBlindsAt(G.tourney, G.tourney.level);
    soloSB = sb; soloBB = bb;
    G.tourney.curAnte = tourneyAnteAt(G.tourney, G.tourney.level);
  }

  // スタックが残っている人だけ続行
  const alive = G.ids.filter((id,i)=>G.stacks[i] > 0);
  if(alive.length < 2){
    // ゲーム終了
    showFinalResult();
    return;
  }

  // 種目変更を適用（ホスト/ソロが手動で切り替えていた場合）
  const prevGame = G.currentGame;
  applyPendingGameChange();

  G.handNo++;
  // 種目ローテーション（HORSE/8-Game/全10種）を進める
  advanceRotation();
  // 種目が変わったら大きくポップアウト演出（ソロ/ホストの画面。ゲストはploPub受信時に表示）
  if(G.currentGame !== prevGame && G.handNo > 1){
    try { showGameChangePopout(G.currentGame); } catch(e){}
  }
  // ボタンを次へ（生存者の中で）
  // 単純化: 毎ハンド buttonIdx を +1（脱落者はスキップ）
  do {
    G.buttonIdx = (G.buttonIdx + 1) % G.ids.length;
  } while(G.stacks[G.buttonIdx] <= 0);

  // ハンド初期化
  const deck = shuffleDeck(makeDeck());
  const n = G.ids.length;
  const gameDef = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  const gd0 = gameDef;

  // プレイヤー作成（種目別の配り方）
  const players = G.ids.map((id, i) => ({
    id, name: G.names[id], idx: i,
    hole: [],
    faceUp: [],   // スタッド用: 各holeカードが表向きか
    stack: G.stacks[i],
    startStack: G.stacks[i], // ハンド開始時スタック（収支表示用）
    totalBet: 0, roundBet: 0,
    folded: G.stacks[i] <= 0,
    allIn: false, acted: false,
    isCpu: isMulti ? false : (id !== 'human'),
    lastAction: '',
    lastDraw: null, // 直近ドローの交換枚数（null=未ドロー）
  }));

  if(gameDef.type === 'stud'){
    // スタッド: 3rd street = 伏2 + 表1
    players.forEach(p=>{
      if(p.folded) return;
      p.hole = [deck.pop(), deck.pop(), deck.pop()];
      p.faceUp = [false, false, true]; // 3枚目だけ表
    });
  } else {
    // コミュニティ/ドロー: 規定枚数すべて配る（すべて伏せ＝自分のみ見える）
    const holeN = gameDef.holeN;
    players.forEach(p=>{
      if(p.folded) return;
      for(let k=0;k<holeN;k++) p.hole.push(deck.pop());
      p.faceUp = p.hole.map(()=>false);
    });
  }

  const aliveIdxs = players.map((p,i)=>i).filter(i=>!players[i].folded);

  let sbIdx=-1, bbIdx=-1, firstActor=-1, highBet=0;

  function postChips(idx, amt){
    const p = players[idx];
    const pay = Math.min(amt, p.stack);
    p.stack -= pay; p.roundBet += pay; p.totalBet += pay;
    if(p.stack===0) p.allIn = true;
    return pay;
  }

  if(gameDef.type === 'stud'){
    // アンティ全員拠出（BBの1/4目安、最低1）
    const ante = Math.max(1, Math.floor(soloBB/4));
    aliveIdxs.forEach(i=>{ postChips(i, ante); });
    // ブリングイン: 3rdの表札が最低(ラズは最高)のプレイヤー
    const isRazz = (G.currentGame === 'razz');
    let biIdx = aliveIdxs[0];
    let biBest = null;
    const suitOrder = {c:0,d:1,h:2,s:3};
    aliveIdxs.forEach(i=>{
      const up = players[i].hole[2];
      const val = up.r * 4 + suitOrder[up.s];
      if(biBest===null){ biBest=val; biIdx=i; }
      else if(isRazz ? val>biBest : val<biBest){ biBest=val; biIdx=i; }
    });
    // アンティをポットに移動
    let anteTotal = 0;
    players.forEach(p=>{ anteTotal += p.roundBet; p.roundBet=0; });
    // ブリングイン: 強制最低額を拠出。その後、ブリングインプレイヤー自身が
    // 「ブリングインのまま（=チェック扱い）」か「コンプリート（=スモールベットまでレイズ）」を選ぶ。
    const bringIn = Math.max(soloSB, Math.floor(soloBB/2));
    postChips(biIdx, bringIn);
    players[biIdx].acted = false; // 本人にアクション選択の番を与える
    highBet = bringIn;
    firstActor = biIdx; // ブリングイン者が最初に動く（コンプリート選択可）
    G.hand = {
      deck, players, board: [],
      pot: anteTotal, phase: 'preflop',
      sbIdx:-1, bbIdx:-1,
      highBet, minRaise: soloBB,
      bbAmount: soloBB,
      toActIdx: firstActor,
      results: null,
      gameType: gameDef.type,
      drawDone: 0, studStreet: 3, studVisible: 3, needDraw: false,
      discards: [], // 捨て札パイル（山札枯渇時のリシャッフル用）
      bringInIdx: biIdx,
      bringInPending: true, // ブリングイン者がまだコンプリート/継続を選んでいない
      raiseCount: 1, // ブリングインが1ベット目
    };
    G.log.unshift(`── ハンド #${G.handNo} (${gameDef.short}) ──`);
    G.log.unshift(`アンティ${ante} / ブリングイン: ${players[biIdx].name}`);
  } else {
    // コミュニティ/ドロー: ブラインド方式
    const btnPos = aliveIdxs.indexOf(G.buttonIdx);
    if(aliveIdxs.length === 2){
      sbIdx = G.buttonIdx;
      bbIdx = aliveIdxs[(btnPos+1)%2];
    } else {
      sbIdx = aliveIdxs[(btnPos+1)%aliveIdxs.length];
      bbIdx = aliveIdxs[(btnPos+2)%aliveIdxs.length];
    }
    postChips(sbIdx, soloSB);
    postChips(bbIdx, soloBB);
    // トーナメント: BBアンティ（プリセットのアンティ額。0のレベルはアンティなし）
    let anteToPot = 0;
    const anteAmt = (G.tourney && G.tourney.curAnte!=null) ? G.tourney.curAnte : (G.tourney ? soloBB : 0);
    if(G.tourney && anteAmt > 0){
      const bp = players[bbIdx];
      const beforeRB = bp.roundBet;
      postChips(bbIdx, anteAmt); // アンティ（スタック不足ならある分だけ）
      anteToPot = bp.roundBet - beforeRB;
      bp.roundBet = beforeRB;   // アンティはコール額に含めない（totalBetには残しサイドポット計算に反映）
      if(anteToPot > 0) G.log.unshift(`🪙 BBアンティ: ${bp.name} が ${anteToPot} をポスト`);
    }
    highBet = soloBB;
    G.hand = {
      deck, players, board: [],
      pot: anteToPot, phase: 'preflop',
      sbIdx, bbIdx,
      highBet, minRaise: soloBB,
      bbAmount: soloBB,
      toActIdx: -1,
      results: null,
      gameType: gameDef.type,
      drawDone: 0, studStreet: 3, studVisible: 3, needDraw: false,
      discards: [], // 捨て札パイル（山札枯渇時のリシャッフル用）
      raiseCount: 1, // BBが1ベット目
    };
    G.hand.toActIdx = nextActor(bbIdx);
    G.log.unshift(`── ハンド #${G.handNo} (${gameDef.short}) ──`);
  }

  render();
  scheduleNext();
}

function HND(){ return G.hand; }
function activePlayers(){ return HND().players.filter(p=>!p.folded && !p.allIn); }
function notFolded(){ return HND().players.filter(p=>!p.folded); }
function roundBetTotal(){ return HND().players.reduce((s,p)=>s+p.roundBet,0); }
function currentPot(){ return HND().pot + roundBetTotal(); }

function nextActor(fromIdx){
  return nextActorIn(HND().players, fromIdx);
}
// players配列を明示的に渡す版（G.hand設定前でも使える）
function nextActorIn(players, fromIdx){
  const n = players.length;
  for(let k=1; k<=n; k++){
    const idx = (fromIdx+k)%n;
    if(!players[idx].folded && !players[idx].allIn) return idx;
  }
  return -1;
}

function isRoundComplete(){
  if(notFolded().length <= 1) return true;
  const active = activePlayers();
  if(active.length === 0) return true;
  for(const p of active){
    if(!p.acted) return false;
    if(p.roundBet !== HND().highBet) return false;
  }
  return true;
}

function applyAction(playerIdx, action){
  const h = HND();
  if(!h || playerIdx < 0 || !h.players[playerIdx]) return;
  const p = h.players[playerIdx];
  if(p.folded || p.allIn) return;
  const toCall = h.highBet - p.roundBet;

  if(action.type === 'fold'){
    p.folded = true; p.acted = true; p.lastAction = 'フォールド';
    G.log.unshift(`${p.name}: フォールド`);
  } else if(action.type === 'check'){
    p.acted = true; p.lastAction = 'チェック';
    G.log.unshift(`${p.name}: チェック`);
  } else if(action.type === 'call'){
    const pay = Math.min(toCall, p.stack);
    p.stack -= pay; p.roundBet += pay; p.totalBet += pay;
    if(p.stack===0) p.allIn = true;
    p.acted = true; p.lastAction = p.allIn ? 'オールイン' : 'コール';
    G.log.unshift(`${p.name}: ${p.lastAction} (${pay})`);
  } else if(action.type === 'raise'){
    p.aggCnt = (p.aggCnt||0) + 1; // アグレッション履歴（レンジ推定用）
    // ベッティング構造に応じた額の検証・強制
    const limits = calcBetLimits(h, p);
    let to = action.amount;
    if(limits.betting === 'fl'){
      // FL: 額は固定。キャップ済みならコール扱い
      if(!limits.canRaise){
        const pay = Math.min(toCall, p.stack);
        p.stack -= pay; p.roundBet += pay; p.totalBet += pay;
        if(p.stack===0) p.allIn = true;
        p.acted = true; p.lastAction = p.allIn ? 'オールイン' : 'コール';
        G.log.unshift(`${p.name}: ${p.lastAction} (${pay})`);
        return;
      }
      to = limits.minRaiseTo; // 固定額に強制
    } else {
      // NL/PL: 範囲内にクランプ
      to = Math.max(limits.minRaiseTo, Math.min(limits.maxRaiseTo, to));
    }
    const need = to - p.roundBet;
    const isAllIn = (need >= p.stack);
    const actualNeed = Math.min(need, p.stack);
    p.stack -= actualNeed; p.roundBet += actualNeed; p.totalBet += actualNeed;
    const raiseBy = p.roundBet - h.highBet;
    if(p.stack===0) p.allIn = true;
    if(raiseBy >= h.minRaise) h.minRaise = raiseBy;
    if(p.roundBet > h.highBet){ h.highBet = p.roundBet; h.raiseCount = (h.raiseCount||0) + 1; }
    h.players.forEach((pp,i)=>{ if(i!==playerIdx && !pp.folded && !pp.allIn) pp.acted=false; });
    p.acted = true;
    p.lastAction = p.allIn ? 'オールイン' : (toCall>0?'レイズ':'ベット');
    G.log.unshift(`${p.name}: ${p.lastAction} → ${p.roundBet}`);
  }
  // スタッド3rd: ブリングイン者が動いたら選択完了フラグを下ろす
  if(h.bringInPending && playerIdx===h.bringInIdx){ h.bringInPending = false; }
}

// スタッド系: 表札（faceUpカード）の強さで各ストリートの先頭アクターを決める
// stud/studhi: 最強の表札がアクション開始。razz: 最弱（ベストロー）の表札が開始。
function studUpScore(p, isRazz){
  const ups = p.hole.filter((cd,i)=>p.faceUp[i]);
  const suitOrder = {c:0,d:1,h:2,s:3};
  // razzはA=1として低い方が強い
  const rv = cd => isRazz ? (cd.r===14?1:cd.r) : cd.r;
  const ranks = ups.map(rv).sort((a,b)=>b-a);
  const counts = {}; ranks.forEach(r=>counts[r]=(counts[r]||0)+1);
  const groups = Object.entries(counts).map(([r,cnt])=>({r:+r,cnt})).sort((a,b)=> b.cnt-a.cnt || b.r-a.r);
  let cat = 0;
  if(groups[0].cnt===4) cat=7;
  else if(groups[0].cnt===3) cat=3;
  else if(groups[0].cnt===2) cat=(groups[1]&&groups[1].cnt===2)?2:1;
  const tb = [];
  groups.forEach(gr=>{ for(let k=0;k<gr.cnt;k++) tb.push(gr.r); });
  // タイブレーク用に最高表札のスート（一意化）
  let topSuit = 0;
  ups.forEach(cd=>{ const v=rv(cd)*4+suitOrder[cd.s]; if(v>topSuit) topSuit=v; });
  return {cat, tb, topSuit};
}
function studCmpScore(a, b, isRazz){
  // 戻り値>0: aが先頭アクター候補として上
  if(isRazz){
    // razz: ローが良い（catが低い・ランクが低い）方が先頭
    if(a.cat !== b.cat) return b.cat - a.cat;
    for(let i=0;i<Math.max(a.tb.length,b.tb.length);i++){
      const av=a.tb[i]??99, bv=b.tb[i]??99;
      if(av!==bv) return bv - av;
    }
    return b.topSuit - a.topSuit;
  }
  // stud/studhi: ハイが強い方が先頭
  if(a.cat !== b.cat) return a.cat - b.cat;
  for(let i=0;i<Math.max(a.tb.length,b.tb.length);i++){
    const av=a.tb[i]??-1, bv=b.tb[i]??-1;
    if(av!==bv) return av - bv;
  }
  return a.topSuit - b.topSuit;
}
function studFirstActor(h){
  const isRazz = (G.currentGame === 'razz');
  let bestIdx = -1, bestScore = null;
  h.players.forEach((p,i)=>{
    if(p.folded) return;
    const sc = studUpScore(p, isRazz);
    if(bestScore===null || studCmpScore(sc, bestScore, isRazz) > 0){ bestScore = sc; bestIdx = i; }
  });
  if(bestIdx < 0) return h.toActIdx;
  // 先頭がオールイン済みなら次の有効アクターへ
  const bp = h.players[bestIdx];
  if(bp.allIn) return nextActor(bestIdx);
  return bestIdx;
}

function advancePhase(){
  const h = HND();
  h.pot += roundBetTotal();
  h.players.forEach(p=>{ p.roundBet=0; p.acted=false; p.lastAction=''; });
  h.highBet = 0; h.minRaise = h.bbAmount;
  h.raiseCount = 0; // FLのレイズ回数をリセット

  const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;

  if(gd.type==='community'){
    advancePhaseCommunity(h);
  } else if(gd.type==='draw'){
    advancePhaseDraw(h, gd);
  } else if(gd.type==='stud'){
    advancePhaseStud(h, gd);
  }

  if(h.phase!=='showdown'){
    // 次のアクター（種目で起点が違う）
    if(gd.type==='stud'){
      h.toActIdx = studFirstActor(h); // 表札の強さで先頭アクターを決定（razzは最弱表札）
      if(h.toActIdx>=0 && h.players[h.toActIdx]){
        const isRazzLog = (G.currentGame==='razz');
        G.log.unshift(`▶ 先頭: ${h.players[h.toActIdx].name}（表札${isRazzLog?'がベストロー':'が最強'}）`);
      }
    } else {
      h.toActIdx = nextActor(G.buttonIdx);
    }
  }
}

function advancePhaseCommunity(h){
  // 山札からボードへ1枚（枯渇時はundefinedを積まず警告）。通常プレイでは枯渇しないため挙動は不変
  const dealBoard = ()=>{ const c=h.deck.pop(); if(c) h.board.push(c); else console.warn('advancePhaseCommunity: 山札不足'); };
  const targetBoard = (MIX_GAMES[G.currentGame]||MIX_GAMES.holdem).boardN || 5;
  if(h.phase==='preflop'){ h.phase='flop'; dealBoard(); dealBoard(); dealBoard(); G.log.unshift('── フロップ ──'); }
  else if(h.phase==='flop'){ h.phase='turn'; dealBoard(); G.log.unshift('── ターン ──'); }
  else if(h.phase==='turn'){ h.phase='river'; dealBoard(); G.log.unshift('── リバー ──'); }
  else if(h.phase==='river'){ if(targetBoard>=6){ h.phase='ocean'; dealBoard(); G.log.unshift('── オーシャン ──'); } else { h.phase='showdown'; } }
  else if(h.phase==='ocean'){ h.phase='showdown'; }
}

// ドロー系: predraw(=preflop) → ベット → ドロー交換 → ベット → ... → showdown
function advancePhaseDraw(h, gd){
  const rounds = gd.drawRounds || 1;
  // h.drawDone: 完了したドロー回数
  if(h.drawDone === undefined) h.drawDone = 0;
  if(h.drawDone < rounds){
    // 次はドローフェーズ
    h.phase = 'draw';
    h.drawDone++;
    G.log.unshift(`── ドロー${h.drawDone} ──`);
    // カード交換はexecuteDraw()で行う（CPU自動 or 人間UI）
    h.needDraw = true;
  } else {
    h.phase = 'showdown';
  }
}

// スタッド系: 3rd→4th→5th→6th→7th→showdown（簡略: 各ストリート1枚追加）
function advancePhaseStud(h, gd){
  // h.studStreet: 現在のストリート（3から開始）
  if(h.studStreet === undefined) h.studStreet = 3;
  if(h.studStreet < 7){
    h.studStreet++;
    const faceUp = (h.studStreet < 7);
    const needers = h.players.filter(p=>!p.folded);
    if(h.deck.length < needers.length){
      // 山札不足（8人全員が7th到達時など）: コミュニティカード1枚を公開して全員共有（正式ルール）
      const c = h.deck.pop();
      if(c){
        h.board.push(c);
        h.studCommunity = true;
        G.log.unshift(`⚠️ 山札不足: 共有カードを公開（全員で使用）`);
      }
    } else {
      // 各生存プレイヤーに1枚配る。7thは伏せ、それ以外は表
      h.players.forEach(p=>{
        if(p.folded) return;
        const c = h.deck.pop();
        p.hole.push(c);
        p.faceUp.push(faceUp);
      });
    }
    G.log.unshift(`── ${h.studStreet}thストリート ──`);
    h.studVisible = h.studStreet;
  } else {
    h.phase = 'showdown';
  }
}

// スタッド: そのストリートで最初に動くプレイヤーの決定は studFirstActor（studUpScore使用）に一本化。
// （旧 studFirstToAct は未参照のため削除）

// スタッド系: プレイヤーの表札の強さ評価（studUpScoreで実装済み）

// 種目タイプ別のフェーズ表示名
// ポジションバッジ（BTN/SB/BB/UTG/.../HJ/CO）。スタッドはブリングインのみ
function posBadge(h, idx){
  const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  if(gd.type==='stud'){
    return idx === h.bringInIdx ? 'BI' : '';
  }
  if(idx === h.sbIdx) return 'SB';
  if(idx === h.bbIdx) return 'BB';
  if(idx === G.buttonIdx) return 'BTN';
  // BBの次からBTNの手前までを順に: UTG, UTG1..., HJ, CO
  const n = h.players.length;
  const order = [];
  let cur = h.bbIdx;
  for(let k=1; k<n; k++){
    const i = (h.bbIdx + k) % n;
    if(i === G.buttonIdx) break;
    if(h.players[i].stack > 0 || !h.players[i].folded) order.push(i);
    else order.push(i); // 配置自体は席順で固定
  }
  const m = order.length;
  const pos = order.indexOf(idx);
  if(pos < 0) return '';
  // 後ろから CO, HJ、先頭から UTG, UTG+1...
  if(m >= 1 && pos === m-1) return 'CO';
  if(m >= 2 && pos === m-2) return 'HJ';
  return pos === 0 ? 'UTG' : 'UTG+'+pos;
}

function phaseLabelFor(h, gameKey){
  const gd = MIX_GAMES[gameKey] || MIX_GAMES.holdem;
  if(h.phase==='showdown'){
    // 全員フォールドで決着した場合はSHOWDOWNではなく「ハンド終了」
    if(h.results && h.results[0] && h.results[0].uncontested) return 'ハンド終了';
    return 'SHOWDOWN';
  }
  if(gd.type==='community'){
    const m={preflop:'PREFLOP', flop:'FLOP', turn:'TURN', river:'RIVER', ocean:'OCEAN'};
    return m[h.phase] || '';
  }
  if(gd.type==='draw'){
    const done = h.drawDone||0;
    const total = gd.drawRounds||1;
    if(h.phase==='preflop') return '1st BET';
    if(h.phase==='draw') return `DRAW ${done}/${total}`;
    return `BET (${done}/${total})`;
  }
  if(gd.type==='stud'){
    const st = h.studStreet||3;
    const ord = {3:'3RD',4:'4TH',5:'5TH',6:'6TH',7:'7TH'}[st] || st+'TH';
    return `${ord} ST`;
  }
  return '';
}

// 最後のベッティングラウンドか判定
function isLastBettingRound(h, gd){
  if(gd.type==='community'){ return (gd.boardN||5)>=6 ? h.phase==='ocean' : h.phase==='river'; }
  if(gd.type==='draw'){
    return (h.drawDone||0) >= (gd.drawRounds||1);
  }
  if(gd.type==='stud'){
    return (h.studStreet||3) >= 7;
  }
  return false;
}

// ドロー実行: CPUは自動交換、人間は交換UI（callback で次へ）
function executeDraw(h, gd, callback){
  const drawers = h.players.filter(p=>!p.folded && !p.allIn);

  if(!isMulti){
    // ソロ: CPUは自動、人間はUI
    let humanPlayer = null;
    drawers.forEach(p=>{
      if(p.id==='human'){ humanPlayer = p; return; }
      cpuDraw(p, h, gd);
    });
    if(humanPlayer){ showDrawUI(humanPlayer, h, gd, callback); }
    else callback();
    return;
  }

  // マルチ: 全員人間。各自に交換させる
  h.drawPending = {};          // pid -> 捨てるインデックス配列
  h.drawCallback = callback;
  h.drawGd = gd;
  drawers.forEach(p=>{ h.drawPending[p.id] = null; }); // null=未回答
  // ホスト自身のUI
  const hostPlayer = drawers.find(p=>p.id===myId);
  if(hostPlayer){ showDrawUI(hostPlayer, h, gd, ()=>submitHostDraw(hostPlayer)); }
  // ゲストにドロー要求
  drawers.forEach(p=>{
    if(p.id===myId) return;
    fbSendTo(p.id, {type:'draw_request', drawNo:h.drawDone, gameKey:G.currentGame});
  });
  // 全員回答済みかをポーリングで監視（タイムアウトで自動スタンド）
  h.drawDeadline = Date.now() + 30000;
  checkDrawComplete(h);
}

// ホスト自身のドロー確定（drawSelectedCardsを使用）
function submitHostDraw(p){
  const h = HND();
  if(!h.drawPending) return;
  h.drawPending[myId] = drawSelectedCards.slice();
  checkDrawComplete(h);
}

// ゲストからのドロー応答を処理
function handleGuestDraw(senderId, discardIdxs){
  const h = HND();
  if(!h || !h.drawPending) return;
  if(h.drawPending[senderId] !== null) return; // 二重回答無視
  h.drawPending[senderId] = discardIdxs || [];
  checkDrawComplete(h);
}

// 全員のドローが揃ったか確認し、揃ったら適用
function checkDrawComplete(h){
  if(!h.drawPending) return;
  const allAnswered = Object.values(h.drawPending).every(v=>v!==null);
  const timedOut = Date.now() > (h.drawDeadline||0);
  if(!allAnswered && !timedOut){
    // まだ待つ（ポーリングで再チェック）
    if(aiTimer) clearTimeout(aiTimer);
    aiTimer = setTimeout(()=>checkDrawComplete(HND()), 800);
    return;
  }
  // 適用
  Object.entries(h.drawPending).forEach(([pid, discardIdxs])=>{
    const p = h.players.find(pp=>pp.id===pid);
    if(!p) return;
    const idxs = discardIdxs || []; // タイムアウト=スタンド
    const keep = p.hole.filter((c,i)=>!idxs.includes(i));
    const discarded = p.hole.filter((c,i)=>idxs.includes(i));
    const discardCount = discarded.length;
    if(h.discards) h.discards.push(...discarded);
    const newCards = [];
    for(let i=0;i<discardCount;i++){ const c2=drawCard(h); if(c2) newCards.push(c2); }
    p.hole = [...keep, ...newCards];
    p.faceUp = p.hole.map(()=>false);
    p.lastAction = discardCount>0 ? `${discardCount}枚交換` : 'スタンド';
  p.lastDraw = discardCount;
  G.log.unshift(`${p.name}: ${discardCount>0 ? discardCount+'枚交換' : 'スタンドパット'}`);
  });
  const cb = h.drawCallback;
  h.drawPending = null; h.drawCallback = null;
  if(cb) cb();
}

// CPU自動カード交換
function cpuDraw(p, h, gd){
  const lt = gd.evalLo;
  const drawsLeft = (gd.drawRounds||1) - (h.drawDone||0); // この交換を含む残り回数
  let keep = [];
  if(lt==='badugi'){ keep = bestBadugiKeep(p.hole); }
  else if(lt==='a5lo' || lt==='deuce27'){ keep = bestLowKeep(p.hole, lt, drawsLeft); }
  else { keep = p.hole.slice(); }
  // ブレイク判断: 相手にパット者がいて自分が9/10ハイの弱パットなら、8以下4枚を残し引き直す
  if(lt==='deuce27' && keep.length===5){
    const oppPat = h.players.some((pp)=> pp!==p && !pp.folded && pp.lastDraw===0);
    if(oppPat && drawsLeft>=1){
      const v = cd => cd.r;
      const hi = Math.max(...keep.map(v));
      const low4 = keep.filter(cd=>v(cd)<=8);
      if(hi>=9 && low4.length>=4 && Math.random()<0.6){
        keep = low4.slice(0,4); // ブレイク
      }
    }
  }
  // スノー（ブラフパット）: 2-7系の最終ドローで相手全員が2枚以上交換していたら低頻度で偽装スタンド
  if(lt==='deuce27' && keep.length<5 && drawsLeft===1){
    const opps = h.players.filter(pp=> pp!==p && !pp.folded);
    const allDrewMany = opps.length>0 && opps.every(pp=> (pp.lastDraw??2) >= 2);
    if(allDrewMany && Math.random()<0.08){
      keep = p.hole.slice(); // スノー: 手を崩さず全キープ
    }
  }
  const discarded = p.hole.filter(c=>!keep.includes(c));
  const discardCount = discarded.length;
  if(h.discards) h.discards.push(...discarded);
  const newCards = [];
  for(let i=0;i<discardCount;i++){ const c=drawCard(h); if(c) newCards.push(c); }
  p.hole = [...keep, ...newCards];
  p.faceUp = p.hole.map(()=>false);
  p.lastAction = discardCount>0 ? `${discardCount}枚交換` : 'スタンド';
  p.lastDraw = discardCount;
  G.log.unshift(`${p.name}: ${discardCount>0 ? discardCount+'枚交換' : 'スタンドパット'}`);
}

function bestBadugiKeep(hole){
  const r = badugiScore(hole);
  return r ? r.cards : hole.slice(0,1);
}
function bestLowKeep(hole, loType, drawsLeft){
  const isA5 = (loType==='a5lo');
  const val = c => isA5 ? (c.r===14?1:c.r) : c.r;
  const sorted = [...hole].sort((a,b)=>val(a)-val(b));
  // 最終ドロー（残り1回以下）は完成優先でパット範囲を広げる（SD2-7は常にこちら）
  const lastDraw = (drawsLeft!=null && drawsLeft<=1);
  const keepLimit = lastDraw ? 9 : 8;
  const patExtra = lastDraw ? 10 : 9; // パットに足す上限札
  let keep=[]; const usedRanks=new Set();
  for(const c of sorted){
    if(val(c) <= keepLimit && !usedRanks.has(c.r) && keep.length<5){ keep.push(c); usedRanks.add(c.r); }
  }
  // 上限札を1枚足してのスタンド（8以下4枚+9、最終ドローなら+10まで）
  if(keep.length===4){
    const ext = sorted.find(cd=>val(cd)<=patExtra && !usedRanks.has(cd.r) && !keep.includes(cd));
    if(ext){ keep.push(ext); usedRanks.add(ext.r); }
  }
  // 2-7: ストレート/フラッシュは役がついて最悪 → 5枚完成形なら最高札を捨てて解体
  if(!isA5 && keep.length===5){
    const rs = keep.map(cd=>cd.r).sort((a,b)=>a-b);
    const isStraight = rs.every((r,i)=> i===0 || r===rs[i-1]+1);
    const isFlush = new Set(keep.map(cd=>cd.s)).size===1;
    if(isStraight || isFlush){
      keep.sort((a,b)=>val(a)-val(b));
      keep.pop(); // 最高札を交換
    }
  }
  // 全部9以上なら最も低い1枚だけ残す
  if(keep.length===0) keep = [sorted[0]];
  return keep;
}

// ===== 種目別の手の強さ（レンジ推定フィルタ用・0-1） =====
function drawStrength(hole, evalLo){
  if(evalLo==='badugi'){
    const b = badugiScore(hole);
    if(!b) return 0;
    const n = b.count;
    const vals = b.cards.map(cd=> cd.r===14?1:cd.r).sort((a,b)=>a-b);
    const hi = vals[vals.length-1];
    // badugi定説: ①枚数(4>3>2>1)が最優先、②同じ枚数なら「最高札が低い」、
    // ③さらに side card も低い「スムーズ」な手が上（A-2-3-4 > A-2-3-8、3枚なら A-2-3 > 7-8-9）。
    const countScore = (n-1)/3;                 // 0,0.33,0.67,1.0
    const hiScore = (14 - hi)/13;               // 最高札の低さ
    // スムーズさ: 全札の低さの平均（A=1で最良）
    const smooth = vals.reduce((s,v)=>s+(14-v),0) / (vals.length*13);
    let s = countScore*0.62 + hiScore*0.24 + smooth*0.14;
    // 3枚以下で高札ばかり（最高札9以上）の弱いドローは追加減点（8-badugi以下を狙うのは悪手）
    if(n<4 && hi>=9) s -= (hi-8)*0.025;
    return Math.max(0, Math.min(1, s));
  }
  const isA5 = (evalLo==='a5lo');
  const val = cd => isA5 ? (cd.r===14?1:cd.r) : cd.r;
  const uniqVals = [...new Set(hole.map(val))].sort((a,b)=>a-b);
  const low5 = uniqVals.slice(0,5);
  if(low5.length < 5) return Math.max(0, low5.length * 0.08); // ペア過多
  const hi = low5[4];
  let s;
  if(hi <= 8) s = Math.min(1, 0.72 + (8-hi)*0.14); // 8ロー完成=0.72、7ロー=0.86、ホイール級=1.0
  else if(hi === 9) s = 0.62;                       // 9ロー完成
  else if(hi === 10) s = 0.50;                      // 10ロー完成
  else {
    // ブロードウェイ混じり: 実質ドロー手。8以下の低札数で評価
    const lowN = low5.filter(v=>v<=8).length;
    s = 0.18 + lowN * 0.07; // 低札4枚=0.46, 3枚=0.39
  }
  if(!isA5 && hole.length===5){
    const rs = hole.map(cd=>cd.r).sort((a,b)=>a-b);
    const st = new Set(rs).size===5 && rs[4]-rs[0]===4;
    const fl = new Set(hole.map(cd=>cd.s)).size===1;
    if(st||fl) s -= 0.45; // 2-7: ストレート/フラッシュ完成は大減点
  }
  return Math.max(0, Math.min(1, s));
}
// ドロー種目: 投資量+交換枚数から相手レンジ下限を推定（閾値はランダム分布から校正済み）
function drawRangeFloor(h, opp, evalLo){
  const bb = h.bbAmount || 20;
  let inv = (opp.totalBet||0) + (opp.roundBet||0);
  if(opp.idx === h.bbIdx){
    const anteBB = (typeof G!=='undefined'&&G&&G.tourney&&G.tourney.curAnte>0) ? (G.tourney.curAnte/bb) : 0;
    inv -= bb * (1 + anteBB);
  }
  else if(opp.idx === h.sbIdx) inv -= Math.floor(bb/2);
  const bbInv = inv / bb;
  const T = evalLo==='badugi' ? [0.56,0.62,0.77] : evalLo==='a5lo' ? [0.32,0.40,0.46] : [0.32,0.36,0.39];
  let tier = 0;
  if(bbInv >= 7) tier = 3;
  else if(bbInv >= 2.2) tier = 2;
  else if(bbInv >= 0.9) tier = 1;
  if((opp.aggCnt||0) >= 2) tier = Math.min(3, tier+1); // 複数回アグレッション
  // 交換枚数は公開情報: スタンドパット=完成手レンジ（上位5%）、1枚交換=ほぼ完成レンジ
  const PAT = evalLo==='badugi' ? 0.82 : evalLo==='a5lo' ? 0.62 : 0.50; // パット=完成手レンジ（badugi:4枚 / a5:9ロー以上 / 2-7:10ロー以上）
  let floor = tier===0 ? 0 : T[tier-1];
  if(opp.lastDraw === 0) floor = Math.max(floor, PAT);
  else if(opp.lastDraw === 1) floor = Math.max(floor, T[1]);
  return floor;
}
// スタッド種目: 投資量から伏せ札レンジ下限を推定
function studRangeFloor(h, opp, isRazz){
  const bb = h.bbAmount || 20;
  const bbInv = ((opp.totalBet||0)+(opp.roundBet||0)) / bb;
  const gdS = (typeof G!=='undefined'&&G) ? (MIX_GAMES[G.currentGame]||{}) : {};
  const T = (gdS.hi&&gdS.lo) ? [0.32,0.39,0.52] : isRazz ? [0.19,0.27,0.38] : [0.28,0.30,0.43]; // studHilo3校正値含む
  let tier = 0;
  if(bbInv >= 7) tier = 3;
  else if(bbInv >= 2.2) tier = 2;
  else if(bbInv >= 0.9) tier = 1;
  if((opp.aggCnt||0) >= 2) tier = Math.min(3, tier+1); // 複数回アグレッション
  return tier===0 ? 0 : T[tier-1];
}
function studStart3(cards, isRazz){
  // スタッドの3枚スターティング強度（伏2+表1相当）
  if(isRazz){
    // ラズ定説: ①8以下3枚が基準（9以上は大きく減点）、②3枚とも低いほど良い、
    // ③ラズの手は「最高札」でランクされるので最高札が低いことを重視、④ペアは減点。
    const vals = cards.map(cd=> cd.r===14?1:cd.r).sort((a,b)=>a-b);
    const uniq = new Set(vals);
    const hi = vals[vals.length-1];
    const mid = vals[1];
    // 最高札ベースの基礎点（A-5=最強、8で実用下限、9+で急落）
    let s;
    if(hi <= 5) s = 0.92;        // 3枚 A-5（ホイール級ドロー）
    else if(hi === 6) s = 0.82;
    else if(hi === 7) s = 0.72;
    else if(hi === 8) s = 0.58;  // 8ロー: 実用下限
    else if(hi === 9) s = 0.33;  // 9含む: 大きく価値減（基本降り寄り）
    else if(hi === 10) s = 0.20;
    else s = 0.08;               // J以上を含む: ほぼ降り
    // 中札・下札も低いとボーナス（例: 8ハイでも A-3-8 は 6-7-8 より良い）
    s += (8 - Math.min(8, mid)) / 8 * 0.06;
    s += (8 - Math.min(8, vals[0])) / 8 * 0.04;
    // ペア（ラズでは役がついて最悪）大減点
    s -= (cards.length - uniq.size) * 0.32;
    return Math.max(0, Math.min(1, s));
  }
  // stud/studhi: ペア・トリップス・スーテッド連結・ハイカード
  const rs = cards.map(cd=>cd.r);
  const counts={}; rs.forEach(r=>counts[r]=(counts[r]||0)+1);
  const maxC = Math.max(...Object.values(counts));
  let s = 0;
  if(maxC===3) s = 0.95;
  else if(maxC===2){
    const pr = +Object.keys(counts).find(k=>counts[k]===2);
    s = 0.45 + pr/14 * 0.3;
  } else {
    const hi = Math.max(...rs);
    s = hi/14 * 0.3;
    const suits = new Set(cards.map(cd=>cd.s));
    if(suits.size===1) s += 0.15;
    const sr = rs.slice().sort((a,b)=>a-b);
    if(sr[2]-sr[0] <= 4) s += 0.08; // 連結気味
  }
  return Math.max(0, Math.min(1, s));
}

// 人間のドロー交換UI（ソロ用）
// ===== CPU参考アクション表示（ソロ専用） =====
let soloShowHint = true;
let _hintKey = null, _hintBusy = false, _hintHtml = '';
function cardLbl(cd){ return rankStr(cd.r)+SUIT_SYM[cd.s]; } // 既存のrankStr/SUIT_SYMを使用（後方で定義・呼び出し時には利用可能）
function updateCpuHint(){
  const el = g('cpu-hint');
  if(!el) return;
  if(!soloShowHint || !G || !G.hand || G.hand.results){ el.style.display='none'; _hintKey=null; return; }
  const h = G.hand;
  const myIdx = h.players.findIndex(pp=>pp.id===myId);
  if(myIdx<0 || h.players[myIdx].folded){ el.style.display='none'; _hintKey=null; return; }
  const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  const isDrawTurn = !!(h._drawPlayer && h._drawPlayer.id==='human');
  const isBetTurn = !isDrawTurn && h.toActIdx===myIdx;
  if(!isBetTurn && !isDrawTurn){ el.style.display='none'; _hintKey=null; return; }
  const key = [G.handNo, h.phase, h.studStreet, h.drawDone, h.highBet, h.pot, isDrawTurn?'d':'b'].join('|');
  if(key === _hintKey){ el.style.display='block'; el.innerHTML = _hintHtml; return; }
  if(_hintBusy) return;
  _hintBusy = true;
  el.style.display = 'block';
  el.innerHTML = '💡 CPU参考: <span class="muted">計算中…</span>';
  setTimeout(()=>{
    const el2 = g('cpu-hint') || el; // 再描画でdivが差し替わっていても最新を取得
    try{
      const me = h.players[myIdx];
      let txt;
      if(isDrawTurn){
        const drawsLeft = (gd.drawRounds||1) - (h.drawDone||0);
        let keep;
        if(gd.evalLo==='badugi') keep = bestBadugiKeep(me.hole);
        else keep = bestLowKeep(me.hole, gd.evalLo, drawsLeft);
        const disc = me.hole.filter(cd=>!keep.includes(cd));
        txt = disc.length===0 ? '<b>スタンドパット</b>'
          : `<b>${disc.length}枚交換</b>（${disc.map(cardLbl).join(' ')} を捨てる）`;
      } else {
        const act = cpuDecide(myIdx);
        txt = act.type==='fold' ? '<b>フォールド</b>'
          : act.type==='check' ? '<b>チェック</b>'
          : act.type==='call' ? '<b>コール</b>'
          : `<b>レイズ → ${act.amount}</b>`;
      }
      _hintHtml = `💡 CPU参考: ${txt}`;
      el2.innerHTML = _hintHtml;
      el2.style.display = 'block';
      _hintKey = key;
    }catch(e){ el2.style.display='none'; }
    _hintBusy = false;
  }, 30);
}
let drawSelectedCards = [];
function showDrawUI(p, h, gd, callback){
  drawSelectedCards = [];
  h._drawCallback = callback;
  h._drawPlayer = p;
  h._drawGd = gd;
  render(); // ボードと手札を表示
  const area = g('action-area');
  area.innerHTML = `
    <div class="action-bar">
      <div class="center" style="margin-bottom:5px; color:var(--gold); font-weight:700; font-size:0.9rem;">🔄 交換するカードをタップ</div>
      <div id="draw-hand" style="display:flex; gap:6px; justify-content:center; margin-bottom:8px;"></div>
      <div class="jopt2-actions">
        <button class="btn btn-ghost" onclick="standPat()">スタンドパット</button>
        <button class="btn btn-gold" onclick="confirmDraw()">交換する</button>
      </div>
      <div id="cpu-hint" class="center muted small" style="display:none; margin-top:6px;"></div>
    </div>`;
  renderDrawHand(p);
  updateCpuHint();
}
function renderDrawHand(p){
  const cont = g('draw-hand');
  if(!cont) return;
  cont.innerHTML = '';
  p.hole.forEach((c,i)=>{
    const selected = drawSelectedCards.includes(i);
    const div = document.createElement('div');
    div.innerHTML = cardHTML(c,{sm:true});
    div.style.cssText = `cursor:pointer; border:2px solid ${selected?'var(--red)':'transparent'}; border-radius:8px; opacity:${selected?'0.5':'1'};`;
    div.onclick = ()=>{
      const idx = drawSelectedCards.indexOf(i);
      if(idx>=0) drawSelectedCards.splice(idx,1);
      else drawSelectedCards.push(i);
      renderDrawHand(p);
    };
    cont.appendChild(div);
  });
}
function confirmDraw(){
  const h = HND();
  g('action-area').innerHTML = '';
  if(isMulti){
    // マルチ: 自分がゲストならホストへ送信、ホストなら直接コールバック
    if(isHost){
      const cb = h._drawCallback; h._drawCallback = null;
      if(cb) cb(); // submitHostDraw(p) が呼ばれる
    } else {
      // ゲスト: 捨てるインデックスをホストへ
      fbSendToHost({type:'draw_response', discard: drawSelectedCards.slice()});
    }
    return;
  }
  // ソロ: 直接交換
  const p = h._drawPlayer;
  const keep = p.hole.filter((c,i)=>!drawSelectedCards.includes(i));
  const discarded = p.hole.filter((c,i)=>drawSelectedCards.includes(i));
  const discardCount = discarded.length;
  if(h.discards) h.discards.push(...discarded);
  const newCards = [];
  for(let i=0;i<discardCount;i++){ const c2=drawCard(h); if(c2) newCards.push(c2); }
  p.hole = [...keep, ...newCards];
  p.faceUp = p.hole.map(()=>false);
  p.lastAction = discardCount>0 ? `${discardCount}枚交換` : 'スタンド';
  p.lastDraw = discardCount;
  G.log.unshift(`${p.name}: ${discardCount>0 ? discardCount+'枚交換' : 'スタンドパット'}`);
  const cb = h._drawCallback;
  h._drawCallback = null;
  if(cb) cb();
}
function standPat(){
  drawSelectedCards = [];
  const h = HND();
  g('action-area').innerHTML = '';
  if(isMulti){
    if(isHost){
      const cb = h._drawCallback; h._drawCallback = null;
      if(cb) cb();
    } else {
      fbSendToHost({type:'draw_response', discard: []});
    }
    return;
  }
  const p = h._drawPlayer;
  p.lastAction = 'スタンド';
  const cb = h._drawCallback;
  h._drawCallback = null;
  if(cb) cb();
}



// 種目別: プレイヤーのHi評価を返す（比較可能な形）。なければnull
function showdownEvalHi(p, h, gd){
  if(!gd.hi) return null;
  if(gd.type==='community') return gd.superHi ? evalSuperHi(p.hole, h.board) : evalHi(p.hole, h.board, gd.plo);
  // スタッド: 手札＋共有カード（山札不足時のみboardに入る）から最強5枚
  const pool = (gd.type==='stud' && h.board && h.board.length) ? p.hole.concat(h.board) : p.hole;
  return bestHiFrom(pool);
}
// 種目別: プレイヤーのLo評価を返す。なければnull。比較関数も種目で違う
function showdownEvalLo(p, h, gd){
  if(!gd.lo) return null;
  const lt = gd.evalLo;
  // スタッド系は共有カード（山札不足時）も含める
  const pool = (gd.type==='stud' && h.board && h.board.length) ? p.hole.concat(h.board) : p.hole;
  if(lt==='lo8' || lt==='stud7lo8'){
    // 8 or better
    if(gd.type==='community'){ const r=evalLo(p.hole,h.board,gd.plo); return r?{kind:'lo8',lo:r.lo,cards:r.cards}:null; }
    const r=bestLo8From(pool,gd); return r?{kind:'lo8',lo:r.lo,cards:r.cards}:null;
  } else if(lt==='a5lo' || lt==='razz'){
    const r=bestA5Lo(pool); return r?{kind:'a5',score:r.score,cards:r.cards}:null;
  } else if(lt==='deuce27'){
    const r=best27Lo(pool); return r?{kind:'27',score:r.score,cards:r.cards}:null;
  } else if(lt==='badugi'){
    const r=badugiScore(pool); return r?{kind:'badugi',score:r.score,cards:r.cards}:null;
  }
  return null;
}
// Lo評価の比較（a が強ければ負）
function cmpLoEval(a, b){
  if(a.kind==='lo8') return compareLo(a.lo, b.lo);
  if(a.kind==='a5'||a.kind==='27') return cmpArr(a.score, b.score);
  if(a.kind==='badugi') return -cmpArr(a.score, b.score); // badugiはscore大が強い→符号反転
  return 0;
}

function doShowdown(){
  const h = HND();
  if(h.results) return; // 二重分配防止
  const gameDef = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  const pots = buildPots(h.players);
  const contenders = notFolded();
  const results = [];

  pots.forEach((pot, pi)=>{
    const eligPlayers = contenders.filter(p=>pot.eligible.includes(p.id));
    if(eligPlayers.length===0) return;
    const potLabel = pots.length>1 ? (pi===0?'メイン':`サイド${pi}`) : '';

    const hasHi = gameDef.hi;
    const hasLo = gameDef.lo;

    if(hasHi && hasLo){
      // Hi-Lo分割
      const hiEvals = eligPlayers.map(p=>({p, ev:showdownEvalHi(p,h,gameDef)}));
      let hiBest=null;
      hiEvals.forEach(e=>{ if(e.ev && (!hiBest||compareEval([e.ev.rank,e.ev.tiebreak],[hiBest.rank,hiBest.tiebreak])>0)) hiBest=e.ev; });
      const hiWinners = hiBest ? hiEvals.filter(e=>e.ev && compareEval([e.ev.rank,e.ev.tiebreak],[hiBest.rank,hiBest.tiebreak])===0).map(e=>e.p) : [];
      const loEvals = eligPlayers.map(p=>({p, ev:showdownEvalLo(p,h,gameDef)}));
      let loBest=null;
      loEvals.forEach(e=>{ if(e.ev && (!loBest||cmpLoEval(e.ev, loBest)<0)) loBest=e.ev; });
      const loWinners = loBest ? loEvals.filter(e=>e.ev && cmpLoEval(e.ev, loBest)===0).map(e=>e.p) : [];

      if(loWinners.length===0){
        distributePot(h, pot.amount, hiWinners, results, pi, potLabel+'(Hi総取り)');
      } else {
        const loAmt = Math.floor(pot.amount/2);
        const hiAmt = pot.amount - loAmt; // 奇数ポットの端数はHi側へ（標準ルール）
        distributePot(h, hiAmt, hiWinners, results, pi, potLabel+'Hi');
        distributePot(h, loAmt, loWinners, results, pi, potLabel+'Lo');
      }
    } else if(hasHi){
      const evals = eligPlayers.map(p=>({p, ev:showdownEvalHi(p,h,gameDef)}));
      let best=null;
      evals.forEach(e=>{ if(e.ev && (!best||compareEval([e.ev.rank,e.ev.tiebreak],[best.rank,best.tiebreak])>0)) best=e.ev; });
      const winners = best ? evals.filter(e=>e.ev && compareEval([e.ev.rank,e.ev.tiebreak],[best.rank,best.tiebreak])===0).map(e=>e.p) : [];
      distributePot(h, pot.amount, winners, results, pi, potLabel);
    } else if(hasLo){
      // Loのみ（A5/27/badugi/razz）
      const evals = eligPlayers.map(p=>({p, ev:showdownEvalLo(p,h,gameDef)}));
      let best=null;
      evals.forEach(e=>{ if(e.ev && (!best||cmpLoEval(e.ev, best)<0)) best=e.ev; });
      const winners = best ? evals.filter(e=>e.ev && cmpLoEval(e.ev, best)===0).map(e=>e.p) : [];
      // ローが誰も成立しない場合（A5/27は常に成立、badugiも必ず1枚以上で成立）
      if(winners.length===0){ distributePot(h, pot.amount, eligPlayers, results, pi, potLabel+'(分配)'); }
      else distributePot(h, pot.amount, winners, results, pi, potLabel);
    }
  });

  h.results = results;
  // 役名を記録（公開用）。降りた相手の役も計算する（ソロのショウダウンで表示するため）
  // ※マルチでは降りた相手のhandNameは配信されない（ploPub_buildで除外）ので画面には出ない
  h.handNames = {};
  const nameOf = (p)=>{
    const hi = gameDef.hi ? showdownEvalHi(p,h,gameDef) : null;
    const lo = gameDef.lo ? showdownEvalLo(p,h,gameDef) : null;
    let label = '';
    if(hi) label += (hi.detail || hi.name);
    if(lo){
      let loStr = '';
      if(lo.kind==='lo8') loStr = lo.lo.map(v=>v===1?'A':v).reverse().join('-');
      else if(lo.kind==='a5') loStr = lo.cards.slice().sort((a,b)=>(b.r===14?1:b.r)-(a.r===14?1:a.r)).map(c=>c.r===14?'A':rankStr(c.r)).join('-');
      else if(lo.kind==='27') loStr = lo.cards.slice().sort((a,b)=>b.r-a.r).map(c=>rankStr(c.r)).join('-');
      else if(lo.kind==='badugi') loStr = lo.cards.slice().sort((a,b)=>(b.r===14?1:b.r)-(a.r===14?1:a.r)).map(c=>c.r===14?'A':rankStr(c.r)).join('-') + `(${lo.cards.length}枚)`;
      label += (label?' / ':'') + 'ロー ' + loStr;
    }
    return label || '-';
  };
  // 全プレイヤー（降りた人含む）。ただし手札を持っている人のみ評価
  h.players.forEach(p=>{
    if(!p.hole || p.hole.length===0) return;
    try { h.handNames[p.id] = nameOf(p); } catch(e){ /* 役評価できない局面は省略 */ }
  });
  // ショウダウン結果をログに記録（勝者と役）。複数ポットは代表してまとめる
  try {
    const shown = h.players.filter(p=>!p.folded);
    const winnerIds = [...new Set(results.flatMap(r=>r.winnerIds))];
    const winnerNames = [...new Set(results.flatMap(r=>r.winnerNames))];
    const totalWon = results.reduce((s,r)=>s+r.amount,0);
    // 勝者行を先に（🏆）、続いて各コンテンダーの手（🃏）。勝者には★を付ける
    if(winnerNames.length){
      G.log.unshift(`🏆 ${winnerNames.join('・')} が ${totalWon} 獲得`);
    }
    shown.forEach(p=>{
      const cards = p.hole.map(cd=>rankStr(cd.r)+SUIT_SYM[cd.s]).join(' ');
      const nm = h.handNames[p.id] ? ` — ${h.handNames[p.id]}` : '';
      const star = winnerIds.includes(p.id) ? '★ ' : '　';
      G.log.unshift(`${star}${p.name}: ${cards}${nm}`);
    });
    // 見出し
    G.log.unshift(`─── ショーダウン ───`);
  } catch(e){ console.error('showdown log build失敗', e); }
  h.players.forEach((p,i)=>{ G.stacks[i] = p.stack; });
  logHandPnl(h);
}

// ポット分配ヘルパー
function distributePot(h, amount, winners, results, potIndex, label){
  if(winners.length===0 || amount<=0) return;
  const share = Math.floor(amount/winners.length);
  const rem = amount - share*winners.length;
  // 余りチップはボタンの左隣(SB)から時計回りに1枚ずつ配る（ポーカー慣行）
  let ordered = winners;
  if(rem>0 && typeof G!=='undefined' && G && typeof G.buttonIdx==='number' && h.players){
    const N = h.players.length;
    const start = (G.buttonIdx + 1) % N;
    const seatOrder = p=>{ const i = h.players.indexOf(p); return i<0 ? 99 : ((i - start + N) % N); };
    ordered = winners.slice().sort((a,b)=> seatOrder(a) - seatOrder(b));
  }
  ordered.forEach((p,i)=>{ p.stack += share + (i<rem?1:0); });
  results.push({
    potIndex, amount,
    winnerIds: winners.map(p=>p.id),
    winnerNames: winners.map(p=>p.name),
    label,
  });
}

// 1人勝ち（全員フォールド）の処理
// ハンド収支をログに記録
function logHandPnl(h){
  const parts = h.players
    .filter(p=>p.startStack>0 || p.stack>0)
    .map(p=>{
      const d = p.stack - p.startStack;
      return `${p.name} ${d>0?'+'+d:(d<0?d:'±0')}`;
    });
  G.log.unshift(`💰 収支: ${parts.join(' / ')}`);
  // セッション集計（自分視点）。ソロ＝常に、マルチ＝ホスト自身ぶん
  try { recordHandResult(h); } catch(e){ console.warn('recordHandResult失敗', e); }
}

function awardToLastPlayer(){
  const h = HND();
  if(h.results) return; // 二重分配防止
  const winner = notFolded()[0];
  h.pot += roundBetTotal();
  h.players.forEach(p=>p.roundBet=0);
  winner.stack += h.pot;
  h.results = [{potIndex:0, amount:h.pot, winnerIds:[winner.id], winnerNames:[winner.name], uncontested:true}];
  // ソロで人間がフォールド済みなら、CPUの手をログに公開
  const meP2 = h.players.find(x=>x.id===myId);
  if(!isMulti && meP2 && meP2.folded){
    h.players.forEach(p=>{
      if(p.id===myId) return;
      const cards = p.hole.map(cd=>rankStr(cd.r)+SUIT_SYM[cd.s]).join(' ');
      G.log.unshift(`🃏 ${p.name}: ${cards}${p.folded?'（フォールド済）':''}`);
    });
  }
  G.log.unshift(`🏆 ${winner.name} が ${h.pot} を獲得（全員フォールド）`);
  // 役名を計算（ボードが十分にある＝役を作れる場合のみ）。
  // ソロ: 全員分。マルチ(WIN THE SHOW): 公開する勝者の分のみ。
  {
    const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
    const canEval = (gd.type==='community' && h.board.length>=5) ||
                    (gd.type!=='community'); // ドロー/スタッドは手札のみで評価可
    if(canEval){
      h.handNames = h.handNames || {};
      const targets = isMulti ? [winner] : h.players;
      targets.forEach(p=>{
        if(!p.hole || p.hole.length===0) return;
        try {
          const hi = gd.hi ? showdownEvalHi(p,h,gd) : null;
          const lo = gd.lo ? showdownEvalLo(p,h,gd) : null;
          let label = '';
          if(hi) label += hi.name;
          if(lo){
            let loStr='';
            if(lo.kind==='lo8') loStr = lo.lo.map(v=>v===1?'A':v).reverse().join('');
            else if(lo.kind==='a5') loStr = lo.cards.slice().sort((a,b)=>(b.r===14?1:b.r)-(a.r===14?1:a.r)).map(c=>c.r===14?'A':rankStr(c.r)).join('');
            else if(lo.kind==='27') loStr = lo.cards.slice().sort((a,b)=>b.r-a.r).map(c=>rankStr(c.r)).join('');
            else if(lo.kind==='badugi') loStr = lo.cards.slice().sort((a,b)=>(b.r===14?1:b.r)-(a.r===14?1:a.r)).map(c=>c.r===14?'A':rankStr(c.r)).join('')+'('+lo.cards.length+'枚)';
            label += (label?' / ':'')+'Lo:'+loStr;
          }
          if(label) h.handNames[p.id] = label;
        } catch(e){ console.warn('役名生成失敗', e); }
      });
    }
  }
  h.players.forEach((p,i)=>{ G.stacks[i]=p.stack; });
  h.toActIdx = -1;
  h.phase = 'showdown'; // アクションUIを閉じる
  logHandPnl(h);
}

// ===== 進行ループ =====
function scheduleNext(){
  if(aiTimer) clearTimeout(aiTimer);

  const h = HND();
  if(!h) return;
  // 既にハンドが決着済み（results確定）なら何もしない（古いコールバック対策）
  if(h.results) return;
  // showdownフェーズで未分配なら分配して終了
  if(h.phase === 'showdown'){
    if(!h.results){ doShowdown(); render(); aiTimer = setTimeout(()=>endHand(), 1500); }
    return;
  }

  // ハンド終了チェック（1人だけ残り）
  if(notFolded().length <= 1){
    awardToLastPlayer();
    render();
    aiTimer = setTimeout(()=>endHand(), 1200);
    return;
  }

  // ラウンド完了チェック
  if(isRoundComplete()){
    const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;

    if(isLastBettingRound(h, gd)){
      // 最後のベッティング → ショーダウン
      h.phase = 'showdown';
      doShowdown();
      render();
      aiTimer = setTimeout(()=>endHand(), 1800);
      return;
    } else {
      advancePhase();
      // ドローフェーズなら交換を実行
      if(h.needDraw){
        h.needDraw = false;
        executeDraw(h, gd, ()=>{
          // 交換後、次のベッティングへ
          h.phase = 'bet';
          h.toActIdx = nextActor(G.buttonIdx);
          render();
          if(activePlayers().length <= 1 && notFolded().length >= 2){
            aiTimer = setTimeout(()=>scheduleNext(), 1000);
          } else {
            aiTimer = setTimeout(()=>scheduleNext(), 600);
          }
        });
        return;
      }
      render();
      if(activePlayers().length <= 1 && notFolded().length >= 2){
        aiTimer = setTimeout(()=>scheduleNext(), 1000);
        return;
      }
      aiTimer = setTimeout(()=>scheduleNext(), 600);
      return;
    }
  }

  // 次のアクター
  const idx = h.toActIdx;
  if(idx < 0){ return; }
  const p = h.players[idx];

  if(isMulti){
    // マルチ: CPUはいない。ホスト自身ならローカルUI、人間ゲストならアクション待ち
    render(); // 配信込み
    if(p.id === myId){
      // ホスト自身の番 → ローカルアクションUI（renderActionAreaで表示）
    }
    // ゲストの番なら、ゲストからのactionメッセージを待つ（onMsg→handleGuestAction）
    return;
  }

  if(p.isCpu){
    render();
    const handSnapshot = G.handNo;
    aiTimer = setTimeout(()=>{
      // 別のハンドに切り替わっていたら無視（古いコールバック対策）
      if(G.handNo !== handSnapshot) return;
      if(h !== HND()) return;
      if(h.toActIdx !== idx) return;
      const action = cpuDecide(idx);
      applyAction(idx, action);
      h.toActIdx = nextActor(idx);
      scheduleNext();
    }, 900);
  } else {
    // 人間の番 → アクションUI表示
    render();
  }
}

function humanAction(action){
  const h = HND();
  const selfId = isMulti ? myId : 'human';
  if(!h || h.toActIdx < 0 || !h.players[h.toActIdx] || h.players[h.toActIdx].id !== selfId) return;
  applyAction(h.toActIdx, action);
  h.toActIdx = nextActor(h.toActIdx);
  scheduleNext();
}

// キャッシュゲーム: チップが0のCPUを次ハンド前に自動リバイ（ソロのみ。マルチは全員人間）
function rebuyBustedCpus(){
  if(G.tourney) return; // トーナメントはリバイなし
  if(isMulti) return;   // マルチにCPUはいない
  const buyin = soloStack;
  G.ids.forEach((id,i)=>{
    if(id==='human') return;
    if(G.stacks[i] <= 0){
      G.stacks[i] = buyin;
      G.log.unshift(`💰 ${G.names[id]} がリバイ +${buyin}`);
    }
  });
}

function endHand(){
  // トーナメント: このハンドで飛んだプレイヤーを脱落として順位記録
  if(G.tourney){
    const h0 = HND();
    const newlyOut = h0.players
      .filter(p=>p.stack===0 && G.tourney.ranks[p.id]==null)
      .sort((a,b)=>a.startStack-b.startStack); // 同時脱落は開始時スタックが少ない方が下位
    if(newlyOut.length){
      const aliveN = G.ids.filter((id,ix)=>G.stacks[ix]>0).length;
      newlyOut.forEach((p,k)=>{
        const rank = aliveN + newlyOut.length - k;
        G.tourney.ranks[p.id] = rank;
        G.log.unshift(`💀 ${p.name} 脱落（${rank}位）`);
      });
    }
  }
  // 結果画面に遷移せず、ゲーム画面のままショーダウン表示を維持
  render();

  if(isMulti){
    // マルチ: ホストのみ進行管理。ショーダウン表示後、次ハンドへ自動進行
    if(!isHost) return; // ゲストは何もしない（ホストの配信を待つ）
    const aliveCount = G.ids.filter((id,i)=>G.stacks[i] > 0).length;
    if(aliveCount < 2){
      if(G.tourney){
        aiTimer = setTimeout(()=>{ startNewHand(); }, 3000); // alive<2 → showFinalResultへ
        return;
      }
      aiTimer = setTimeout(()=>{ /* 全員リバイ待ち or 終了 */ broadcastState(); }, 2000);
      // リバイ猶予を与えて、一定時間後に再チェック
      aiTimer = setTimeout(()=>{ tryStartNextMultiHand(); }, 8000);
      return;
    }
    aiTimer = setTimeout(()=>{ tryStartNextMultiHand(); }, 4000);
    return;
  }

  // ソロ: 自分のチップが0ならリバイUI（トーナメントはリバイなし→観戦継続）
  const meIdx = G.ids.indexOf('human');
  if(!G.tourney && G.stacks[meIdx] <= 0){
    showRebuyPrompt();
    return;
  }
  // キャッシュゲーム: 飛んだCPUを自動リバイして卓を維持
  rebuyBustedCpus();
  const alive = G.ids.filter((id,i)=>G.stacks[i] > 0);
  if(alive.length < 2){
    aiTimer = setTimeout(()=>showFinalResult(), 2000);
    return;
  }
  aiTimer = setTimeout(()=>{ startNewHand(); }, 2600);
}

// マルチ: 次ハンド開始（生存者2人以上必要）
function tryStartNextMultiHand(){
  if(!isHost) return;
  const alive = G.ids.filter((id,i)=>G.stacks[i] > 0);
  if(alive.length < 2){
    // まだ2人未満ならもう少し待つ（リバイ待ち）。長時間ならログのみ
    aiTimer = setTimeout(()=>tryStartNextMultiHand(), 5000);
    return;
  }
  startNewHand();
}

function nextHand(){
  show('game');
  startNewHand();
}

function backToLobby(){
  if(aiTimer) clearTimeout(aiTimer);
  show('lobby');
}

// ===== リバイ =====
function showRebuyPrompt(){
  // ゲーム画面下部にリバイUIを表示
  const area = g('action-area');
  const baseStack = soloStack;
  area.innerHTML = `
    <div class="action-bar">
      <div class="center" style="margin-bottom:10px; color:var(--gold); font-weight:700;">
        💰 チップがなくなりました
      </div>
      <div class="center small muted" style="margin-bottom:10px;">リバイ（買い足し）しますか？</div>
      <div class="action-btns">
        <button class="btn btn-felt" onclick="doRebuy(${Math.floor(baseStack/2)})">+${Math.floor(baseStack/2)}</button>
        <button class="btn btn-gold" onclick="doRebuy(${baseStack})">+${baseStack}</button>
        <button class="btn btn-felt" onclick="doRebuy(${baseStack*2})">+${baseStack*2}</button>
      </div>
      <button class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="quitToLobby()">やめる（ロビーへ）</button>
    </div>`;
}
function doRebuy(amount){
  const meIdx = G.ids.indexOf('human');
  G.stacks[meIdx] += amount;
  G.log.unshift(`💰 ${G.names['human']} がリバイ +${amount}`);
  g('action-area').innerHTML = '';
  // 飛んだCPUも一緒にリバイして卓を維持
  rebuyBustedCpus();
  // リバイ後、次のハンドへ
  const alive = G.ids.filter((id,i)=>G.stacks[i] > 0);
  if(alive.length < 2){ aiTimer = setTimeout(()=>showFinalResult(), 1500); return; }
  aiTimer = setTimeout(()=>{ startNewHand(); }, 800);
}
function quitToLobby(){
  if(aiTimer) clearTimeout(aiTimer);
  show('lobby');
}

function tourneyRankingHTML(ranks, names, ids, handNo, level){
  const medal = r => r===1?'🥇':r===2?'🥈':r===3?'🥉':`${r}位`;
  const rows = ids.map(id=>({id, rank: ranks[id]||99}))
    .sort((a,b)=>a.rank-b.rank)
    .map(e=>`<div style="display:flex; justify-content:space-between; padding:7px 12px; border-bottom:1px solid var(--surface3); ${e.rank===1?'color:var(--gold); font-weight:700;':''}">
      <span>${medal(e.rank)}</span><span>${esc(names[e.id]||e.id)}</span></div>`).join('');
  return `
    <h3 class="center">🏆 トーナメント終了</h3>
    <div style="margin:12px 0;">${rows}</div>
    <div class="center muted small">全${handNo}ハンド / Lv${(level||0)+1}まで進行</div>`;
}
function showFinalResult(){
  stopTourneyBar();
  show('result');
  const winner = G.ids.find((id,i)=>G.stacks[i]>0);
  if(G.tourney){
    if(winner) G.tourney.ranks[winner] = 1;
    g('result-detail').innerHTML = tourneyRankingHTML(G.tourney.ranks, G.names, G.ids, G.handNo, G.tourney.level);
    if(isMulti && isHost){
      fbBroadcast({type:'tourney_end', ranks:G.tourney.ranks, names:G.names, ids:G.ids, handNo:G.handNo, level:G.tourney.level});
    }
  } else {
    g('result-detail').innerHTML = `
      <h3 class="center">🏆 ゲーム終了</h3>
      <div class="center" style="font-size:1.3rem; color:var(--gold); margin:14px 0;">
        ${winner?esc(G.names[winner]):'(なし)'} の勝利！
      </div>
      <div class="center muted">全${G.handNo}ハンド</div>`;
  }
  const btn = g('result-detail').parentElement.querySelector('button');
  if(btn) btn.style.display='none';
}

// ===== トーナメント情報バー（レベル・ブラインド・次レベルまでの残り時間） =====
let tourneyBarTimer = null;
function tourneyInfo(){
  // ソロ/ホストはG.tourney、ゲストはploPub.tourneyを参照
  if(typeof G!=='undefined' && G && G.tourney) return G.tourney;
  if(typeof ploPub!=='undefined' && ploPub && ploPub.tourney) return ploPub.tourney;
  return null;
}
function updateTourneyBar(){
  const bar = g('tourney-bar');
  if(!bar) return;
  const t = tourneyInfo();
  if(!t){ bar.style.display='none'; return; }
  bar.style.display='block';
  const per = tourneyMinForLevel(t, 0);
  const lvNow = Math.floor((Date.now() - t.startTs) / (per * 60000));
  const applied = t.level; // 適用中レベル（次のハンドから上がる）
  const [sb, bb] = tourneyBlindsAt(t, applied);
  const ante = tourneyAnteAt(t, applied);
  const nextAt = t.startTs + (lvNow + 1) * per * 60000;
  const total = per * 60000;
  const remain = Math.max(0, nextAt - Date.now());
  const elapsed = total - remain;
  const pct = Math.max(0, Math.min(100, (elapsed/total)*100));
  const mm = Math.floor(remain/60000), ss = Math.floor((remain%60000)/1000);
  const clockTxt = `${mm}:${String(ss).padStart(2,'0')}`;
  // 残り時間に応じた緊急度
  let urgency = '';
  if(remain <= 15000) urgency = 'urgent';
  else if(remain <= 60000) urgency = 'warn';

  // 残り人数・平均スタック（ホスト/ソロ=G、ゲスト=ploPub）
  let alive = 0, totalChips = 0, totalEntrants = 0;
  if(typeof G!=='undefined' && G && G.ids){
    totalEntrants = G.ids.length;
    G.ids.forEach((id,i)=>{ if(G.stacks[i]>0){ alive++; totalChips += G.stacks[i]; } });
  } else if(ploPub && Array.isArray(ploPub.players)){
    totalEntrants = ploPub.players.length;
    ploPub.players.forEach(p=>{ if((p.stack||0)>0){ alive++; totalChips += p.stack; } });
  }
  const avg = alive>0 ? Math.round(totalChips/alive) : 0;

  // 次レベルのブラインド
  const nextLv = (lvNow > applied) ? lvNow : applied+1;
  const [nsb, nbb] = tourneyBlindsAt(t, nextLv);
  const nante = tourneyAnteAt(t, nextLv);

  let nextLine;
  if(lvNow > applied){
    nextLine = `⬆ Lv${lvNow+1} ${nsb}/${nbb}${nante>0?`a${nante}`:''}`;
  } else {
    nextLine = `次 ${nsb}/${nbb}${nante>0?`a${nante}`:''}`;
  }

  bar.innerHTML = `
    <div class="tbar">
      <div class="tbar-row">
        <span class="tbar-lv">🏆 Lv ${applied+1}</span>
        <span class="tbar-blinds">${sb}/${bb}${ante>0?` <span class="muted">a${ante}</span>`:''}</span>
        <span class="tbar-clock ${urgency}">${lvNow>applied?'UP':clockTxt}</span>
      </div>
      <div class="tbar-progress ${urgency}"><span style="width:${pct}%"></span></div>
      <div class="tbar-meta">
        <span>残り <b>${alive}</b>${totalEntrants?`/${totalEntrants}`:''}人</span>
        <span>平均 <b>${avg.toLocaleString()}</b></span>
        <span>${bb>0?`<b>${Math.round(avg/bb)}</b>bb`:''}</span>
        <span class="tbar-next-inline">${nextLine}</span>
      </div>
    </div>`;
}
function startTourneyBar(){
  stopTourneyBar();
  updateTourneyBar();
  tourneyBarTimer = setInterval(updateTourneyBar, 1000);
}
function stopTourneyBar(){
  if(tourneyBarTimer){ clearInterval(tourneyBarTimer); tourneyBarTimer = null; }
  const bar = g('tourney-bar');
  if(bar) bar.style.display='none';
}

// 続きは次のブロック（CPU AI と 描画）
