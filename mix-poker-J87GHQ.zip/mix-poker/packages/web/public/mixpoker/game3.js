
// ============================================================
// CPU AI（簡易ハンド強度評価ベース）
// ============================================================

// プリフロップのハンド強度を概算（0-1）
function ploStartStrength(hole){
  // PLO系4枚スターティング: ペアランク・ダブルスーテッド・ラップ・ダングラーを理論に沿って評価
  // 定説の要点: ①4枚が連動する手が強い ②ダブルスーテッド>シングル>レインボー
  // ③ナッツ性（A入りフラッシュ・高位ストレート）が重要、低rundown(6543)は非ナッツで価値減
  // ④高ペア＋コネクト(AAJT)は高ペア＋2ペア(AAQQ)より straight 補完で僅かに上
  const ranks = hole.map(c=>c.r).sort((a,b)=>b-a);
  const counts={}; ranks.forEach(r=>counts[r]=(counts[r]||0)+1);
  let score=0;
  let pairScore=0;
  let pairRanks=[];
  for(const r in counts){
    if(counts[r]===2){ pairScore += 0.10 + (r/14)*0.14; pairRanks.push(+r); }  // AA=0.24, 22=0.11
    if(counts[r]>=3) pairScore += 0.06;                   // トリップスはアウツが死ぬので僅か
  }
  score += Math.min(0.40, pairScore);
  const bySuit={};
  hole.forEach(cd=>{ (bySuit[cd.s]=bySuit[cd.s]||[]).push(cd.r); });
  let nutFlush=0;
  for(const s in bySuit){
    if(bySuit[s].length>=2){
      const top=Math.max(...bySuit[s]);
      score += 0.05 + (top===14?0.06: top>=12?0.03:0.01); // Aハイスートが価値大
      if(top===14) nutFlush += 1;                          // ナッツフラッシュ路線
      if(bySuit[s].length>=3) score -= 0.03;              // 3枚同スートは1枚無駄
    }
  }
  const uniq=[...new Set(ranks)];
  let conn=0;
  for(let i=0;i<uniq.length-1;i++){
    const gap = uniq[i]-uniq[i+1];
    if(gap===1) conn+=0.06;
    else if(gap===2) conn+=0.035;
    else if(gap===3) conn+=0.015;
  }
  if(uniq.length===4 && (uniq[0]-uniq[3])<=4) conn += 0.07; // 完全ラップ
  conn += ranks.filter(r=>r>=10).length*0.025;              // ブロードウェイ密集
  score += conn;
  // 高ペア＋コネクトしたサイドカード（例 AAJT）への加点: ストレート補完で 2ペア型(AAQQ)より価値
  if(pairRanks.length===1){
    const pr = pairRanks[0];
    const others = uniq.filter(r=>r!==pr).sort((a,b)=>b-a);
    if(others.length>=2){
      const g = others[0]-others[1];
      if(g<=2 && others[0]>=10) score += 0.09;     // 高位コネクト側カード（JT等）
      else if(g<=2) score += 0.05;                 // 中位コネクト
    }
  }
  // ナッツ性: 低rundown（最高札が低くA・ブロードウェイ無し）は非ナッツになりやすく減点
  const hiCard = ranks[0];
  const hasBroadwayOrAce = ranks.some(r=>r>=11);
  if(!hasBroadwayOrAce && pairRanks.length===0){
    // 例: 6543, 7654 — つながってはいるがナッツになりにくい
    score -= (11 - hiCard) * 0.018;
  }
  // ナッツフラッシュ路線（A入り同色）はボーナス
  score += nutFlush * 0.03;
  if(uniq.length>=3){ // ダングラー（孤立低札）減点
    const lo = uniq[uniq.length-1];
    if(uniq[uniq.length-2]-lo>=5 && lo<=8 && counts[lo]===1) score -= 0.05;
  }
  if(ranks.includes(14)) score += 0.04;
  return Math.max(0, Math.min(1, score));
}
function plo8StartStrength(hole){
  // PLO8: ハイ方向 + ローポテンシャル（A2が圧倒的価値・スクープ志向）の複合評価
  const hi = ploStartStrength(hole);
  const lows = [...new Set(hole.map(cd=> cd.r===14?1:cd.r).filter(v=>v<=8))].sort((a,b)=>a-b);
  let lo = 0;
  if(lows.length>=2){
    const a=lows[0], b=lows[1];
    if(a===1&&b===2) lo = 0.34;       // A2: ナッツロー直行
    else if(a===1&&b===3) lo = 0.26;  // A3
    else if(a===1) lo = 0.18;         // Ax
    else if(a===2&&b===3) lo = 0.16;  // 23
    else lo = 0.10;
    if(lows.length>=3) lo += 0.06;    // ロー3枚はカウンターフィット保険
  }
  return Math.min(1, hi*0.62 + lo);
}
function cpuPreflopStrength(hole){
  if(hole.length >= 4){
    const gdNow = (typeof G!=='undefined' && G) ? (MIX_GAMES[G.currentGame]||{}) : {};
    return (gdNow.hi && gdNow.lo) ? plo8StartStrength(hole) : ploStartStrength(hole);
  }
  const ranks = hole.map(c=>c.r).sort((a,b)=>b-a);
  const suits = hole.map(c=>c.s);
  let score = 0;
  // 高いカードの存在
  const highCount = ranks.filter(r=>r>=11).length;
  score += highCount * 0.12;
  // ペア
  const counts = {}; ranks.forEach(r=>counts[r]=(counts[r]||0)+1);
  const pairs = Object.values(counts).filter(c=>c>=2).length;
  score += pairs * 0.18;
  // ダブルスーテッド（同じスートが2枚ずつ）
  const suitCounts = {}; suits.forEach(s=>suitCounts[s]=(suitCounts[s]||0)+1);
  const suited = Object.values(suitCounts).filter(c=>c>=2).length;
  if(suited >= 2) score += 0.15;
  else if(suited === 1) score += 0.07;
  // コネクテッド（連続性）
  const uniq = [...new Set(ranks)].sort((a,b)=>b-a);
  let connected = 0;
  for(let i=0;i<uniq.length-1;i++) if(uniq[i]-uniq[i+1]<=2) connected++;
  score += connected * 0.05;
  // Aの存在
  if(ranks.includes(14)) score += 0.08;
  return Math.min(1, score);
}

// ===== GTO近似エンジン =====
// モンテカルロでエクイティ（ポット取得期待割合）を計算
let CPU_ITER = 260; // シミュレーション回数

// 相手のレンジ下限を投資量から推定（投資が大きい相手ほど強い手を持つ前提でサンプリング）
// 閾値は cpuPreflopStrength のランダム分布パーセンタイルから校正済み
function oppRangeFloor(h, opp, holeN){
  const bb = h.bbAmount || 20;
  // 強制投資（ブラインド・BBアンティ）を除いた「自発的な投資」で判定
  let inv = (opp.totalBet||0) + (opp.roundBet||0);
  if(opp.idx === h.bbIdx) inv -= bb * ((typeof G!=='undefined' && G && G.tourney) ? 2 : 1);
  else if(opp.idx === h.sbIdx) inv -= Math.floor(bb/2);
  const bbInv = inv / bb;
  let tier = 0; // 0=フルレンジ
  if(bbInv >= 7) tier = 3;        // 大投資 → 上位25%
  else if(bbInv >= 2.2) tier = 2; // レイズ参加 → 上位35%
  else if(bbInv >= 0.9) tier = 1; // コール参加 → 上位55%
  if((opp.aggCnt||0) >= 2) tier = Math.min(3, tier+1); // 複数回のレイズ/ベットはレンジが強い
  if(tier === 0) return 0;
  if(holeN >= 4){
    const gdR = (typeof G!=='undefined'&&G) ? (MIX_GAMES[G.currentGame]||{}) : {};
    if(gdR.hi && gdR.lo) return tier===3 ? 0.35 : tier===2 ? 0.32 : 0.26; // plo8StartStrength校正値
    return tier===3 ? 0.30 : tier===2 ? 0.27 : 0.22; // ploStartStrength校正値
  }
  return tier===3 ? 0.19 : tier===2 ? 0.17 : 0.11;
}

let lastEqStats = null; // 直近calcEquityのハイロー統計（スクープ率/ハーフ率）
function calcEquity(h, idx, iterations){
  // ポットが大きいほど判断の重要度が高い → 反復を増やして精度を上げる
  let auto = CPU_ITER;
  if(!iterations){
    const bb = h.bbAmount||20;
    const potBB = (h.pot + h.players.reduce((s,pp)=>s+pp.roundBet,0)) / bb;
    if(potBB >= 40) auto = Math.round(CPU_ITER*1.8);
    else if(potBB >= 15) auto = Math.round(CPU_ITER*1.35);
  }
  const iters = iterations || auto;
  const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  const me = h.players[idx];
  const opps = h.players.filter((p,i)=>i!==idx && !p.folded);
  if(opps.length===0) return 1;

  // デッドカード: 自分の手札 + 公開ボード + スタッドの相手表札
  const dead = new Set();
  me.hole.forEach(c=>dead.add(c.r+c.s));
  (h.board||[]).forEach(c=>dead.add(c.r+c.s));
  // フォールドした人がテーブルに見せていた表札もデッドカード（スタッド系で重要）
  if(gd.type==='stud'){
    h.players.forEach((pp,i)=>{
      if(i===idx || !pp.folded || !pp.faceUp) return;
      pp.hole.forEach((cd,k)=>{ if(pp.faceUp[k]) dead.add(cd.r+cd.s); });
    });
  }
  // スタッド: 相手の表札は既知（伏札は未知）
  const oppKnown = opps.map(p=>{
    if(gd.type==='stud' && p.faceUp){
      const ups = p.hole.filter((c,i)=>p.faceUp[i]);
      ups.forEach(c=>dead.add(c.r+c.s));
      return {ups, total: p.hole.length};
    }
    return {ups:[], total: p.hole.length};
  });

  // 残りデッキ
  const pool = [];
  const SUITS=['s','h','d','c'];
  for(let r=2;r<=14;r++) for(const s of SUITS){ if(!dead.has(r+s)) pool.push({r,s}); }

  let totalShare = 0;
  const isHiLo = !!(gd.hi && gd.lo);
  let scoopCnt = 0, halfCnt = 0;
  // 1手あたりの計算時間を上限で打ち切る（UIフリーズ防止）。打ち切っても集めたサンプルで確率を算出
  const nowMs = ()=> (typeof performance!=='undefined' && performance.now) ? performance.now() : Date.now();
  const eqT0 = nowMs();
  const EQ_TIME_BUDGET_MS = 120;
  let done = 0;
  for(let it=0; it<iters; it++){
    // プールをシャッフル（部分Fisher-Yates: 必要分だけ）
    const deck = pool.slice();
    for(let i=deck.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [deck[i],deck[j]]=[deck[j],deck[i]]; }
    let di = 0;
    const draw1 = ()=> {
      if(di < deck.length) return deck[di++];
      // デッキ枯渇（8人スタッド等のエッジ）: 統計的近似としてプールからランダム複製しクラッシュを防ぐ
      return deck[Math.floor(Math.random()*deck.length)];
    };
    // 棄却サンプリングで戻す札は未使用部分のランダム位置へ（末尾に固めると将来札が偏る）
    const putBack = (cards)=>{
      cards.forEach(rc=>{
        const pos = di + Math.floor(Math.random()*(deck.length - di + 1));
        deck.splice(pos, 0, rc);
      });
    };
    // レンジ条件付きサンプリング: 閾値超えを採用、全試行不通過なら最良候補を採用（分布を上位へ寄せる）
    const sampleFiltered = (n, floor, scoreFn)=>{
      const first=[]; for(let k=0;k<n;k++) first.push(draw1());
      if(floor===0 || scoreFn(first) >= floor) return first;
      let best=first, bestS=scoreFn(first);
      const tries = floor >= 0.5 ? 24 : 7; // 高閾値（パット等の完成手レンジ）は試行を増やす
      for(let t=0;t<tries;t++){
        const cand=[]; for(let k=0;k<n;k++) cand.push(draw1());
        const s = scoreFn(cand);
        if(s >= floor){ putBack(best); return cand; }
        if(s > bestS){ putBack(best); bestS=s; best=cand; }
        else putBack(cand);
      }
      return best;
    };

    let myHole = me.hole.slice();
    let simBoard = (h.board||[]).slice();
    const oppHoles = [];

    if(gd.type==='community'){
      // 相手に手札を配り、ボードを5枚まで補完（投資量に応じたレンジで棄却サンプリング）
      opps.forEach((op)=>{
        const floor = oppRangeFloor(h, op, gd.holeN);
        oppHoles.push(sampleFiltered(gd.holeN, floor, cd=>cpuPreflopStrength(cd)));
      });
      while(simBoard.length < (gd.boardN||5)) simBoard.push(draw1());
    } else if(gd.type==='draw'){
      // 相手の手: 投資量+交換枚数（公開情報）に応じたレンジで棄却サンプリング
      opps.forEach((op)=>{
        const floor = drawRangeFloor(h, op, gd.evalLo);
        oppHoles.push(sampleFiltered(gd.holeN, floor, cd=>drawStrength(cd, gd.evalLo)));
      });
      const drawsLeft = (gd.drawRounds||1) - (h.drawDone||0);
      for(let d=0; d<drawsLeft; d++){ // 残り全ドローをシミュレート（トリプルドロー精度向上）
        myHole = simDrawOnce(myHole, gd, draw1, drawsLeft-d);
        for(let oi=0;oi<oppHoles.length;oi++){
          if(opps[oi].lastDraw === 0) continue; // スタンドパットの相手は完成手のまま
          oppHoles[oi] = simDrawOnce(oppHoles[oi], gd, draw1, drawsLeft-d);
        }
      }
    } else { // stud
      // 相手: 表札既知。伏せ札は投資量レンジ（3枚スターティング強度）で棄却サンプリング
      const isRazzSim = (G.currentGame === 'razz');
      opps.forEach((p,oi)=>{
        const ups = oppKnown[oi].ups;
        const downN = Math.max(0, oppKnown[oi].total - ups.length);
        const floor = studRangeFloor(h, p, isRazzSim);
        const hiloSim = !!(gd.hi && gd.lo);
        const down = downN===0 ? [] : sampleFiltered(downN, floor, cd=>{
          const start3 = cd.slice(0,2).concat(ups.slice(0,1));
          if(start3.length<3) return 1;
          return hiloSim ? studHilo3(start3) : studStart3(start3, isRazzSim);
        });
        const oh = ups.slice().concat(down);
        while(oh.length < 7) oh.push(draw1());
        oppHoles.push(oh);
      });
      while(myHole.length < 7) myHole.push(draw1());
    }

    // ショーダウン判定（doShowdownと同じ評価系を流用）
    const simH = {board: simBoard};
    const allPlayers = [{hole:myHole}, ...oppHoles.map(oh=>({hole:oh}))];
    const sh = simShare(allPlayers, simH, gd);
    totalShare += sh;
    if(isHiLo){
      if(sh >= 0.95) scoopCnt++;            // 両取り（スクープ）
      else if(sh >= 0.4 && sh <= 0.6) halfCnt++; // 片側ハーフ止まり
    }
    done++;
    // 32回ごとに経過時間をチェックし、上限を超えたら打ち切る
    if((done & 31)===0 && (nowMs() - eqT0) > EQ_TIME_BUDGET_MS) break;
  }
  const denom = done || 1;
  if(isHiLo) lastEqStats = { scoop: scoopCnt/denom, half: halfCnt/denom };
  else lastEqStats = null;
  return totalShare / denom;
}

// ドロー1回の簡易シミュレーション（CPUと同じキープロジック）
function simDrawOnce(hole, gd, draw1, drawsLeft){
  let keep;
  if(gd.evalLo==='badugi') keep = bestBadugiKeep(hole);
  else keep = bestLowKeep(hole, gd.evalLo, drawsLeft);
  const need = hole.length - keep.length;
  const nh = keep.slice();
  for(let i=0;i<need;i++){ const c=draw1(); if(c) nh.push(c); }
  return nh;
}

// players[0]（自分）のポット取得割合を返す
function simShare(players, simH, gd){
  const n = players.length;
  if(gd.hi && gd.lo){
    // Hi-Lo分割
    const hiEvals = players.map(p=>showdownEvalHi(p, simH, gd));
    const loEvals = players.map(p=>showdownEvalLo(p, simH, gd));
    let hiBest=null; hiEvals.forEach(e=>{ if(e&&(!hiBest||compareEval([e.rank,e.tiebreak],[hiBest.rank,hiBest.tiebreak])>0)) hiBest=e; });
    const hiWin = hiEvals.map(e=> e&&hiBest&&compareEval([e.rank,e.tiebreak],[hiBest.rank,hiBest.tiebreak])===0);
    let loBest=null; loEvals.forEach(e=>{ if(e&&(!loBest||cmpLoEval(e,loBest)<0)) loBest=e; });
    const loWin = loEvals.map(e=> e&&loBest&&cmpLoEval(e,loBest)===0);
    const hiWinners = hiWin.filter(Boolean).length;
    const loWinners = loWin.filter(Boolean).length;
    let share = 0;
    if(loWinners===0){
      if(hiWin[0]) share = 1/hiWinners;
    } else {
      if(hiWin[0]) share += 0.5/hiWinners;
      if(loWin[0]) share += 0.5/loWinners;
    }
    return share;
  } else if(gd.hi){
    const evals = players.map(p=>showdownEvalHi(p, simH, gd));
    let best=null; evals.forEach(e=>{ if(e&&(!best||compareEval([e.rank,e.tiebreak],[best.rank,best.tiebreak])>0)) best=e; });
    const wins = evals.map(e=> e&&best&&compareEval([e.rank,e.tiebreak],[best.rank,best.tiebreak])===0);
    const w = wins.filter(Boolean).length;
    return wins[0] ? 1/w : 0;
  } else {
    const evals = players.map(p=>showdownEvalLo(p, simH, gd));
    let best=null; evals.forEach(e=>{ if(e&&(!best||cmpLoEval(e,best)<0)) best=e; });
    const wins = evals.map(e=> e&&best&&cmpLoEval(e,best)===0);
    const w = wins.filter(Boolean).length;
    return wins[0] ? 1/w : 0;
  }
}

// GTO風意思決定 v2（MDF・ポジション・ベットサイズミックス・最終ストリートのブラフ均衡）
// ===== GTOソルバー出力テーブル =====
// プッシュ/フォールドはfictitious playで計算したナッシュ均衡（169ハンド×スタック4-20BB）
// オープン/3ベットはGTOソルバー解の代表レンジ。hex43桁=169bit、bit i=GTO_CLASSES[i]
const GTO_CLASSES = ["22", "32o", "32s", "33", "42o", "42s", "43o", "43s", "44", "52o", "52s", "53o", "53s", "54o", "54s", "55", "62o", "62s", "63o", "63s", "64o", "64s", "65o", "65s", "66", "72o", "72s", "73o", "73s", "74o", "74s", "75o", "75s", "76o", "76s", "77", "82o", "82s", "83o", "83s", "84o", "84s", "85o", "85s", "86o", "86s", "87o", "87s", "88", "92o", "92s", "93o", "93s", "94o", "94s", "95o", "95s", "96o", "96s", "97o", "97s", "98o", "98s", "99", "T2o", "T2s", "T3o", "T3s", "T4o", "T4s", "T5o", "T5s", "T6o", "T6s", "T7o", "T7s", "T8o", "T8s", "T9o", "T9s", "TT", "J2o", "J2s", "J3o", "J3s", "J4o", "J4s", "J5o", "J5s", "J6o", "J6s", "J7o", "J7s", "J8o", "J8s", "J9o", "J9s", "JTo", "JTs", "JJ", "Q2o", "Q2s", "Q3o", "Q3s", "Q4o", "Q4s", "Q5o", "Q5s", "Q6o", "Q6s", "Q7o", "Q7s", "Q8o", "Q8s", "Q9o", "Q9s", "QTo", "QTs", "QJo", "QJs", "QQ", "K2o", "K2s", "K3o", "K3s", "K4o", "K4s", "K5o", "K5s", "K6o", "K6s", "K7o", "K7s", "K8o", "K8s", "K9o", "K9s", "KTo", "KTs", "KJo", "KJs", "KQo", "KQs", "KK", "A2o", "A2s", "A3o", "A3s", "A4o", "A4s", "A5o", "A5s", "A6o", "A6s", "A7o", "A7s", "A8o", "A8s", "A9o", "A9s", "ATo", "ATs", "AJo", "AJs", "AQo", "AQs", "AKo", "AKs", "AA"];
const GTO_CIDX = {}; GTO_CLASSES.forEach((h,i)=>GTO_CIDX[h]=i);
const GTO_T = {"RFI": {"utg": "1ffaaa8fe0001f0000c000100008001000801008109", "hj": "1ffeaaaff5501fa800f000180008001000801008109", "co": "1fffaaaffd555feaa0f5401a000c001000801008109", "btn": "1ffffeafffd55ffeaaffd55feaaf541a00c01008109", "sb": "1ffffaafffd55ffaaaff555faa8f401a00c01008109"}, "TBV": "1e00000800001000008000000000000000000000000", "TBB": "00000aa110000200000000080004000000400000000", "FLAT": "03faaa87f0000f0000e000100008001000801008109", "PUSH": {"4": "1ffffffffffffffffffffffffeaff51fa0f41a0d109", "6": "1ffffffffffffffffffff55feaafd51ea0f41e8d589", "8": "1fffffffffffffffeaffd55faa0f501ea0f41e8d589", "10": "1ffffffffffffffaaaff545fa80f501ea0f41e8d189", "12": "1fffffffffff5feaaafd541ea80f501e80f41a0d109", "15": "1fffffffffd55faaa0fd401ea00f501e80d41a0d109", "20": "1ffffffff5551fa2a0f5001ea00f501a80d01a0d109"}, "CALL": {"4": "1ffffffffffffffffffffffffeaff51f80f41a0d109", "6": "1fffffffffffffffeaffd41fa00f001800801008109", "8": "1fffffffffffdffea0fd001e800c001000801008109", "10": "1ffffffffff51fe800fc00180008001000801008109", "12": "1fffffffffd01fa000f000100008001000801008109", "15": "1fffffeffc001f8000c000100008001000801008108", "20": "1ffffa8ff0001a00008000100008001000801008108"}, "PUSH2": {"4": "1ffffffffffd5ffa00fc00180008001000801008109", "6": "1fffffffffd01f8000c000100008001000801008109", "8": "1ffffffffd001e00008000100008001000801008109", "10": "1fffffaff0001a00008000100008001000801008109", "12": "1ffffaaff0001800008000100008001000801008109", "15": "1fffea8fc0001000008000100008001000801008108", "20": "1ffe800f00001000008000100008001000801008108"}, "PUSH4": {"4": "1ffffffffff51fe000f000100008001000801008108", "6": "1fffffeffc001e00008000100008001000801008108", "8": "1ffffa8ff0001800008000100008001000801008108", "10": "1fffe80fc0001000008000100008001000801008100", "12": "1fffa00f40001000008000100008001000801008100", "15": "1ffe800c00001000008000100008001000801008100", "20": "1ff8000800001000008000100008001000801008000"}, "PUSH7": {"4": "1ffffffffff41fe000f000100008001000801008108", "6": "1fffffaffc001e00008000100008001000801008108", "8": "1fffea8ff0001800008000100008001000801008100", "10": "1fffa00fc0001000008000100008001000801008100", "12": "1ffe800f00001000008000100008001000801008100", "15": "1ffe000c00001000008000100008001000801008100", "20": "1ff0000800001000008000100008001000801000000"}};
function handClass169(c1, c2){
  const R='23456789TJQKA';
  if(c1.r===c2.r) return R[c1.r-2]+R[c1.r-2];
  const hi = c1.r>c2.r?c1:c2, lo = c1.r>c2.r?c2:c1;
  return R[hi.r-2]+R[lo.r-2]+(c1.s===c2.s?'s':'o');
}
function gtoIn(hex, cls){
  const idx = GTO_CIDX[cls];
  if(idx==null) return false;
  const nib = parseInt(hex[42 - (idx>>2)], 16);
  return !!((nib >> (idx & 3)) & 1);
}
function gtoNearestS(bb){
  const S=[4,6,8,10,12];
  let best=S[0], bd=1e9;
  S.forEach(s=>{ const d=Math.abs(s-bb); if(d<bd){bd=d;best=s;} });
  return best;
}
// NLH専用: ソルバーテーブルに基づく初回ラウンド判断（該当しない局面はnullで従来ロジックへ）
function nlhTableDecide(h, idx, p, gd, limits){
  const toCall = limits.toCall;
  const bb = h.bbAmount||20;
  const cls = handClass169(p.hole[0], p.hole[1]);
  const r = Math.random();
  const stackBB = (p.stack + p.roundBet) / bb;
  const oppN = h.players.filter((pp,i)=>i!==idx && !pp.folded).length;

  // ナッシュ・プッシュ/フォールド（12BB以下）
  if(limits.betting==='nl' && stackBB <= 12){
    const S = gtoNearestS(stackBB);
    const facingAllIn = toCall >= (p.stack + p.roundBet) * 0.6;
    if(facingAllIn) return gtoIn(GTO_T.CALL[S], cls) ? {type:'call'} : {type:'fold'};
    const pushHex = oppN<=1 ? GTO_T.PUSH[S] : oppN<=3 ? GTO_T.PUSH2[S] : oppN<=5 ? GTO_T.PUSH4[S] : GTO_T.PUSH7[S];
    if(gtoIn(pushHex, cls) && limits.canRaise) return {type:'raise', amount: limits.maxRaiseTo};
    if(toCall===0) return {type:'check'};
    if(toCall <= bb && gtoIn(GTO_T.CALL[S], cls)) return {type:'call'}; // BB好オッズ
    return {type:'fold'};
  }

  const openAmt = ()=> limits.betting==='fl' ? limits.minRaiseTo
    : Math.min(limits.maxRaiseTo, Math.max(limits.minRaiseTo, Math.floor(bb*2.5)));
  const reraiseAmt = ()=> limits.betting==='fl' ? limits.minRaiseTo
    : Math.min(limits.maxRaiseTo, Math.max(limits.minRaiseTo, h.highBet*3));

  // ポジション名（ボタンからの距離）
  let posName;
  if(idx===h.sbIdx) posName='sb';
  else if(idx===h.bbIdx) posName='bb';
  else {
    let d=0, cur=(typeof G!=='undefined'&&G)?G.buttonIdx:0;
    const n=h.players.length;
    while(cur!==idx && d<n){ cur=(cur-1+n)-Math.floor((cur-1+n)/n)*n; d++; }
    posName = d===0?'btn' : d===1?'co' : d===2?'hj' : 'utg';
  }

  const unopened = h.highBet <= bb*1.05;
  if(unopened){
    if(posName==='bb' && toCall===0){
      if(gtoIn(GTO_T.TBV, cls) && limits.canRaise && r<0.8) return {type:'raise', amount: openAmt()};
      return {type:'check'};
    }
    const rfiHex = GTO_T.RFI[posName==='bb' ? 'sb' : posName];
    if(gtoIn(rfiHex, cls) && limits.canRaise){
      return r<0.97 ? {type:'raise', amount: openAmt()} : {type:'call'};
    }
    return toCall===0 ? {type:'check'} : {type:'fold'};
  }
  // オープンに直面
  const facing = h.highBet / bb;
  if(facing <= 5){
    if(gtoIn(GTO_T.TBV, cls)){
      if(limits.canRaise && r<0.72) return {type:'raise', amount: reraiseAmt()};
      return {type:'call'};
    }
    if(gtoIn(GTO_T.TBB, cls) && limits.canRaise && r<0.5) return {type:'raise', amount: reraiseAmt()};
    if(gtoIn(GTO_T.FLAT, cls) || gtoIn(GTO_T.TBB, cls)) return {type:'call'};
    // 投機的コール: ポケットペア・スーテッド・ブロードウェイは小さめのオープンに広くコール
    const isPair = cls.length===2;
    const isSuited = cls.endsWith('s');
    const R='23456789TJQKA';
    const hiR = R.indexOf(cls[0])+2;
    const loR = cls.length===2 ? hiR : R.indexOf(cls[1])+2;
    const speculative = isPair || isSuited || (hiR>=11 && loR>=9); // ペア/スーテッド/ブロードウェイ
    if(speculative && facing<=3.2 && toCall <= (p.stack+p.roundBet)*0.12 && r<0.55) return {type:'call'};
    return {type:'fold'};
  }
  // 3ベット以上に直面: QQ+/AKは4ベット/コール、それ以外はエクイティ判断へ
  if(gtoIn(GTO_T.TBV, cls)){
    if((cls==='AA'||cls==='KK'||cls==='QQ'||cls==='AKs') && limits.canRaise && r<0.6)
      return {type:'raise', amount: reraiseAmt()};
    return {type:'call'};
  }
  return null;
}

// ===== 初回ベッティングラウンドのレンジ戦略 =====
// ボードテクスチャ: 0=ドライ〜1=ウェット（GTOのベット頻度/サイズ調整用）
function boardTexture(board){
  if(!board || board.length<3) return 0.5;
  const rs = board.map(cd=>cd.r).sort((a,b)=>b-a);
  const suits = {};
  board.forEach(cd=>suits[cd.s]=(suits[cd.s]||0)+1);
  const maxSuit = Math.max(...Object.values(suits));
  let t = 0;
  if(maxSuit>=4) t += 0.50;
  else if(maxSuit===3) t += (board.length===3 ? 0.45 : 0.30); // フロップモノトーンは超ウェット
  else if(maxSuit===2 && board.length===3) t += 0.12;
  const uniq=[...new Set(rs)];
  let conn=0;
  for(let i=0;i<uniq.length-1;i++){ const gap=uniq[i]-uniq[i+1]; if(gap===1) conn+=2.0; else if(gap===2) conn+=1; }
  t += Math.min(0.40, conn*0.11);
  if(uniq.length < board.length) t -= 0.08; // ペアボードはドロー減
  if(rs[0]>=11 && rs[1]>=10) t += 0.08;     // ブロードウェイ集中
  return Math.max(0, Math.min(1, t));
}
// リバーブラフのブロッカー: ナッツ級（フラッシュ）の键札を自分が握っていればブラフ価値増
function bluffBlockerBonus(h, p, gd){
  if(gd.type!=='community') return 1.0;
  const board = h.board||[];
  if(board.length<4) return 1.0;
  const suits={};
  board.forEach(cd=>suits[cd.s]=(suits[cd.s]||0)+1);
  let bonus = 1.0;
  for(const s in suits){
    if(suits[s]>=3){
      if(p.hole.some(cd=>cd.s===s && cd.r===14)) bonus = Math.max(bonus, 1.6);      // ナッツフラッシュブロッカー
      else if(p.hole.some(cd=>cd.s===s && cd.r>=13)) bonus = Math.max(bonus, 1.3);
    }
  }
  return bonus;
}
function isFirstRound(h, gd){
  if(gd.type==='community') return h.phase==='preflop';
  if(gd.type==='draw') return (h.drawDone||0)===0;
  return (h.studStreet||3)===3;
}
function relPos01(h, idx){
  const n = h.players.length;
  if(n<=2) return (typeof G!=='undefined' && G && idx===G.buttonIdx) ? 1 : 0.5;
  if(idx===h.sbIdx) return 0.3;
  if(idx===h.bbIdx) return 0.35;
  let d=0, cur=(typeof G!=='undefined'&&G)?G.buttonIdx:0;
  while(cur!==idx && d<n){ cur=(cur-1+n)%n; d++; }
  return Math.max(0.2, 1 - d/Math.max(2, n-2)); // 人数で正規化（BTN=1.0、最アーリー≒0.2）
}
function studHilo3(cards){
  // スタッドHi-Lo: ロー3枚 or ハイの強い方 + 両立（スクープ）ボーナス
  const hiS = studStart3(cards, false);
  const loS = studStart3(cards, true);
  return Math.min(1, Math.max(hiS, loS*0.92) + Math.min(hiS, loS)*0.18);
}
function strengthOf(p, gd){
  if(gd.type==='community') return cpuPreflopStrength(p.hole);
  if(gd.type==='draw') return drawStrength(p.hole, gd.evalLo);
  if(gd.hi && gd.lo) return studHilo3(p.hole.slice(0,3));
  return studStart3(p.hole.slice(0,3), (typeof G!=='undefined'&&G&&G.currentGame==='razz'));
}
function openThr(gd, pos){
  // ポジション別オープン閾値（種目別strength分布の校正値から: BTN広い・アーリー狭い）
  // ※全体的に少し緩めに調整（CPUがタイト過ぎる問題の修正）
  if(gd.type==='community'){
    if(gd.holeN>=4) return (gd.hi&&gd.lo) ? (0.37-0.13*pos) : (0.30-0.12*pos); // plo8 / plo
    return 0.20-0.10*pos; // NLH（通常はテーブル判断だが保険）
  }
  if(gd.type==='draw'){
    if(gd.evalLo==='badugi') return 0.63-0.17*pos; // バドゥーギ: UTG~0.63 / BTN~0.46
    if(gd.evalLo==='a5lo') return 0.40-0.13*pos;
    return 0.35-0.08*pos;
  }
  if(gd.hi && gd.lo) return 0.34; // スタッドHi-Lo
  return (typeof G!=='undefined'&&G&&G.currentGame==='razz') ? 0.22 : 0.26; // スタッド
}
function preflopRangeDecide(h, idx, p, gd, limits, prof){
  prof = prof || {eqShift:0, bluffMul:1, raiseMul:1, err:0};
  // 難易度→プリフロップ調整: tightは参加閾値を上げ、looseは下げる
  const thrAdj = (prof.eqShift||0) * 2.0;   // strength(0-1)スケールに変換
  const RM = prof.raiseMul!=null ? prof.raiseMul : 1;
  // 弱いCPU: 一定確率でレンジ判断をミス（甘くコール）
  const pErr = prof.err || 0;
  // NLH系（2枚コミュニティ種目）はソルバーテーブルで判断
  if(gd.type==='community' && gd.holeN===2 && p.hole.length===2){
    // 弱いCPUはテーブルから外れて甘く参加するミスをたまにする
    if(pErr>0 && Math.random()<pErr*0.5){
      const toCall0 = limits.toCall;
      if(toCall0>0 && toCall0 <= (p.stack+p.roundBet)*0.25) return {type:'call'}; // ルースコール
    }
    const act = nlhTableDecide(h, idx, p, gd, limits);
    if(act) return act;
    return null; // テーブル対象外の局面はエクイティロジックへ
  }
  const toCall = limits.toCall;
  const bb = h.bbAmount||20;
  const s = strengthOf(p, gd);
  const pos = relPos01(h, idx);
  const r = Math.random();
  const openAmt = ()=> limits.betting==='fl' ? limits.minRaiseTo
    : Math.min(limits.maxRaiseTo, Math.max(limits.minRaiseTo, Math.floor(bb*2.5)));
  const reraiseAmt = ()=> limits.betting==='fl' ? limits.minRaiseTo
    : Math.min(limits.maxRaiseTo, Math.max(limits.minRaiseTo, h.highBet*3));

  // ショートスタック: プッシュ/フォールド（NLのみ・理論どおり2択へ）
  if(limits.betting==='nl' && (p.stack + p.roundBet) <= 10*bb){
    const pushThr = openThr(gd, pos) * 0.85 + thrAdj;
    if(s >= pushThr && limits.canRaise) return {type:'raise', amount: limits.maxRaiseTo};
    if(toCall>0 && toCall <= (p.stack+p.roundBet)*0.3 && s >= pushThr*0.9) return {type:'call'};
    return toCall===0 ? {type:'check'} : {type:'fold'};
  }

  const unopened = h.highBet <= bb*1.05;
  // スタッド3rdスチール: 残存2人以下で自分の表札が全員より優位なら弱い手でもレイズ
  if(gd.type==='stud' && unopened && limits.canRaise && s < openThr(gd, pos)){
    const others = h.players.filter((pp,i)=>i!==idx && !pp.folded);
    if(others.length<=2 && others.length>=1){
      const isRz = (typeof G!=='undefined'&&G&&G.currentGame==='razz') || (gd.hi&&gd.lo);
      const upv = cd => isRz ? (cd.r===14?1:cd.r) : cd.r;
      const myUps = p.hole.filter((cd,k)=>p.faceUp&&p.faceUp[k]);
      const myV = myUps.length ? upv(myUps[myUps.length-1]) : 7;
      const dominate = others.every(pp=>{
        const u = pp.hole.filter((cd,k)=>pp.faceUp&&pp.faceUp[k]);
        if(!u.length) return false;
        const v = upv(u[u.length-1]);
        return isRz ? myV < v : myV > v;
      });
      if(dominate && r < 0.30*RM) return {type:'raise', amount: limits.minRaiseTo};
    }
  }
  if(unopened){
    const thr = openThr(gd, pos) + thrAdj;
    // スタッド系の定説: 3rdストリートで参加する価値のある手は「コンプリート（フルベットへ上げる）」で入る。
    // ブリングインへのフラットコールは原則しない（安く相手を入れてしまい、良い手の価値を取れない）。
    const isStud = (gd.type==='stud');
    if(toCall===0){
      if(s >= thr && limits.canRaise && r<Math.min(0.97,0.85*RM)) return {type:'raise', amount: openAmt()};
      return {type:'check'};
    }
    // 参加するならレイズ（コンプリート）。スタッド系はコール混在をほぼ排除。
    if(s >= thr && limits.canRaise){
      const callMix = isStud ? 0.995 : 0.85; // スタッド系はほぼ必ずコンプリート
      return r<Math.min(0.995,callMix*RM) ? {type:'raise', amount: openAmt()} : {type:'call'};
    }
    // ブラインドの好オッズ防御（ホールデム/ドロー等のブラインド構造のみ。スタッドはブラインド無し）
    if(!isStud && (idx===h.sbIdx || idx===h.bbIdx) && toCall <= bb && s >= thr*0.7 && r<0.4) return {type:'call'};
    // 弱いCPU: フォールドすべき手をたまにコール（スタッドはコンプリートで参加が定説なので弱CPUのみ）
    if(pErr>0 && toCall<=bb*1.5 && Math.random()<pErr) return {type:'call'};
    return {type:'fold'};
  }
  // オープンに直面（リレイズ判断）
  const facing = h.highBet / bb;
  if(facing <= 5){
    // 3bet閾値: コミュニティは上位レンジ、ドロー/スタッドは「完成手〜強ドロー」相当の高めの値
    let thr3base;
    if(gd.type==='community' && gd.holeN>=4) thr3base = (gd.hi&&gd.lo)?0.50:0.42; // PLO/PLO8
    else if(gd.type==='draw'){
      thr3base = (gd.evalLo==='badugi') ? 0.72 : (gd.evalLo==='a5lo') ? 0.62 : 0.60; // 完成手中心
    } else if(gd.type==='stud'){
      thr3base = (gd.hi&&gd.lo) ? 0.50 : 0.46;
    } else {
      thr3base = openThr(gd, Math.min(1,pos)) + 0.10;
    }
    const thr3 = thr3base + thrAdj; // 3bet閾値（難易度で増減）
    if(s >= thr3 && limits.canRaise && r < 0.55*RM) return {type:'raise', amount: reraiseAmt()};
    if(s >= openThr(gd,pos)*0.92 + thrAdj) return {type:'call'}; // コール幅を広げる
    if(limits.canRaise && pos>0.7 && r < 0.06*RM) return {type:'raise', amount: reraiseAmt()}; // 低頻度ブラフ3bet
    if(s >= (openThr(gd,pos)+thrAdj)*0.7 && toCall<=bb*3 && r<0.5) return {type:'call'}; // 好オッズの広いコール
    if(pErr>0 && toCall<=bb*2.5 && Math.random()<pErr*0.8) return {type:'call'}; // 弱いCPUの甘いコール
    return {type:'fold'};
  }
  return null; // 大きなリレイズに直面: エクイティ計算（レンジフィルタ済み）で精密対応
}
// 残存相手の最強レンジtier（ブラフ頻度の調整用）
function oppMaxTier(h, idx){
  const bb = h.bbAmount||20;
  let mt = 0;
  h.players.forEach((pp,i)=>{
    if(i===idx || pp.folded) return;
    let inv = (pp.totalBet||0)+(pp.roundBet||0);
    if(pp.idx===h.bbIdx) inv -= bb*((typeof G!=='undefined'&&G&&G.tourney)?2:1);
    else if(pp.idx===h.sbIdx) inv -= Math.floor(bb/2);
    const bi = inv/bb;
    const t = bi>=7?3:bi>=2.2?2:bi>=0.9?1:0;
    if(t>mt) mt=t;
  });
  return mt;
}

function isFinalStreet(h, gd){
  if(gd.type==='community') return (h.board||[]).length >= (gd.boardN||5);
  if(gd.type==='draw') return (h.drawDone||0) >= (gd.drawRounds||1);
  return (h.studStreet||3) >= 7;
}
function posFactor(h, idx){
  const n = h.players.length;
  if(n<=2) return 1.0;
  if((MIX_GAMES[G.currentGame]||{}).type==='stud') return 1.0; // スタッドは表札でアクション順が決まる
  if(typeof G!=='undefined' && G && idx===G.buttonIdx) return 1.25; // ボタンは広く
  if(idx===h.sbIdx || idx===h.bbIdx) return 0.85;                  // ブラインドは狭く
  return 1.0;
}
function pickBetFrac(eq, finalSt, tex){
  const r = Math.random();
  const shift = tex==null ? 0 : (tex - 0.45) * 0.4; // ウェット→大きめ / ドライ→小さめ
  let f;
  if(eq > 0.8) f = r<0.35 ? 1.0 : (r<0.75 ? 0.75 : 0.5);     // 超強い手は大きめ多め
  else if(finalSt) f = r<0.30 ? 0.66 : (r<0.70 ? 0.85 : 1.0); // 最終ストリートはポラライズして大きめ
  else f = r<0.30 ? 0.4 : (r<0.75 ? 0.6 : 0.85);              // 序中盤は小さめ（レンジベット風）
  return Math.max(0.33, Math.min(1.1, f + shift));
}
function cpuDecide(idx){
  const h = HND();
  if(!h || idx < 0 || !h.players[idx]) return {type:'check'};
  const p = h.players[idx];
  const gd = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  const limits = calcBetLimits(h, p);
  const toCall = limits.toCall;
  const pot = limits.pot;
  const oppCount = h.players.filter((pp,i)=>i!==idx && !pp.folded).length;
  const finalSt = isFinalStreet(h, gd);
  const pf = posFactor(h, idx);

  // CPUプロファイル（難易度＋個性）。未設定時は中立
  const prof = (G.cpuProfiles && G.cpuProfiles[p.id]) || {eqShift:0, bluffMul:1, raiseMul:1, err:0};
  // ゲーム別の効き具合: セルフプレイ検証で、タイトアグレッシブ＝バリュー重視の優位が
  // 大きい種目（NLH/PLO/2-7/razz/sd）と、ほぼ効かない種目（Hi-Lo分け合い系・A5・badugi）がある。
  // 後者では攻撃寄りの倍率を中立側へ戻す（過剰なバリュー/ブラフが裏目に出るため）。
  let aggrDamp = 1.0; // 1=プロファイルそのまま, 0=完全中立
  if(G.currentGame==='studhi') aggrDamp = 0.1; // スタッドHi-Lo: 検証で攻撃寄りが裏目→ほぼ中立に
  else if(gd.hi && gd.lo) aggrDamp = 0.35;       // その他Hi-Lo分け合い（plo8: 検証で攻撃が有効）
  else if(gd.evalLo==='a5lo') aggrDamp = 0.5;    // A-5
  else if(gd.evalLo==='badugi') aggrDamp = 0.5;  // バドゥーギ
  const eqShift = (prof.eqShift || 0) * (0.5 + 0.5*aggrDamp); // 絞りも少し緩める
  const BM = 1 + ((prof.bluffMul!=null?prof.bluffMul:1) - 1) * aggrDamp; // ブラフ倍率を中立へ
  const RM = 1 + ((prof.raiseMul!=null?prof.raiseMul:1) - 1) * aggrDamp; // バリューレイズ倍率を中立へ
  const tough = !!prof.tough && aggrDamp > 0.6; // hard: 対人で厳しめ調整（Hi-Lo等では無効）
  const valueBoost = tough ? 1.18 : 1.0;        // 強い手のバリューベット頻度UP

  // 初回ベッティングラウンド: ポジション別レンジ戦略（オープン/3ベット/プッシュフォールド）
  if(isFirstRound(h, gd)){
    const dampProf = { eqShift, bluffMul: BM, raiseMul: RM, err: prof.err };
    const act = preflopRangeDecide(h, idx, p, gd, limits, dampProf);
    if(act) return act;
  }

  // FL（固定リミット）はベット単価が低く理論上よりアグレッシブが正しい
  const flAdj = limits.betting==='fl' ? 0.07 : 0;
  // 強いレンジを見せている相手にはブラフを減らす + リバーはナッツブロッカー保持でブラフ増
  const bluffVs = (1 - 0.18 * oppMaxTier(h, idx)) * (finalSt ? bluffBlockerBonus(h, p, gd) : 1);
  // ボードテクスチャ: ドライ→高頻度・小サイズ / ウェット→低頻度・大サイズ（GTOの基本）
  const tex = (gd.type==='community' && (h.board||[]).length>=3) ? boardTexture(h.board) : null;
  const texFreq = tex==null ? 0 : (0.45 - tex) * 0.25; // ドライ+0.1〜ウェット-0.14

  // エクイティ計算（モンテカルロ・レンジ加重）
  const eq = calcEquity(h, idx);
  const rnd = Math.random();

  // 弱いCPUのミス: 一定確率で「降りるべき手をコール」または「強い手を消極的に」
  if(prof.err>0 && Math.random()<prof.err){
    if(toCall>0){
      const odds = toCall/(pot+toCall);
      if(eq < odds && toCall < p.stack && Math.random()<0.6) return {type:'call'}; // ルースコール（ミス）
    } else {
      return {type:'check'}; // チェックすべきでない場面でもチェック（消極ミス）
    }
  }
  // ハイロー種目: スクープ（両取り）濃厚なら強気、ハーフ止まりならポットを膨らませない
  let hlThr = 0, hlRaiseMul = 1.0;
  if(gd.hi && gd.lo && lastEqStats){
    if(lastEqStats.scoop > 0.35) hlThr = 0.08;
    else if(lastEqStats.half > 0.5 && lastEqStats.scoop < 0.15) hlRaiseMul = 0.4;
  }

  function raiseAmt(frac){
    if(limits.betting==='fl') return limits.minRaiseTo;
    const target = h.highBet + Math.max(h.minRaise, Math.floor(pot * frac));
    return Math.max(limits.minRaiseTo, Math.min(limits.maxRaiseTo, target));
  }
  function canRaiseNow(){
    return limits.canRaise && (limits.minRaiseTo - p.roundBet) <= p.stack + toCall;
  }

  // ===== チェック可能 =====
  if(toCall === 0){
    // スタッド系の「オートベット」セオリー: 4thストリート以降、ボードが強く（最初に動く＝最強ボード）
    // 強い完成手があるなら自動的にベットして、ドローにフリーカードを与えず価値を取る・ポットを作る。
    // （3rd以降のストリートで適用。eqが十分高い＝バリュー確実な局面）
    if(gd.type==='stud' && h.studStreet>=4 && eq > 0.62 - hlThr + eqShift){
      if(canRaiseNow() && rnd < 0.94*RM) return {type:'raise', amount: raiseAmt(pickBetFrac(eq, finalSt, tex))};
      return {type:'check'};
    }
    if(eq > 0.70 - flAdj - hlThr + eqShift){
      if(canRaiseNow() && rnd < (0.85 + texFreq*0.5)*hlRaiseMul*RM*valueBoost) return {type:'raise', amount: raiseAmt(pickBetFrac(eq, finalSt, tex))};
      return {type:'check'}; // たまにトラップ
    }
    if(eq > 0.52 - flAdj - hlThr + eqShift){
      if(canRaiseNow() && rnd < (0.55 + texFreq)*hlRaiseMul*RM*valueBoost) return {type:'raise', amount: raiseAmt(pickBetFrac(eq, finalSt, tex))};
      return {type:'check'};
    }
    if(eq > 0.35){
      // セミブラフ（ドロー価値が残る間のみ。最終ストリートでは縮小）
      const f = (finalSt ? 0.10 : 0.22) * pf * bluffVs * BM / oppCount;
      if(canRaiseNow() && rnd < f) return {type:'raise', amount: raiseAmt(0.7)};
      return {type:'check'};
    }
    // 弱い手のブラフ: 最終ストリートはベットサイズに応じた均衡比率 α=s/(1+2s)
    const s = 0.7;
    const bluffF = (finalSt ? (s/(1+2*s)) * 0.9 : 0.12) * pf * bluffVs * BM / oppCount;
    if(canRaiseNow() && rnd < bluffF) return {type:'raise', amount: raiseAmt(0.7)};
    return {type:'check'};
  }

  // ===== コールが必要 =====
  const potOdds = toCall / (pot + toCall);
  const allInCall = toCall >= p.stack;
  // hard（tough）: 対人で搾取されにくくするため、ブラフキャッチを厚くする。
  //   callBoost: 要求エクイティを下げてコール域を広げる / mdfBoost: 最低防御頻度の上乗せ
  const callBoost = tough ? 0.015 : 0;   // 閾値を少しだけ下げる（搾取耐性、ただし入れすぎない）
  const mdfBoost = tough ? 0.06 : 0;     // 限界域の防御を軽く上乗せ

  if(allInCall){
    return eq > potOdds + 0.02 - callBoost ? {type:'call'} : {type:'fold'};
  }

  if(eq > 0.72 - flAdj - hlThr + eqShift){
    if(canRaiseNow() && rnd < 0.65*hlRaiseMul*RM) return {type:'raise', amount: raiseAmt(pickBetFrac(eq, finalSt, tex))};
    return {type:'call'};
  }
  if(eq > 0.55 - flAdj - hlThr + eqShift){
    if(canRaiseNow() && rnd < 0.28*hlRaiseMul*RM) return {type:'raise', amount: raiseAmt(pickBetFrac(eq, finalSt, tex))};
    return {type:'call'};
  }
  if(eq > potOdds + 0.03 + eqShift*0.5 - callBoost){
    // オッズに合う: コール主体、非最終ストリートはセミブラフレイズ少々
    if(!finalSt && canRaiseNow() && rnd < 0.10 * pf * RM) return {type:'raise', amount: raiseAmt(0.7)};
    return {type:'call'};
  }
  if(eq > potOdds - 0.05 + eqShift*0.5 - callBoost){
    return rnd < (0.60 + mdfBoost) ? {type:'call'} : {type:'fold'}; // 境界域ミックス
  }
  if(eq > potOdds - 0.12 + eqShift*0.5 - callBoost){
    // MDF確保のブラフキャッチ（降りすぎると搾取されるため一定頻度で継続）
    const mdf = pot / (pot + toCall);
    return rnd < (0.18 + 0.12*mdf + mdfBoost) ? {type:'call'} : {type:'fold'};
  }
  // オッズに大きく合わない: 基本フォールド、低頻度ブラフレイズ
  const s2 = 0.85;
  const bluffRaiseF = ((finalSt ? (s2/(1+2*s2))*0.45 : 0.07) * pf * bluffVs * BM / oppCount) * (limits.betting==='nl'?1:0.7);
  if(canRaiseNow() && rnd < bluffRaiseF) return {type:'raise', amount: raiseAmt(0.9)};
  return {type:'fold'};
}

// ============================================================
// 描画
// ============================================================
const SUIT_SYM = {c:'♣', d:'♦', h:'♥', s:'♠'};
const SUIT_COLOR = {s:'suit-black', h:'suit-red', d:'suit-blue', c:'suit-green'};
const RANK_STR = {14:'A',13:'K',12:'Q',11:'J',10:'T'};
function rankStr(r){ return RANK_STR[r] || String(r); }

function cardHTML(card, opts={}){
  if(!card) return '';
  let sizeCls = '';
  if(opts.xs) sizeCls = ' xs';
  else if(opts.sm) sizeCls = ' sm';
  if(opts.back){
    return `<div class="card${sizeCls} back${opts.up?' up':''}"></div>`;
  }
  const color = SUIT_COLOR[card.s];
  const cls = `card${sizeCls} ${color}${opts.win?' win':''}${opts.muck?' muck':''}${opts.down?' facedown':''}${opts.up?' up':''}`;
  return `<div class="${cls}"><span class="rank">${rankStr(card.r)}</span><span class="suit">${SUIT_SYM[card.s]}</span></div>`;
}

// 相手プレイヤーを縦長楕円の外周に配置する座標(%)を返す
// 自分=下中央。相手は下右→右→上→左→下左 の順で外周に沿わせる
function oppPositions(count){
  if(count<=0) return [];
  // 縦長テーブル(aspect 100/168)。上端(y<8)はヘッダーと重なるため避ける。
  // 中央のボード/ポット帯(y:40-62)も避ける。
  const presets = {
    1: [{x:50,y:14}],
    2: [{x:20,y:16},{x:80,y:16}],
    3: [{x:16,y:22},{x:50,y:12},{x:84,y:22}],
    4: [{x:14,y:34},{x:33,y:13},{x:67,y:13},{x:86,y:34}],
    5: [{x:13,y:37},{x:27,y:14},{x:50,y:11},{x:73,y:14},{x:87,y:37}],
    6: [{x:13,y:38},{x:23,y:16},{x:41,y:12},{x:59,y:12},{x:77,y:16},{x:87,y:38}],
    7: [{x:12,y:56},{x:13,y:32},{x:29,y:14},{x:50,y:11},{x:71,y:14},{x:87,y:32},{x:88,y:56}],
    8: [{x:12,y:58},{x:13,y:34},{x:28,y:15},{x:43,y:12},{x:57,y:12},{x:72,y:15},{x:87,y:34},{x:88,y:58}],
  };
  // 6人は上中央が重複しないよう個別補正
  if(count===6) return [{x:13,y:38},{x:23,y:16},{x:41,y:12},{x:59,y:12},{x:77,y:16},{x:87,y:38}];
  return presets[count] || presets[8].slice(0,count);
}

// ============================================================
// 描画共通ヘルパー（ソロ render / マルチ renderGuest で共用）
// ============================================================
function buildOppSeatHTML(d){
  const stackCls = (d.holeLen>=4?' stacked':'') + (d.holeLen>=7?' stack7':d.holeLen===6?' stack6':d.holeLen===5?' stack5':'');
  const z = d.pos.y < 18 ? (18 + Math.round(8 - Math.abs(d.pos.x-50)/7)) : (2 + Math.round(d.pos.y));
  return `
      <div class="${d.cls}" style="left:${d.pos.x}%; top:${d.pos.y}%; z-index:${z};">
        <div class="opp-cards${stackCls}">${d.cardsH}</div>
        <div class="opp-panel" style="position:relative;">
          ${d.isDealer?'<span class="opp-dealer">D</span>':''}
          <div class="opp-name">${esc(d.name)} ${d.allinBadge}</div>
          <div class="opp-meta">${d.posH}<span class="opp-stack">${d.stack}</span></div>
          ${d.actBar}
        </div>
        ${d.showPill}
        ${d.handName}
        ${d.foldPill}
        ${d.drawPill}
        ${d.pnlPill}
        ${d.roundBet>0 ? `<div class="opp-bet" style="left:50%; bottom:-18px; transform:translateX(-50%);">${d.roundBet}</div>` : ''}
      </div>`;
}
function buildMySeatHTML(d){
  return `
    <div class="${d.myCls}" style="position:relative;">
      ${d.isDealer?'<span class="opp-dealer">D</span>':''}
      <div class="my-top">
        <span class="my-name">${esc(d.name)} ${d.posH} ${d.allIn?'<span class="opp-badge-allin">ALLIN</span>':''} ${d.folded?'<span class="fold-pill" style="margin-top:0;">Fold</span>':''}</span>
        <span class="my-stack">${d.stack}</span>
        ${d.handName}
        ${d.pnl}
        ${d.roundBet>0 ? `<div class="my-bet">${d.roundBet}</div>` : ''}
      </div>
      <div class="my-cards cards-${d.holeLen}">${d.cardsH}</div>
      ${d.active ? '<div class="act-bar" style="position:absolute; left:14px; right:14px; bottom:-9px;"></div>' : ''}
    </div>`;
}
function buildActionBarHTML(limits, ctx){
  const toCall = limits.toCall, pot = limits.pot;
  let html = '<div class="action-bar">';
  if(limits.betting === 'fl'){
    html += '<div class="action-btns">';
    // ブリングインは強制ベットなのでフォールド不可。それ以外はフォールド可
    if(!ctx.isBringInChoice){
      html += `<button class="btn btn-fold" onclick="${ctx.fold}">フォールド</button>`;
    }
    if(toCall === 0){
      const checkLabel = ctx.isBringInChoice ? 'ブリングイン' : 'チェック';
      html += `<button class="btn btn-call" onclick="${ctx.check}">${checkLabel}</button>`;
    } else {
      const callAmt = Math.min(toCall, limits.stack);
      html += `<button class="btn btn-call" onclick="${ctx.call}">コール ${callAmt}</button>`;
    }
    if(limits.canRaise){
      const raiseLabel = ctx.isBringInChoice ? 'コンプリート' : (toCall>0?'レイズ':'ベット');
      html += `<button class="btn btn-raise" onclick="${ctx.raiseTo(limits.minRaiseTo)}">${raiseLabel} ${limits.minRaiseTo}</button>`;
    }
    html += '</div>';
    const cap = (ctx.raiseCount||0);
    html += `<div class="center muted small" style="margin-top:6px;">固定: ${limits.flUnit} / ベット${cap}/4${cap>=4?'（キャップ）':''}</div>`;
  } else {
    if(limits.canRaise){
      const pot3_4 = Math.max(limits.minRaiseTo, Math.min(limits.maxRaiseTo, ctx.highBet + Math.floor(pot*0.75)));
      const pot1_2 = Math.max(limits.minRaiseTo, Math.min(limits.maxRaiseTo, ctx.highBet + Math.floor(pot*0.5)));
      const potRaise = Math.max(limits.minRaiseTo, Math.min(limits.maxRaiseTo, potLimitMaxRaiseTo(pot, toCall, limits.roundBet)));
      const minR = limits.minRaiseTo;
      const initVal = pot1_2;
      const callAmt = toCall===0 ? 0 : Math.min(toCall, limits.stack);
      html += `
        <div class="jopt2">
          <div class="jopt2-presets">
            <button class="jopt2-chip" onclick="${ctx.raiseTo(minR)}"><span class="jopt2-lbl">Min</span><span class="jopt2-val">${minR}</span></button>
            <button class="jopt2-chip" onclick="${ctx.raiseTo(pot1_2)}"><span class="jopt2-lbl">½</span><span class="jopt2-val">${pot1_2}</span></button>
            <button class="jopt2-chip" onclick="${ctx.raiseTo(pot3_4)}"><span class="jopt2-lbl">¾</span><span class="jopt2-val">${pot3_4}</span></button>
            <button class="jopt2-chip" onclick="${ctx.raiseTo(potRaise)}"><span class="jopt2-lbl">Pot</span><span class="jopt2-val">${potRaise}</span></button>
          </div>
          <input type="range" id="bet-slider" class="jopt2-slider" min="${minR}" max="${limits.maxRaiseTo}" value="${initVal}" step="${ctx.bbAmount}" oninput="updateBetLabel()">
          <div class="jopt2-actions">
            <button class="btn btn-fold" onclick="${ctx.fold}">フォールド</button>
            ${toCall===0
              ? `<button class="btn btn-call" onclick="${ctx.check}">チェック</button>`
              : `<button class="btn btn-call" onclick="${ctx.call}">コール<span class="jopt2-amt">${callAmt}</span></button>`}
            <button class="btn btn-raise" onclick="${ctx.confirm}">${toCall>0?'レイズ':'ベット'}<span class="jopt2-amt" id="raise-btn-amt">${initVal}</span></button>
          </div>
        </div>`;
    } else {
      const callAmt = toCall===0 ? 0 : Math.min(toCall, limits.stack);
      html += '<div class="action-btns">';
      html += `<button class="btn btn-fold" onclick="${ctx.fold}">フォールド</button>`;
      html += toCall===0
        ? `<button class="btn btn-call" onclick="${ctx.check}">チェック</button>`
        : `<button class="btn btn-call" onclick="${ctx.call}">コール ${callAmt}</button>`;
      html += '</div>';
    }
  }
  html += '<div id="cpu-hint" class="center muted small" style="display:none; margin-top:8px;"></div>';
  html += '</div>';
  return html;
}

// アクションエリアの確保高さを種目カテゴリ別に設定する。
// これによりテーブルが手番のたびに伸縮せず、種目ごとに一定サイズで安定する。
function setActReserve(gameKey){
  const gd = MIX_GAMES[gameKey || 'holdem'];
  let px = 172;                         // NLコミュニティ（コンパクトベットUI≈164px）
  if(gd){
    if(gd.type==='draw') px = 186;      // 交換UI≈177px
    else if(gd.type==='stud') px = 128; // スタッドはFLベット≈118px
  }
  const sg = document.getElementById('screen-game');
  if(sg) sg.style.setProperty('--act-reserve', px + 'px');
}

function render(){
  const h = HND();
  if(!h) return;

  // マルチホスト: ゲストへ状態配信
  if(isHost && isMulti){ broadcastState(); }

  // 種目バー更新
  updateGameTypeBar();
  setActReserve(G && G.currentGame);

  // フェーズ（種目タイプで表示を変える）
  const phLabel = phaseLabelFor(h, G.currentGame);
  g('phase-label').textContent = phLabel;

  // ポット
  g('pot-display').textContent = `POT: ${currentPot()}`;


  // ボード（コミュニティカード or 種目情報）
  const gdCur = MIX_GAMES[G.currentGame] || MIX_GAMES.holdem;
  const winCards = new Set();
  if(h.phase==='showdown' && h.results){
    const firstWinId = h.results[0]?.winnerIds[0];
    if(firstWinId){
      const wp = h.players.find(p=>p.id===firstWinId);
      const ev = evalHiCur(wp.hole, h.board);
      if(ev) ev.cards.forEach(c=>winCards.add(c.r+c.s));
    }
  }
  if(gdCur.type==='community' || h.board.length>0){
    let boardH = '';
    const slots = gdCur.type==='community' ? (gdCur.boardN||5) : h.board.length;
    for(let i=0;i<slots;i++){
      if(h.board[i]){
        const c = h.board[i];
        boardH += cardHTML(c, {win: winCards.has(c.r+c.s)});
      } else {
        boardH += `<div class="card" style="opacity:0.35;background:transparent;border:1px dashed rgba(232,200,74,0.4);box-shadow:none;"></div>`;
      }
    }
    g('board-area').classList.toggle('six', slots>=6);
    g('board-area').innerHTML = boardH;
  } else {
    // 場札なし種目: 中央はポット表示のみ（種目名はヘッダにあるため省略）
    g('board-area').innerHTML = '';
  }

  // ===== 相手プレイヤーを楕円周囲に配置 =====
  // 自分を基準に、相手を上半分〜左右に配置
  const selfId = isMulti ? myId : 'human';
  const me = h.players.find(p=>p.id===selfId);
  const myIdx = h.players.findIndex(p=>p.id===selfId);
  // PLOリング風ヘッダー
  {
    const gdH = MIX_GAMES[G.currentGame] || {};
    const actH = h.players[h.toActIdx];
    const mineH = (h.toActIdx===myIdx && h.phase!=='showdown');
    plHeader({
      room: isMulti ? ('#'+(roomCode||'')) : '練習',
      game: gdH.short || gdH.label || G.currentGame,
      blind: (G.sb!=null&&G.bb!=null) ? (G.sb+'/'+G.bb) : '',
      canChange: !!(isHost || !isMulti),
      street: phLabel,
      turn: h.phase==='showdown' ? 'ショーダウン'
        : (mineH ? '▶ あなたのアクション' : (actH ? `▶ ${actH.name} のアクション` : '')),
      myTurn: mineH
    });
  }
  const n = h.players.length;
  // 相手のインデックス（自分の次から時計回り）
  const oppOrder = [];
  for(let k=1; k<n; k++) oppOrder.push((myIdx+k)%n);

  // 楕円周囲の座標（自分=下中央=90度を除いた位置に配置）
  // 角度を上半分に均等配置（左160°〜右20°を使う）
  const positions = oppPositions(oppOrder.length);

  let oppH = '';
  oppOrder.forEach((pi, slot)=>{
    const p = h.players[pi];
    const isActive = (h.toActIdx===pi && h.phase!=='showdown');
    const isDealer = (pi===G.buttonIdx) && (MIX_GAMES[G.currentGame]||{}).type!=='stud';
    const pos = positions[slot];
    let cls = 'opp';
    if(oppOrder.length >= 7) cls += ' compact xcompact xxcompact';
    else if(oppOrder.length >= 4) cls += ' compact xcompact';
    if(isActive) cls += ' active';
    if(p.folded) cls += ' folded';

    // カード表示の条件:
    //  マルチ: ショウダウンで降りていない相手のみ公開（通常のポーカー）
    //  ソロ: ショウダウン時は降りた相手も含め全員公開。人間が降りた後も相手の手を公開
    let cardsH = '';
    const isSolo = !isMulti;
    const humanFoldedSolo = isSolo && me && me.folded;
    // 全員フォールド勝ち(uncontested)かどうか
    const isUncontested = isMulti && h.results && h.results.length && h.results[0].uncontested;
    const showCards = isSolo
      ? (h.phase==='showdown' || humanFoldedSolo)   // ソロ: ショウダウンで全員公開
      : isUncontested
        ? (winTheShow && !p.folded)                 // マルチ全員フォールド: WIN THE SHOWがONの時だけ勝者公開
        : (h.phase==='showdown' && !p.folded);      // マルチ通常ショウダウン: 降りていない人を公開
    const isStud = (MIX_GAMES[G.currentGame]||{}).type === 'stud';
    // スタッド系: 降りた人の表向き札は場から引き上げられるので表示しない
    const studFolded = isStud && p.folded;
    if(studFolded){
      cardsH = '';
    } else if(p.hole.length){
      const studHidden = isStud && !showCards && p.faceUp;
      if(studHidden){
        // スタッド: 裏向き札を先にまとめ、表向き札(ドアカード)は重ねず横並びで全部見せる
        const downs=[], ups=[];
        p.hole.forEach((c,ci)=>{ if(p.faceUp[ci]) ups.push(cardHTML(c,{xs:true, up:true})); else downs.push('<div class="card xs back"></div>'); });
        cardsH = downs.join('') + ups.join('');
      } else if(isStud && showCards){
        // スタッドのショーダウン: 7枚すべて重ねず見せる
        p.hole.forEach(c=>{ cardsH += cardHTML(c,{xs:true, up:true, muck:p.folded}); });
      } else {
        p.hole.forEach((c,ci)=>{
          if(showCards){
            cardsH += cardHTML(c,{xs:true, muck:p.folded}); // 降りた相手は暗めに表示
          } else if(isStud && p.faceUp && p.faceUp[ci]){
            cardsH += cardHTML(c,{xs:true}); // 表札
          } else {
            cardsH += `<div class="card xs back"></div>`; // 伏札
          }
        });
      }
    }

    // 役名（ソロは降りた相手の役名も表示。マルチは降りていない相手のみ）
    let handName = '';
    const showName = isSolo
      ? (h.phase==='showdown' && h.handNames && h.handNames[p.id])
      : (h.phase==='showdown' && !p.folded && h.handNames && h.handNames[p.id]);
    if(showName){
      handName = `<div class="opp-hand-name">${h.handNames[p.id]}</div>`;
    }

    const allinBadge = p.allIn ? '<span class="opp-badge-allin">ALLIN</span>' : '';
    const isUncontestedWinner = isMulti && winTheShow && h.results && h.results.length && h.results[0].uncontested
      && (h.results.flatMap(r=>r.winnerIds||[]).includes(p.id));
    const showPill = isUncontestedWinner ? `<div class="show-pill">🏆 WIN THE SHOW</div>` : '';
    const pb = posBadge(h, pi);
    const posH = pb ? `<span class="pos-badge">${pb}</span>` : '';
    const foldPill = p.folded ? `<div class="fold-pill">Fold</div>` : '';
    const actBar = isActive ? `<div class="act-bar"></div>` : '';
    // ドロー系: 直近の交換枚数（フォールド者には不要）
    const isDrawGame = (MIX_GAMES[G.currentGame]||{}).type === 'draw';
    const drawPill = (isDrawGame && !p.folded && p.lastDraw!=null)
      ? `<div class="draw-pill">${p.lastDraw>0 ? '🔄 '+p.lastDraw+'枚' : 'スタンド'}</div>` : '';
    // ショーダウン時の収支
    let pnlPill = '';
    if(h.phase==='showdown' && p.startStack!=null){
      const d = p.stack - p.startStack;
      const pc = d>0?'pnl-plus':(d<0?'pnl-minus':'pnl-zero');
      pnlPill = `<div class="pnl-pill ${pc}">${d>0?'+'+d:(d<0?d:'±0')}</div>`;
    }

    oppH += buildOppSeatHTML({
      cls, pos, cardsH, holeLen: p.hole.length, isDealer,
      name: p.name, allinBadge, posH, stack: p.stack, actBar,
      showPill, handName, foldPill, drawPill, pnlPill, roundBet: p.roundBet
    });
  });
  g('opponents').innerHTML = oppH;

  // ===== 自分（テーブル下） =====
  const meActive = (h.toActIdx===myIdx && h.phase!=='showdown');
  const meDealer = (myIdx===G.buttonIdx);
  let myCardsH = '';
  if(me.hole.length){
    const isStudMe = (MIX_GAMES[G.currentGame]||{}).type === 'stud';
    me.hole.forEach((c,ci)=>{
      const down = isStudMe && me.faceUp && me.faceUp[ci]===false;
      myCardsH += cardHTML(c,{sm:true, muck:me.folded, down});
    });
  }
  let myHandName = '';
  if(h.phase==='showdown' && !me.folded && h.handNames && h.handNames[selfId]){
    myHandName = `<div class="my-hand-name">${h.handNames[selfId]}</div>`;
  } else if(me.hole.length && h.board.length>=3 && !me.folded){
    // 自分の現在の役を常時表示（具体名）。完成役が低い時はドロー情報も添える
    const ev = evalHiCur(me.hole, h.board);
    if(ev){
      let txt = ev.detail || ev.name;
      const gdNow = MIX_GAMES[(G&&G.currentGame)||'holdem'];
      if(gdNow && gdNow.type==='community' && ev.rank<=1){ // ハイカード/ワンペアの時だけドロー表示
        const dr = detectDraws(me.hole, h.board, gdNow.plo, gdNow.boardN);
        if(dr.length) txt += ` <span class="draw-tag">+${dr.join('・')}</span>`;
      }
      myHandName = `<div class="my-hand-name">${txt}</div>`;
    }
  }
  let myCls = 'my-seat';
  if(meActive) myCls += ' active';
  if(me.folded) myCls += ' folded';
  const myPb = posBadge(h, myIdx);
  const myPosH = myPb ? `<span class="pos-badge">${myPb}</span>` : '';
  let myPnl = '';
  if(h.phase==='showdown' && me.startStack!=null){
    const d = me.stack - me.startStack;
    const pc = d>0?'pnl-plus':(d<0?'pnl-minus':'pnl-zero');
    myPnl = `<span class="pnl-pill ${pc}" style="margin-top:0;">${d>0?'+'+d:(d<0?d:'±0')}</span>`;
  }
  g('my-seat').innerHTML = buildMySeatHTML({
    myCls, isDealer: meDealer, name: me.name, posH: myPosH,
    allIn: me.allIn, folded: me.folded, stack: me.stack,
    handName: myHandName, pnl: myPnl, roundBet: me.roundBet,
    holeLen: me.hole.length, cardsH: myCardsH, active: meActive
  });

  // アクションエリア
  renderActionArea();

  // ログ
  g('log').innerHTML = G.log.slice(0,12).map(l=>`<div>${esc(l)}</div>`).join('');
}

function renderActionArea(){
  const h = HND();
  const area = g('action-area');
  const selfId = isMulti ? myId : 'human';
  if(h.phase==='showdown' || h.toActIdx<0 || h.players[h.toActIdx].id!==selfId){
    area.innerHTML = '';
    return;
  }
  const me = h.players[h.toActIdx];
  const limits = calcBetLimits(h, me);
  limits.stack = me.stack; limits.roundBet = me.roundBet;
  const isBringInChoice = h.bringInPending && h.toActIdx===h.bringInIdx && limits.toCall===0;
  const ctx = {
    fold: "humanAction({type:'fold'})",
    check: "humanAction({type:'check'})",
    call: "humanAction({type:'call'})",
    raiseTo: (amt)=>`humanAction({type:'raise', amount:${amt}})`,
    confirm: "confirmRaise()",
    bbAmount: h.bbAmount, highBet: h.highBet, raiseCount: h.raiseCount,
    isBringInChoice
  };
  area.innerHTML = buildActionBarHTML(limits, ctx);
  updateCpuHint();
}

function updateBetLabel(){
  const v = g('bet-slider').value;
  const ba = g('bet-amount');
  if(ba) ba.textContent = v;
  const rb = g('raise-btn-amt');
  if(rb) rb.textContent = v;
}
function confirmRaise(){
  const to = parseInt(g('bet-slider').value);
  humanAction({type:'raise', amount: to});
}

// ============================================================
// マルチプレイ（Firebase）
// ============================================================
const FB_URL = 'https://playgame-3e7ba-default-rtdb.firebaseio.com';
let fbRoom = '';
let fbListener = null;
let fbLastSeen = {};

async function fbPut(sub, data){
  if(!fbRoom) return;
  try { await fetch(`${FB_URL}/rooms/${fbRoom}/${sub}.json`, {method:'PUT', body:JSON.stringify(data)}); } catch(e){}
}
async function fbGet(sub){
  if(!fbRoom) return null;
  try { const r = await fetch(`${FB_URL}/rooms/${fbRoom}/${sub}.json`); return await r.json(); } catch(e){ return null; }
}
async function fbDel(sub){
  if(!fbRoom) return;
  try { await fetch(`${FB_URL}/rooms/${fbRoom}/${sub}.json`, {method:'DELETE'}); } catch(e){}
}
async function fbBroadcast(msg){
  if(!fbRoom) return;
  const k = 'b_' + Date.now() + '_' + Math.floor(Math.random()*1000);
  await fbPut('broadcast/' + k, {...msg, ts:Date.now()});
}
async function fbSendTo(pid, msg){
  if(!fbRoom) return;
  const k = 'p_' + Date.now() + '_' + Math.floor(Math.random()*1000);
  await fbPut(`private/${pid}/${k}`, {...msg, ts:Date.now()});
}
async function fbSendToHost(msg){
  if(!fbRoom) return;
  const k = 'h_' + Date.now() + '_' + Math.floor(Math.random()*1000);
  await fbPut(`action/${k}`, {...msg, sender:myId, ts:Date.now()});
}
function fbListen(){
  if(fbListener) clearInterval(fbListener);
  fbListener = setInterval(fbPoll, 1000);
  fbPoll();
}
async function fbPoll(){
  if(!fbRoom) return;
  const b = await fbGet('broadcast') || {};
  Object.entries(b).forEach(([k,v])=>{ if(!v||fbLastSeen[k]) return; fbLastSeen[k]=true; onMsg(v, v.sender); });
  const p = await fbGet(`private/${myId}`) || {};
  Object.entries(p).forEach(([k,v])=>{ if(!v||fbLastSeen['p_'+k]) return; fbLastSeen['p_'+k]=true; onMsg(v, null); });
  if(isHost){
    const a = await fbGet('action') || {};
    Object.entries(a).forEach(([k,v])=>{ if(!v||fbLastSeen['a_'+k]) return; fbLastSeen['a_'+k]=true; onMsg(v, v.sender); });
  }
}
function fbClose(){
  if(fbListener) clearInterval(fbListener);
  fbListener = null; fbRoom = ''; fbLastSeen = {};
}

function ploSetErr(m){ const el=g('lobby-error'); if(el) el.textContent=m||''; }
function ploSetSt(m){ const el=g('lobby-status'); if(el) el.textContent=m||''; }

// ===== 部屋作成（ホスト） =====
async function ploCreateRoom(){
  const nm = g('my-name').value.trim();
  if(!nm){ ploSetErr('ニックネームを入力してください'); return; }
  myName = nm;
  myId = 'host_' + Math.floor(Math.random()*100000);
  isHost = true; isMulti = true;
  roomCode = String(Math.floor(1000 + Math.random()*9000));
  fbRoom = 'PL-' + roomCode;
  ploSetSt('部屋を作成中...');
  await fbPut('meta', {host:myId, game:'plo', stack:soloStack, sb:soloSB, bb:soloBB, ts:Date.now()});
  waitingPlayers = [{id:myId, name:myName, isHost:true}];
  await fbPut('waiting', waitingPlayers);
  fbListen();
  ploSaveSession();
  show('waiting');
  g('disp-code').textContent = roomCode;
  g('wait-blind-info').textContent = `スタック${soloStack} / SB${soloSB} BB${soloBB}`;
  g('btn-start-game').style.display = '';
  g('wait-host-note').textContent = '2人以上集まったら開始できます';
  renderWaitingPlayers();
}

// ===== 部屋参加（ゲスト） =====
async function ploJoinRoom(){
  const nm = g('my-name').value.trim();
  if(!nm){ ploSetErr('ニックネームを入力してください'); return; }
  const code = g('join-code').value.trim();
  if(code.length !== 4){ ploSetErr('部屋コードは4桁です'); return; }
  myName = nm;
  myId = 'guest_' + Math.floor(Math.random()*100000);
  isHost = false; isMulti = true;
  roomCode = code;
  fbRoom = 'PL-' + code;
  ploSetSt('接続中...');
  const meta = await fbGet('meta');
  if(!meta){ ploSetErr('部屋が見つかりません'); ploSetSt(''); fbRoom=''; return; }
  soloStack = meta.stack; soloSB = meta.sb; soloBB = meta.bb;
  fbListen();
  await fbSendToHost({type:'join', name:myName, id:myId});
  initSession('multi');
  ploSaveSession();
  show('waiting');
  g('disp-code').textContent = roomCode;
  g('wait-blind-info').textContent = `スタック${soloStack} / SB${soloSB} BB${soloBB}`;
  g('btn-start-game').style.display = 'none';
  g('wait-host-note').textContent = 'ホストの開始を待っています...';
  ploSetSt('');
}

function renderWaitingPlayers(){
  const list = isHost ? waitingPlayers : (ploPub?.waitingPlayers || []);
  g('wait-players').innerHTML = list.map(p=>
    `<div class="result-row"><span>${p.isHost?'👑':'🧑'} ${esc(p.name)}</span></div>`
  ).join('');
}

// ===== メッセージ処理 =====
function onMsg(msg, sender){
  if(isHost){
    if(msg.type === 'join'){
      const inGame = !!(G && G.ids && G.ids.length);
      if(inGame){
        // ゲーム進行中の途中参加（次ハンドから）
        if(G.ids.includes(msg.id)){
          // 既存プレイヤーの再接続: 状態を再送
          broadcastState();
          return;
        }
        if(pendingJoins.find(p=>p.id===msg.id)) return; // 二重join無視
        if(G.ids.length + pendingJoins.length >= 8){
          fbSendTo(msg.id, {type:'rejected', reason:'満員です（最大8人）'});
          return;
        }
        pendingJoins.push({id:msg.id, name:msg.name});
        G.log.unshift(`👋 ${msg.name} が参加します（次のハンドから）`);
        // 観戦できるよう現在の状態を送る
        broadcastState();
        render();
      } else {
        // 開始前（待機中）
        if(!waitingPlayers.find(p=>p.id===msg.id)){
          if(waitingPlayers.length >= 8){ fbSendTo(msg.id, {type:'rejected', reason:'満員です（最大8人）'}); return; }
          waitingPlayers.push({id:msg.id, name:msg.name, isHost:false});
          fbPut('waiting', waitingPlayers);
          fbBroadcast({type:'waiting_update', waitingPlayers});
          renderWaitingPlayers();
        }
      }
    } else if(msg.type === 'action'){
      handleGuestAction(msg.sender, msg.action);
    } else if(msg.type === 'rebuy'){
      handleGuestRebuy(msg.sender, msg.amount);
    } else if(msg.type === 'draw_response'){
      handleGuestDraw(msg.sender, msg.discard);
    }
  } else {
    if(msg.type === 'waiting_update'){
      ploPub = ploPub || {};
      ploPub.waitingPlayers = msg.waitingPlayers;
      if(g('screen-waiting').classList.contains('active')) renderWaitingPlayers();
    } else if(msg.type === 'tourney_end'){
      stopTourneyBar();
      show('result');
      g('result-detail').innerHTML = tourneyRankingHTML(msg.ranks||{}, msg.names||{}, msg.ids||[], msg.handNo||0, msg.level||0);
      const rbtn = g('result-detail').parentElement.querySelector('button');
      if(rbtn) rbtn.style.display='none';
    } else if(msg.type === 'state'){
      ploPub = msg.pub;
      if(ploPub && ploPub.tourney && !tourneyBarTimer) startTourneyBar();
      // Firebase空配列削除対策: 必須配列を正規化
      if(ploPub){
        if(!Array.isArray(ploPub.board)) ploPub.board = [];
        if(!Array.isArray(ploPub.players)) ploPub.players = [];
        if(!Array.isArray(ploPub.results) && ploPub.results) ploPub.results = [];
        ploPub.players.forEach(p=>{
          if(p.hole && !Array.isArray(p.hole)) p.hole = null;
          if(p.upCards && !Array.isArray(p.upCards)) p.upCards = null;
        });
        ploPub.pot = ploPub.pot || 0;
        ploPub.roundBetTotal = ploPub.roundBetTotal || 0;
        ploPub.highBet = ploPub.highBet || 0;
      }
      onGuestStateUpdate();
    } else if(msg.type === 'your_hand'){
      ploMyHole = Array.isArray(msg.hole) ? msg.hole : [];
      ploMyFaceUp = Array.isArray(msg.faceUp) ? msg.faceUp : [];
      onGuestStateUpdate();
    } else if(msg.type === 'draw_request'){
      showGuestDrawUI(msg.gameKey);
    } else if(msg.type === 'rejected'){
      ploSetErr('参加できませんでした: ' + (msg.reason||''));
      show('lobby'); fbClose();
    }
  }
}

// ===== ホスト: ゲーム開始 =====
function ploHostStart(){
  if(waitingPlayers.length < 2){ alert('2人以上必要です'); return; }
  const ids = waitingPlayers.map(p=>p.id);
  const names = {};
  waitingPlayers.forEach(p=>names[p.id]=p.name);
  G = { ids, names, stacks: ids.map(()=>soloStack), buttonIdx: Math.floor(Math.random()*ids.length), handNo: 0, log: [], isMulti: true, currentGame: hostSelectedGame || 'holdem', cpuLevel };
  G.cpuProfiles = buildAllCpuProfiles();
  initRotation();
  initSession('multi');
  if(gameFormat === 'tourney'){
    G.tourney = {startTs: Date.now(), levelMin: tourneyLevelMin, structKey: tourneyStructKey, level: 0, ranks: {}};
    soloSB = 10; soloBB = 20;
    G.log.unshift(`🏆 トーナメント開始！ ${tourneyLevelMin}分ごとにブラインドアップ`);
  }
  show('game');
  startTourneyBar();
  startNewHand();
}

function handleGuestAction(senderId, action){
  const h = HND();
  if(!h) return;
  const idx = h.players.findIndex(p=>p.id===senderId);
  if(idx < 0 || idx !== h.toActIdx) return;
  applyAction(idx, action);
  h.toActIdx = nextActor(idx);
  scheduleNext();
}
function handleGuestRebuy(senderId, amount){
  if(G && G.tourney) return; // トーナメントはリバイ不可
  const i = G.ids.indexOf(senderId);
  if(i < 0 || G.stacks[i] > 0) return;
  G.stacks[i] += amount;
  G.log.unshift(`💰 ${G.names[senderId]} がリバイ +${amount}`);
  broadcastState();
}

function ploPub_build(){
  const h = HND();
  if(!h) return null;
  return {
    phase: h.phase, board: h.board, pot: h.pot, roundBetTotal: roundBetTotal(),
    highBet: h.highBet,
    handNames: h.handNames || null, // 役名（WIN THE SHOW / ショウダウンで公開）
    toActId: (h.toActIdx>=0 && h.players[h.toActIdx]) ? h.players[h.toActIdx].id : null,
    buttonId: G.ids[G.buttonIdx], bbAmount: h.bbAmount,
    currentGame: G.currentGame,
    rotation: G.rotation ? { every: G.rotation.every, idx: G.rotation.idx, seq: G.rotation.seq, handNo: G.handNo } : null,
    drawDone: h.drawDone, studStreet: h.studStreet, studVisible: h.studVisible,
    raiseCount: h.raiseCount || 0, minRaise: h.minRaise,
    sbId: (h.sbIdx>=0 && h.players[h.sbIdx]) ? h.players[h.sbIdx].id : null,
    bbId: (h.bbIdx>=0 && h.players[h.bbIdx]) ? h.players[h.bbIdx].id : null,
    results: h.results,
    handNames: (function(){
      // マルチ配信: 降りた相手の役名は送らない（公開しているのは降りていない相手のみ）
      if(!h.handNames) return null;
      const out = {};
      h.players.forEach(p=>{ if(!p.folded && h.handNames[p.id]!=null) out[p.id]=h.handNames[p.id]; });
      return out;
    })(),
    tourney: G.tourney ? {startTs:G.tourney.startTs, levelMin:G.tourney.levelMin, structKey:G.tourney.structKey, curAnte:G.tourney.curAnte, level:G.tourney.level, ranks:G.tourney.ranks} : null,
    players: (function(){
      const meP = h.players.find(x=>x.id===myId);
      const humanFolded = !isMulti && meP && meP.folded; // ソロで人間がフォールド済み→CPUの手を公開
      // 全員フォールド勝ち(uncontested)か通常ショウダウンかを区別する
      const isUncontested = h.results && h.results.length && h.results[0].uncontested;
      // WIN THE SHOW(ホスト設定がONの時のみ): 全員フォールドで勝った人のカードを公開する
      const uncontestedWinnerIds = (winTheShow && isUncontested)
        ? new Set(h.results.flatMap(r=>r.winnerIds||[])) : null;
      return h.players.map((p,pi)=>{
      const isStud = (MIX_GAMES[G.currentGame]||{}).type === 'stud';
      // スタッド: 表札を公開（自分の手札は your_hand で別途送る）
      const upCards = isStud && p.faceUp ? p.hole.map((c,i)=> p.faceUp[i] ? c : null) : null;
      const revealWin = uncontestedWinnerIds && uncontestedWinnerIds.has(p.id); // この人は勝者として公開
      // カード公開条件:
      //  - 全員フォールド勝ち → WIN THE SHOWがONの勝者のみ(revealWin)
      //  - 通常のショウダウン → 降りていない人を公開
      //  - ソロで人間が降りた → 相手を公開
      const showHole = isUncontested
        ? revealWin
        : ((h.phase==='showdown' && !p.folded) || (humanFolded && p.id!==myId));
      return {
        id:p.id, name:p.name, stack:p.stack, roundBet:p.roundBet, totalBet:p.totalBet||0, aggCnt:p.aggCnt||0, folded:p.folded, allIn:p.allIn, lastAction:p.lastAction,
        hole: showHole ? p.hole : null,
        holeCount: p.hole.length,
        upCards, // スタッドの表札（nullの要素は伏札）
        revealWin, // WIN THE SHOW: 全員フォールド勝者のカードを公開中
        pos: posBadge(h, pi), // ポジションバッジ
        lastDraw: p.lastDraw, // 直近ドローの交換枚数
        startStack: p.startStack, // ハンド開始時スタック（収支用）
      };
    });})(),
    handNo: G.handNo,
  };
}
function broadcastState(){
  if(!isHost || !isMulti) return;
  const pub = ploPub_build();
  if(!pub) return;
  fbBroadcast({type:'state', pub});
  const h = HND();
  h.players.forEach(p=>{
    if(p.id === myId) return;
    fbSendTo(p.id, {type:'your_hand', hole:p.hole, faceUp:p.faceUp});
  });
  if(typeof pgSaveHostState==='function') pgSaveHostState();
}

let guestLastSeenGame = null;
function onGuestStateUpdate(){
  if(!ploPub) return;
  if(ploPub.phase==='waiting'){ show('waiting'); renderWaitingPlayers(); return; }
  if(!g('screen-game').classList.contains('active')) show('game');
  // ゲスト: 受信した現在種目が変わったら大きくポップアウト
  if(ploPub.currentGame && guestLastSeenGame && ploPub.currentGame !== guestLastSeenGame){
    try { showGameChangePopout(ploPub.currentGame); } catch(e){}
  }
  guestLastSeenGame = ploPub.currentGame || guestLastSeenGame;
  renderGuest();
}

function renderGuest(){
  const pub = ploPub;
  if(!pub || !pub.players) return;
  // Firebaseは空配列を削除するため、boardがundefinedの場合は空配列に正規化
  if(!Array.isArray(pub.board)) pub.board = [];
  pub.players.forEach(p=>{ if(p.hole && !Array.isArray(p.hole)) p.hole=null; });
  // ゲスト自身の収支をセッション記録（showdown時に1ハンド1回）
  try { maybeRecordGuestHand(pub); } catch(e){ console.warn('maybeRecordGuestHand失敗', e); }
  updateGameTypeBar();
  setActReserve(pub.currentGame);
  const phLabelG = phaseLabelFor({phase:pub.phase, drawDone:pub.drawDone, studStreet:pub.studStreet, results:pub.results}, pub.currentGame);
  g('phase-label').textContent = phLabelG;
  g('pot-display').textContent = `POT: ${pub.pot + pub.roundBetTotal}`;
  {
    const gdG = MIX_GAMES[pub.currentGame] || {};
    const actG = pub.players ? pub.players[pub.toActIdx] : null;
    const mineG = !!(actG && actG.id===myId && pub.phase!=='showdown');
    plHeader({
      room: '#'+(roomCode||''),
      game: gdG.short || gdG.label || pub.currentGame,
      blind: (pub.sb!=null&&pub.bb!=null) ? (pub.sb+'/'+pub.bb) : '',
      canChange: false,
      street: phLabelG,
      turn: pub.phase==='showdown' ? 'ショーダウン'
        : (mineG ? '▶ あなたのアクション' : (actG ? `▶ ${actG.name} のアクション` : '')),
      myTurn: mineG
    });
  }
  const winCards = new Set();
  if(pub.phase==='showdown' && pub.results){
    const firstWinId = pub.results[0]?.winnerIds[0];
    const wp = pub.players.find(p=>p.id===firstWinId);
    if(wp && wp.hole){ const ev=evalHiPub(wp.hole, pub.board); if(ev) ev.cards.forEach(c=>winCards.add(c.r+c.s)); }
  }
  const gdG = MIX_GAMES[pub.currentGame] || MIX_GAMES.holdem;
  if(gdG.type==='community' || pub.board.length>0){
    let boardH='';
    const slots = gdG.type==='community' ? (gdG.boardN||5) : pub.board.length;
    for(let i=0;i<slots;i++){
      if(pub.board[i]){ const c=pub.board[i]; boardH += cardHTML(c,{win:winCards.has(c.r+c.s)}); }
      else boardH += `<div class="card" style="opacity:0.35;background:transparent;border:1px dashed rgba(232,200,74,0.4);box-shadow:none;"></div>`;
    }
    g('board-area').classList.toggle('six', slots>=6);
    g('board-area').innerHTML = boardH;
  } else {
    g('board-area').innerHTML = `<div style="font-family:'Share Tech Mono',monospace; color:rgba(232,200,74,0.5); font-size:0.7rem; letter-spacing:0.3em; text-transform:uppercase; text-align:center;">${gdG.short}</div>`;
  }
  const meIdx = pub.players.findIndex(p=>p.id===myId);
  const n = pub.players.length;
  const oppOrder=[];
  for(let k=1;k<n;k++) oppOrder.push((meIdx+k)%n);
  const positions = oppPositions(oppOrder.length);
  let oppH='';
  oppOrder.forEach((pi,slot)=>{
    const p=pub.players[pi];
    const isActive=(pub.toActId===p.id && pub.phase!=='showdown');
    const isDealer=(pub.buttonId===p.id) && (MIX_GAMES[pub.currentGame]||{}).type!=='stud';
    const pos=positions[slot];
    let cls='opp'; if(oppOrder.length>=7)cls+=' compact xcompact xxcompact'; else if(oppOrder.length>=4)cls+=' compact xcompact'; if(isActive)cls+=' active'; if(p.folded)cls+=' folded';
    let cardsH='';
    const isStudG = (MIX_GAMES[pub.currentGame]||{}).type === 'stud';
    if(isStudG && p.folded){
      cardsH = '';   // スタッド系: 降りた人のカードは表示しない
    }
    else if(p.hole){ p.hole.forEach(c=> cardsH+=cardHTML(c,{xs:true,muck:p.folded})); }
    else if(p.upCards){ // スタッド: 表札は見える、伏札は裏。裏は先にまとめ、表は重ねず横並び
      const downs=[], ups=[];
      p.upCards.forEach(c=>{ if(c) ups.push(cardHTML(c,{xs:true, up:true})); else downs.push('<div class="card xs back"></div>'); });
      cardsH = downs.join('') + ups.join('');
    }
    else { for(let i=0;i<(p.holeCount||0);i++) cardsH+=`<div class="card xs back"></div>`; }
    let handName='';
    if(pub.phase==='showdown' && !p.folded && pub.handNames && pub.handNames[p.id]) handName=`<div class="opp-hand-name">${pub.handNames[p.id]}</div>`;
    const allinB = p.allIn?'<span class="opp-badge-allin">ALLIN</span>':'';
    const posH = p.pos ? `<span class="pos-badge">${p.pos}</span>` : '';
    const foldPill = p.folded ? `<div class="fold-pill">Fold</div>` : '';
    const actBar = isActive ? `<div class="act-bar"></div>` : '';
    const isDrawGameG = (MIX_GAMES[pub.currentGame]||{}).type === 'draw';
    const drawPill = (isDrawGameG && !p.folded && p.lastDraw!=null)
      ? `<div class="draw-pill">${p.lastDraw>0 ? '🔄 '+p.lastDraw+'枚' : 'スタンド'}</div>` : '';
    let pnlPill = '';
    if(pub.phase==='showdown' && p.startStack!=null){
      const d = p.stack - p.startStack;
      const pc = d>0?'pnl-plus':(d<0?'pnl-minus':'pnl-zero');
      pnlPill = `<div class="pnl-pill ${pc}">${d>0?'+'+d:(d<0?d:'±0')}</div>`;
    }
    const showPill = p.revealWin ? `<div class="show-pill">🏆 WIN THE SHOW</div>` : '';
    const gHoleLen = ((p.hole&&p.hole.length)||(p.upCards&&p.upCards.length)||p.holeCount||0);
    oppH += buildOppSeatHTML({
      cls, pos, cardsH, holeLen: gHoleLen, isDealer,
      name: p.name, allinBadge: allinB, posH, stack: p.stack, actBar,
      showPill, handName, foldPill, drawPill, pnlPill, roundBet: p.roundBet
    });
  });
  g('opponents').innerHTML = oppH;
  const me = pub.players[meIdx];
  // 途中参加直後: まだプレイヤーに入っていない → 観戦案内
  if(!me){
    g('my-seat').innerHTML = `<div class="my-seat"><div class="my-top" style="justify-content:center;">
      <span class="muted">👀 観戦中 — 次のハンドから参加します</span>
    </div></div>`;
    g('action-area').innerHTML = '';
    return;
  }
  const meActive=(pub.toActId===myId && pub.phase!=='showdown');
  const meDealer=(pub.buttonId===myId);
  let myCardsH='';
  const myHole = (pub.phase==='showdown' && me && !me.folded && me.hole) ? me.hole : ploMyHole;
  const isStudG = (MIX_GAMES[pub.currentGame]||{}).type === 'stud';
  if(myHole && myHole.length) myHole.forEach((c,ci)=>{
    const down = isStudG && ploMyFaceUp && ploMyFaceUp[ci]===false;
    myCardsH+=cardHTML(c,{sm:true, muck:me&&me.folded, down});
  });
  let myHandName='';
  if(pub.phase==='showdown' && me && !me.folded && pub.handNames && pub.handNames[myId]){
    myHandName = `<div class="my-hand-name">${pub.handNames[myId]}</div>`;
  } else if(myHole && myHole.length && pub.board.length>=3 && me && !me.folded){
    const ev=evalHiPub(myHole, pub.board);
    if(ev){
      let txt = ev.detail || ev.name;
      const gdNow = MIX_GAMES[pub.currentGame||'holdem'];
      if(gdNow && gdNow.type==='community' && ev.rank<=1){
        const dr = detectDraws(myHole, pub.board, gdNow.plo, gdNow.boardN);
        if(dr.length) txt += ` <span class="draw-tag">+${dr.join('・')}</span>`;
      }
      myHandName=`<div class="my-hand-name">${txt}</div>`;
    }
  }
  let myCls='my-seat'; if(meActive)myCls+=' active'; if(me&&me.folded)myCls+=' folded';
  const myPosH = me && me.pos ? `<span class="pos-badge">${me.pos}</span>` : '';
  let myPnlG = '';
  if(pub.phase==='showdown' && me && me.startStack!=null){
    const d = me.stack - me.startStack;
    const pc = d>0?'pnl-plus':(d<0?'pnl-minus':'pnl-zero');
    myPnlG = `<span class="pnl-pill ${pc}" style="margin-top:0;">${d>0?'+'+d:(d<0?d:'±0')}</span>`;
  }
  g('my-seat').innerHTML = buildMySeatHTML({
    myCls, isDealer: meDealer, name: me?me.name:'', posH: myPosH,
    allIn: me&&me.allIn, folded: me&&me.folded, stack: me?me.stack:0,
    handName: myHandName, pnl: myPnlG, roundBet: me?me.roundBet:0,
    holeLen: myHole?myHole.length:0, cardsH: myCardsH, active: meActive
  });
  renderGuestActionArea();
  if(me && me.stack<=0 && pub.phase==='showdown' && !pub.tourney) showGuestRebuyPrompt();
}

// ゲスト用ベット制限計算（pubベース）
function calcBetLimitsGuest(pub, me){
  const gd = MIX_GAMES[pub.currentGame] || MIX_GAMES.holdem;
  const betting = gd.betting || 'pl';
  const toCall = pub.highBet - me.roundBet;
  const pot = pub.pot + pub.roundBetTotal;
  let minRaiseTo, maxRaiseTo, canRaise, flUnit=0;
  if(betting === 'fl'){
    const small = pub.bbAmount, big = pub.bbAmount*2;
    if(gd.type==='stud') flUnit = (pub.studStreet||3) <= 4 ? small : big;
    else if(gd.type==='draw') flUnit = (pub.drawDone||0) <= 1 ? small : big;
    else flUnit = small;
    const capped = (pub.raiseCount||0) >= 4;
    const isBringInSpot = (gd.type==='stud') && (pub.studStreet===3) && (pub.highBet < flUnit);
    minRaiseTo = isBringInSpot ? flUnit : (pub.highBet + flUnit);
    maxRaiseTo = minRaiseTo;
    canRaise = !capped && (me.stack > toCall);
    if(!capped && me.stack > toCall && minRaiseTo - me.roundBet > me.stack){
      minRaiseTo = me.roundBet + me.stack; maxRaiseTo = minRaiseTo;
      canRaise = minRaiseTo > pub.highBet;
    }
  } else if(betting === 'nl'){
    minRaiseTo = Math.min(pub.highBet + Math.max(pub.minRaise||pub.bbAmount, pub.bbAmount), me.roundBet + me.stack);
    maxRaiseTo = me.roundBet + me.stack;
    canRaise = (me.stack > toCall) && (maxRaiseTo > pub.highBet);
  } else {
    minRaiseTo = Math.min(pub.highBet + pub.bbAmount, me.roundBet + me.stack);
    maxRaiseTo = Math.min(potLimitMaxRaiseTo(pot, toCall, me.roundBet), me.roundBet + me.stack);
    canRaise = (me.stack > toCall) && (maxRaiseTo > pub.highBet);
  }
  return {betting, minRaiseTo, maxRaiseTo, canRaise, flUnit, toCall, pot};
}

// ゲスト用: 公開情報+自分の手札からCPU判断用の擬似ハンドを構築（見えない情報は使わない）
function buildGuestHand(){
  const pub = ploPub;
  if(!pub || !pub.players) return null;
  const players = pub.players.map((p,i)=>{
    const isMe = p.id===myId;
    let hole, faceUp;
    if(isMe){ hole = ploMyHole.slice(); faceUp = (ploMyFaceUp&&ploMyFaceUp.length?ploMyFaceUp:hole.map(()=>false)).slice(); }
    else {
      hole=[]; faceUp=[];
      if(p.upCards){ p.upCards.forEach(cd=>{ hole.push(cd||{r:0,s:'x'}); faceUp.push(!!cd); }); }
      while(hole.length < (p.holeCount||0)){ hole.push({r:0,s:'x'}); faceUp.push(false); }
    }
    return { id:p.id, idx:i, name:p.name, stack:p.stack, roundBet:p.roundBet||0,
      totalBet:p.totalBet||0, aggCnt:p.aggCnt||0, folded:!!p.folded, allIn:!!p.allIn,
      lastDraw:(p.lastDraw==null?null:p.lastDraw), hole, faceUp };
  });
  const idxOf = id => players.findIndex(pp=>pp.id===id);
  return {
    players, board: pub.board||[], pot: pub.pot||0,
    phase: pub.phase, highBet: pub.highBet||0,
    minRaise: pub.minRaise || pub.bbAmount || 20, bbAmount: pub.bbAmount||20,
    sbIdx: pub.sbId!=null ? idxOf(pub.sbId) : -1,
    bbIdx: pub.bbId!=null ? idxOf(pub.bbId) : -1,
    toActIdx: idxOf(pub.toActId), results: pub.results||null,
    drawDone: pub.drawDone||0, studStreet: pub.studStreet||3,
    raiseCount: pub.raiseCount||0, deck: [],
    gameType: (MIX_GAMES[pub.currentGame]||{}).type,
  };
}
function updateCpuHintGuest(mode){
  const el = g('cpu-hint');
  if(!el) return;
  const pub = ploPub;
  if(!soloShowHint || !pub || pub.phase==='showdown'){ el.style.display='none'; _hintKey=null; return; }
  const isDraw = mode==='draw';
  if(!isDraw && pub.toActId !== myId){ el.style.display='none'; _hintKey=null; return; }
  const key = ['g', pub.handNo, pub.phase, pub.studStreet, pub.drawDone, pub.highBet, pub.pot, isDraw?'d':'b'].join('|');
  if(key === _hintKey){ el.style.display='block'; el.innerHTML = _hintHtml; return; }
  if(_hintBusy) return;
  _hintBusy = true;
  el.style.display = 'block';
  el.innerHTML = '💡 CPU参考: <span class="muted">計算中…</span>';
  setTimeout(()=>{
    const el2 = g('cpu-hint') || el;
    const savedG = G;
    try{
      const gd = MIX_GAMES[pub.currentGame] || MIX_GAMES.holdem;
      let txt;
      if(isDraw){
        const drawsLeft = (gd.drawRounds||1) - (pub.drawDone||0);
        let keep;
        if(gd.evalLo==='badugi') keep = bestBadugiKeep(ploMyHole);
        else keep = bestLowKeep(ploMyHole, gd.evalLo, drawsLeft);
        const disc = ploMyHole.filter(cd=>!keep.includes(cd));
        txt = disc.length===0 ? '<b>スタンドパット</b>'
          : `<b>${disc.length}枚交換</b>（${disc.map(cardLbl).join(' ')} を捨てる）`;
      } else {
        const fake = buildGuestHand();
        if(!fake || fake.toActIdx<0) throw 0;
        G = { currentGame: pub.currentGame, ids: fake.players.map(pp=>pp.id),
              buttonIdx: Math.max(0, fake.players.findIndex(pp=>pp.id===pub.buttonId)),
              tourney: pub.tourney||null, hand: fake, log: [], handNo: pub.handNo||1, isMulti: true };
        const act = cpuDecide(fake.toActIdx);
        txt = act.type==='fold' ? '<b>フォールド</b>'
          : act.type==='check' ? '<b>チェック</b>'
          : act.type==='call' ? '<b>コール</b>'
          : `<b>レイズ → ${act.amount}</b>`;
      }
      _hintHtml = `💡 CPU参考: ${txt}`;
      el2.innerHTML = _hintHtml;
      el2.style.display = 'block';
      _hintKey = key;
    }catch(e){ el2.style.display='none'; }
    G = savedG;
    _hintBusy = false;
  }, 30);
}
function renderGuestActionArea(){
  const pub = ploPub;
  const area = g('action-area');
  if(pub.phase==='showdown' || pub.toActId !== myId){ area.innerHTML=''; return; }
  const me = pub.players.find(p=>p.id===myId);
  if(!me){ area.innerHTML=''; return; }
  const limits = calcBetLimitsGuest(pub, me);
  limits.stack = me.stack; limits.roundBet = me.roundBet;
  const ctx = {
    fold: "guestAct({type:'fold'})",
    check: "guestAct({type:'check'})",
    call: "guestAct({type:'call'})",
    raiseTo: (amt)=>`guestAct({type:'raise', amount:${amt}})`,
    confirm: "confirmRaiseGuest()",
    bbAmount: pub.bbAmount, highBet: pub.highBet, raiseCount: pub.raiseCount,
    isBringInChoice: false
  };
  area.innerHTML = buildActionBarHTML(limits, ctx);
  updateCpuHintGuest('bet');
}
function confirmRaiseGuest(){ guestAct({type:'raise', amount:parseInt(g('bet-slider').value)}); }
function guestAct(action){ g('action-area').innerHTML=''; fbSendToHost({type:'action', action}); }
function showGuestRebuyPrompt(){
  const area=g('action-area');
  if(area.querySelector('.rebuy-prompt')) return;
  const base=soloStack;
  area.innerHTML=`<div class="action-bar rebuy-prompt">
    <div class="center" style="margin-bottom:10px;color:var(--gold);font-weight:700;">💰 チップ切れ</div>
    <div class="action-btns">
      <button class="btn btn-felt" onclick="guestRebuy(${Math.floor(base/2)})">+${Math.floor(base/2)}</button>
      <button class="btn btn-gold" onclick="guestRebuy(${base})">+${base}</button>
      <button class="btn btn-felt" onclick="guestRebuy(${base*2})">+${base*2}</button>
    </div></div>`;
}
function guestRebuy(amount){ g('action-area').innerHTML=''; fbSendToHost({type:'rebuy', amount}); }

// ゲスト用ドローUI（自分の手札ploMyHoleで交換選択）
let guestDrawSelected = [];
function showGuestDrawUI(gameKey){
  guestDrawSelected = [];
  const area = g('action-area');
  area.innerHTML = `
    <div class="action-bar">
      <div class="center" style="margin-bottom:8px; color:var(--gold); font-weight:700;">🔄 交換するカードを選んでタップ</div>
      <div id="guest-draw-hand" style="display:flex; gap:6px; justify-content:center; margin-bottom:10px;"></div>
      <button class="btn btn-gold" onclick="guestConfirmDraw()">交換する</button>
      <button class="btn btn-ghost btn-sm" onclick="guestStandPat()">交換しない（スタンドパット）</button>
      <div id="cpu-hint" class="center muted small" style="display:none; margin-top:8px;"></div>
    </div>`;
  renderGuestDrawHand();
  updateCpuHintGuest('draw');
}
function renderGuestDrawHand(){
  const cont = g('guest-draw-hand');
  if(!cont) return;
  cont.innerHTML = '';
  (ploMyHole||[]).forEach((c,i)=>{
    const selected = guestDrawSelected.includes(i);
    const div = document.createElement('div');
    div.innerHTML = cardHTML(c,{sm:true});
    div.style.cssText = `cursor:pointer; border:2px solid ${selected?'var(--red)':'transparent'}; border-radius:8px; opacity:${selected?'0.5':'1'};`;
    div.onclick = ()=>{
      const idx = guestDrawSelected.indexOf(i);
      if(idx>=0) guestDrawSelected.splice(idx,1);
      else guestDrawSelected.push(i);
      renderGuestDrawHand();
    };
    cont.appendChild(div);
  });
}
function guestConfirmDraw(){
  g('action-area').innerHTML = '';
  fbSendToHost({type:'draw_response', discard: guestDrawSelected.slice()});
}
function guestStandPat(){
  g('action-area').innerHTML = '';
  fbSendToHost({type:'draw_response', discard: []});
}

// ===== セッション（再接続） =====
const PG_SESSION_KEY_plo = 'pgSession_plo';
function ploSaveSession(){
  try { localStorage.setItem(PG_SESSION_KEY_plo, JSON.stringify({myId,myName,roomCode,fbRoom,isHost,ts:Date.now()})); } catch(e){}
}
function ploClearSession(){ try { localStorage.removeItem(PG_SESSION_KEY_plo); } catch(e){} }
function ploLoadSession(){
  try {
    const raw = localStorage.getItem(PG_SESSION_KEY_plo);
    if(!raw) return null;
    const s = JSON.parse(raw);
    if(Date.now()-s.ts > 3*60*60*1000){ ploClearSession(); return null; }
    return s;
  } catch(e){ return null; }
}
function ploShowReconnectOption(){
  const s = ploLoadSession();
  const btn = g('btn-reconnect');
  if(!btn) return;
  if(!s || !s.roomCode){ btn.style.display='none'; return; }
  btn.style.display='';
  btn.textContent = '🔄 前のルームに戻る（#' + s.roomCode + '）';
}
function pgSaveHostState(){
  if(!isHost || !fbRoom || !isMulti || typeof G==='undefined' || !G) return;
  try { fbPut('hostState', {ts: Date.now(), j: JSON.stringify(G), seen: JSON.stringify(fbLastSeen||{})}); } catch(e){ console.warn('pgSaveHostState失敗', e); }
}
async function ploReconnectToRoom(){
  const s = ploLoadSession();
  if(!s){ ploSetErr('セッションが見つかりません'); return; }
  myId=s.myId; myName=s.myName; roomCode=s.roomCode; fbRoom=s.fbRoom; isHost=s.isHost; isMulti=true;
  ploSetSt('再接続中...');
  const meta = await fbGet('meta');
  if(!meta){ ploClearSession(); ploSetErr('ルームが見つかりません'); ploSetSt(''); ploShowReconnectOption(); return; }
  soloStack=meta.stack; soloSB=meta.sb; soloBB=meta.bb;
  if(!sessionStats) initSession('multi'); // 再接続時もセッション集計を継続
  if(isHost){
    const hs = await fbGet('hostState');
    if(hs && hs.j){
      // 完全状態（非公開情報込み）から復元
      G = JSON.parse(hs.j);
      fbListen();
      try { fbLastSeen = JSON.parse(hs.seen||'{}'); } catch(e){ fbLastSeen = {}; }
      g('disp-code').textContent=roomCode;
      if(G.hand){
        show('game');
        broadcastState();
        render();
        const h = HND();
        if(h && h.results){ aiTimer = setTimeout(()=>startNewHand(), 1500); }
        else if(h && h.needDraw){ aiTimer = setTimeout(()=>checkDrawComplete(h), 1200); }
        else if(h){ scheduleNext(); }
      } else {
        show('waiting');
      }
    } else {
      // 待機中（ゲーム未開始）: 待機リストから復元
      const w = await fbGet('waiting');
      fbListen();
      if(Array.isArray(w) && w.length) waitingPlayers = w;
      show('waiting'); g('disp-code').textContent=roomCode;
      if(typeof renderWaitingPlayers==='function') renderWaitingPlayers();
      fbBroadcast({type:'waiting_update', waitingPlayers});
    }
  } else {
    fbListen();
    await fbSendToHost({type:'join', name:myName, id:myId});
    show('waiting'); g('disp-code').textContent=roomCode;
    g('wait-host-note').textContent='再接続しました。ホストを待っています...';
  }
  ploSetSt('');
}

// ============================================================
// MIX 種目選択
// ============================================================
let pendingGameChange = null; // 次ハンドで適用する種目

function setInitGame(gk){
  soloSelectedGame = gk;
  hostSelectedGame = gk;
  document.querySelectorAll('#game-select .count-btn').forEach(b=>{
    b.classList.toggle('selected', b.dataset.g===gk);
  });
}

function updateGameTypeBar(){
  // 現在の種目ラベルと変更ボタンの表示制御
  const gk = (G && G.currentGame) || (isMulti && ploPub && ploPub.currentGame) || soloSelectedGame || 'holdem';
  const gd = MIX_GAMES[gk] || MIX_GAMES.holdem;
  const lbl = g('current-game-label');
  // ローテーション情報（ホストはG、ゲストはploPub）
  const rot = (G && G.rotation) ? {seq:G.rotation.seq, every:G.rotation.every, idx:G.rotation.idx, handNo:G.handNo}
            : (isMulti && ploPub && ploPub.rotation) ? ploPub.rotation : null;
  if(lbl){
    if(rot){
      // 現在の種目で残り何手か（現在のハンドを含む）。every - ((handNo-1) % every)
      const left = rot.every - ((rot.handNo - 1) % rot.every);
      const nextGk = rot.seq[(rot.idx+1)%rot.seq.length];
      lbl.textContent = `${gd.label} ｜ 残り${left}手→${MIX_GAMES[nextGk].short}`;
    } else {
      lbl.textContent = gd.label + (pendingGameChange ? ` → ${MIX_GAMES[pendingGameChange].short}` : '');
    }
  }
  // 変更ボタン: ソロは常に、マルチはホストのみ。ローテーション中は非表示
  const btn = g('btn-change-game');
  if(btn){
    const rotating = !!rot;
    const canChange = (!isMulti || isHost) && !rotating;
    btn.style.display = canChange ? '' : 'none';
  }
}

function openGamePicker(){
  const list = g('game-picker-list');
  const curGk = (G && G.currentGame) || soloSelectedGame || 'holdem';
  const betLabel = {nl:'NL', pl:'PL', fl:'固定'};
  list.innerHTML = MIX_ORDER.map(gk=>{
    const gd = MIX_GAMES[gk];
    const isCur = gk===curGk;
    return `<button class="btn ${isCur?'btn-gold':'btn-felt'}" style="margin:5px 0; text-align:left;" onclick="selectGame('${gk}')">
      ${isCur?'▶ ':''}${gd.label} <span class="muted small">(${gd.short}・${betLabel[gd.betting]||''})</span>
    </button>`;
  }).join('');
  g('game-picker-modal').style.display = 'flex';
}
function closeGamePicker(){ g('game-picker-modal').style.display = 'none'; }
function selectGame(gk){
  // 次ハンドから適用
  pendingGameChange = gk;
  closeGamePicker();
  updateGameTypeBar();
  if(G) G.log.unshift(`🔄 次ハンドから「${MIX_GAMES[gk].label}」に変更`);
  // ソロ即描画
  if(!isMulti && typeof render==='function' && HND()) render();
}

// 次ハンド開始時に種目変更を適用（startNewHandから呼ぶ）
function applyPendingGameChange(){
  if(pendingGameChange && G){
    G.currentGame = pendingGameChange;
    if(!isMulti) soloSelectedGame = pendingGameChange;
    if(isMulti && isHost) hostSelectedGame = pendingGameChange;
    pendingGameChange = null;
  }
}

// 初期化
window.addEventListener('DOMContentLoaded', ()=>{
  setPlayerCount(3);
  setStack(1000);
  try { ploShowReconnectOption(); } catch(e){ console.warn('ploShowReconnectOption失敗', e); }
});

// テスト用に主要な純粋関数を公開（本番のゲーム動作には一切影響しない）
function __testSetG(g){ G = g; } // テスト専用: ゲーム状態を差し込む（本番では使わない）
if (typeof window !== 'undefined') {
  window.__pokerInternals = {
    eval5, compareEval, buildPots, distributePot,
    loValue, compareLo, eval5_a5, eval5_27, badugiScore, cmpArr,
    bestA5Lo, best27Lo, bestLo8From, bestHiFrom, evalLo, evalHi, evalSuperHi,
    HAND_RANK, secureRand, esc, makeDeck, shuffleDeck,
    // ベッティング進行（テスト用）
    __testSetG, HND, applyAction, isRoundComplete, nextActor, nextActorIn,
    activePlayers, notFolded, calcBetLimits, currentPot, roundBetTotal
  };
}



