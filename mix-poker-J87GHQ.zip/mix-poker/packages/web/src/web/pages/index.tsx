import { useEffect, useState } from "react";
import { mountPokerGame } from "../lib/mount-poker-game";

function Index() {
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    mountPokerGame()
      .then(() => setReady(true))
      .catch((e: unknown) => setError(e instanceof Error ? e.message : String(e)));
  }, []);

  if (error) {
    return (
      <div className="boot-note boot-note--error">
        ゲームの読み込みに失敗しました
        <span>{error}</span>
      </div>
    );
  }

  if (!ready) {
    return <div className="boot-note">MIX POKER</div>;
  }

  return null;
}

export default Index;
