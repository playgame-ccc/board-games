// Mounts the MIX POKER game (vanilla DOM + globals) into document.body.
// The markup lives in /mixpoker/body.html and the game engine in /mixpoker/game1-4.js,
// which are loaded in order and then kicked off with a replayed DOMContentLoaded event.

const GAME_SCRIPTS = [
  "/mixpoker/game1.js",
  "/mixpoker/game2.js",
  "/mixpoker/game3.js",
  "/mixpoker/game4.js",
] as const;

const MARKUP_URL = "/mixpoker/body.html";
const MOUNTED_ATTR = "data-mixpoker-mounted";

let mounting: Promise<void> | null = null;

function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(`script[src="${src}"]`);
    if (existing) {
      resolve();
      return;
    }
    const el = document.createElement("script");
    el.src = src;
    el.async = false;
    el.onload = () => resolve();
    el.onerror = () => reject(new Error(`failed to load ${src}`));
    document.body.appendChild(el);
  });
}

async function mount(): Promise<void> {
  const res = await fetch(MARKUP_URL, { cache: "no-cache" });
  if (!res.ok) throw new Error(`failed to load game markup (${res.status})`);
  const html = await res.text();

  const holder = document.createElement("div");
  holder.setAttribute(MOUNTED_ATTR, "true");
  holder.style.display = "contents";
  holder.innerHTML = html;
  document.body.appendChild(holder);
  document.body.classList.add("mixpoker");

  for (const src of GAME_SCRIPTS) {
    await loadScript(src);
  }

  document.dispatchEvent(new Event("DOMContentLoaded", { bubbles: true }));
}

export function mountPokerGame(): Promise<void> {
  if (document.body.querySelector(`[${MOUNTED_ATTR}]`)) return Promise.resolve();
  if (!mounting) {
    mounting = mount().catch((err) => {
      mounting = null;
      throw err;
    });
  }
  return mounting;
}
